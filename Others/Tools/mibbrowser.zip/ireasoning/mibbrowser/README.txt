                iReasoning MIB Browser

browser.bat:     script for launching MIB browser on windows.
browser.sh:      script for launching MIB browser on UNIX. 
browser.commad:  script for launching MIB browser on OS X. 

Open a shell window and run the script to start MIB browser.

