﻿#include "dialognetbind.h"
#include "ui_dialognetbind.h"

DialogNetBind::DialogNetBind(QMap<QString, struct st_sean_netinterface> NetIfaceS, QWidget *parent) :
    m_NetIfaceS(NetIfaceS),
    QDialog(parent),
    ui(new Ui::DialogNetBind)
{
    ui->setupUi(this);

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
    QValidator* validator = new QRegExpValidator(regx);
    ui->lineEdit_bindip->setValidator(validator);
    ui->lineEdit_BindMask->setValidator(validator);
    ui->lineEdit_BindGate->setValidator(validator);

    ui->comboBoxbindtype->addItem(tr("负载均衡(0)"));
    ui->comboBoxbindtype->addItem(tr("冗余(1)"));
    ui->comboBoxbindtype->addItem(tr("适配器传输负载均衡(6)"));
    m_BindMode = 0;

    //ui->listWidget_bindnet->setHeaderLabel(QString(tr("网络接口")));

    for(QMap<QString, struct st_sean_netinterface>::iterator iter = m_NetIfaceS.begin(); iter!=m_NetIfaceS.end(); ++iter)
    {
        ui->listWidget_bindnet->addItem(iter.key());
        //ui->lineEdit_state->setText(NetStateDescriptionS[iter.value().state]);
        //ui->lineEdit_mac->setText(iter.value().mac);
    }

    ui->lineEdit_bindip->setText(m_NetIfaceS.begin().value().ipv4);
    ui->lineEdit_BindMask->setText(m_NetIfaceS.begin().value().netmask);
    ui->lineEdit_BindGate->setText(m_NetIfaceS.begin().value().netgate);
}

DialogNetBind::~DialogNetBind()
{
    delete ui;
}

void DialogNetBind::on_buttonBox_accepted()
{
    m_BindIp = ui->lineEdit_bindip->text();
    m_BindMask = ui->lineEdit_BindMask->text();
    m_BindGate = ui->lineEdit_BindGate->text();
    m_BindMode = ui->comboBoxbindtype->currentIndex();
    if(m_BindMode==0)
    {
        m_BindMode = 0;
    }
    else if(m_BindMode==1)
    {
        m_BindMode = 1;
    }
    else if(m_BindMode==2)
    {
        m_BindMode = 6;
    }

    if(m_BindIp.length()==0||m_BindMask.length()==0||m_BindGate.length()==0)
    {
        QDialog::reject();
    }
}
