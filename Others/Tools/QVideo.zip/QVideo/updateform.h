﻿#ifndef UPDATEFORM_H
#define UPDATEFORM_H

#include <QWidget>
#include "seanfileserver.h"
#include "configconnector.h"

namespace Ui {
class UpdateForm;
}

class UpdateForm : public QWidget,  public SeanSendFileTaskOwner
{
    Q_OBJECT


public:
    explicit UpdateForm(ConfigConnector *conn, QWidget *parent = 0);
    ~UpdateForm();

    int HandleUpdateAck(QStringList cmdlist);

private slots:
    void on_pushButtonUpdate_clicked();

    void on_pushButton_remote_chosefile_clicked();

    void on_pushButton_remote_upload_clicked();

    void on_pushButton_nvrcore_backup_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_restoredatabase_clicked();

    void on_pushButton_commonupgedate_clicked();

    void on_pushButton_2_clicked();

    void on_checkBox_dosh_clicked();

    //void on_pushButton_clicked();

    //void on_pushButton_updatanvr_clicked();


    void on_pushButton_restore_old_version_clicked();

    //void on_pushButton_updatendm_clicked();

    //void on_pushButton_startupdatendm_clicked();

    //void on_pushButton_updatenmc_clicked();

   // void on_pushButton_startupdatenmc_clicked();

    void on_pushButton_updateall1_clicked();

    void on_pushButton_startupdateall1_clicked();

    //void on_checkBox_updatenmc_clicked();

    //void on_checkBox_withstorage_clicked();

    void on_pushButton_choose_uds_clicked();

    void on_pushButton_uds_update_clicked();

    void on_pushButton_choose_udsall_clicked();

    void on_pushButton_udsall_update_clicked();

private:
    virtual void OnSeanFileSending(struct SeanUploadFileCtrlInfo CtrlInfo);
    virtual void OnSeanFileSendError(int Error);
    virtual void OnSeanFileSendFinish();

private:
    Ui::UpdateForm *ui;

    ConfigConnector *m_conn;

    QString fileNameNvr;
    QString fileNameNdm;
    QString fileNameNmc;
    QString fileNameAll1;

    QString fileNameUDSMgr;
};

#endif // UPDATEFORM_H
