#include "dialogenterip.h"
#include "ui_dialogenterip.h"
#include <qvalidator.h>
#include <QMessageBox>

DialogEnterIp::DialogEnterIp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogEnterIp)
{
    ui->setupUi(this);

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
    QRegExpValidator *validator = new QRegExpValidator(regx);
    ui->lineEdit_enterIp->setValidator(validator);
}

DialogEnterIp::~DialogEnterIp()
{
    delete ui;
}

void DialogEnterIp::on_buttonBox_accepted()
{
    m_IP = ui->lineEdit_enterIp->text();
    if(m_IP.size()==0)
    {
        QMessageBox::about(NULL, tr("请输入ip"), tr("请输入ip"));
    }
}
