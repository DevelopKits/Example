#ifndef CONNECTOR_H
#define CONNECTOR_H

#include <QHostAddress>
#include <QTcpSocket>

#include "COMM_HEADER.h"

class  ITcpCallbackSink: public QObject
{
    Q_OBJECT
protected slots:
    virtual int OnRecvData(char* pData, int dataLen)=0;
    virtual int OnConnected()=0;
    virtual int OnClosed()=0;
    //virtual int OnReConnected(UINT64 fromAddr)=0;
};

class Connector : public QTcpSocket
{
    Q_OBJECT
private:
    unsigned int SeqID;
    int RecvBufLen;
    char *RecvBuf;
    char *CmdBuf;
    int Readed;
public:
    explicit Connector(QObject *parent = 0);
    ~Connector();
    int SetCallBackSink(ITcpCallbackSink* pSink, int serverType);
    int SendCmd(unsigned short wSrcType, unsigned short wCmdMainType, unsigned int dwCmdSubType,char *strXml);
    int SendData(const BYTE* Data, int Len);
signals:
    void OnRecved(char* Data, int Len);
public slots:
    void OnReciveData();
};

#endif // CONNECTOR_H
