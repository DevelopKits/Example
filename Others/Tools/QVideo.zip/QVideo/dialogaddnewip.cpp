﻿#include "dialogaddnewip.h"
#include "ui_dialogaddnewip.h"
#include <qvalidator.h>
#include <QMessageBox>

DialogAddNewIP::DialogAddNewIP(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAddNewIP)
{
    ui->setupUi(this);

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
    QRegExpValidator *validator = new QRegExpValidator(regx);
    ui->textEdit_addnewipip->setValidator(validator);
    ui->textEdit_addnewipmask->setValidator(validator);
}

DialogAddNewIP::~DialogAddNewIP()
{
    delete ui;
}

void DialogAddNewIP::on_buttonBox_accepted()
{
    newIp = ui->textEdit_addnewipip->text();
    newMask = ui->textEdit_addnewipmask->text();

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");

    if(newMask.indexOf(regx)==-1 || newIp.indexOf(regx)==-1)  //newIp
    {
         QMessageBox::about(NULL, tr("格式错误"), tr("格式错误"));

         return;
    }
}
