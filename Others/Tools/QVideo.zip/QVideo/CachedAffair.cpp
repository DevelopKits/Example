﻿#include "CachedAffair.h"
#include "time.h"
//UINT64 CCachedAffair::m_lastSeq = 0;
//QMutex CCachedAffair::m_simpleCS;

CCachedAffair::CCachedAffair(ST_AFFAIR_CALLBACK* pAffairCallBack,DWORD dwDevId)
:m_fpOnGotData(NULL),m_fpOnAffairOverTime(NULL),m_dwUserCookie(0),m_nOverTime(1000)
,m_nOutCmdIdx(0),m_nExptedRecvCmdIdx(0),m_nOutSeqIdx(0),m_dwPushedTime(time(0))
,m_handleOverTime(NULL),m_Conditionmutex(NULL),m_pRecvDataBuf(NULL),m_recvDataSize(0),m_recvDataCanceled(false),m_dwDevId(dwDevId)
{
    if (pAffairCallBack && pAffairCallBack->m_pOnGotData && pAffairCallBack->m_pOnAffairOverTime)
    {
        m_fpOnGotData			= pAffairCallBack->m_pOnGotData;
        m_fpOnAffairOverTime	= pAffairCallBack->m_pOnAffairOverTime;
        m_dwUserCookie			= pAffairCallBack->m_dwUserCookie;
        m_nOverTime				= pAffairCallBack->m_nOverTime;
    }
    else
    {
        m_handleOverTime		= new QWaitCondition();
        m_Conditionmutex        = new QMutex();
    }
}

CCachedAffair::~CCachedAffair(void)
{
    STRY;
    if (NULL != m_pRecvDataBuf)
    {
        free(m_pRecvDataBuf);
        m_pRecvDataBuf	= 0;
    }

    if(m_handleOverTime)
        delete m_handleOverTime;

    if(m_Conditionmutex)
        delete m_Conditionmutex;

    SCATCH;
}

int CCachedAffair::DoOverTime()
{
    STRY;
    if (m_fpOnAffairOverTime)
        m_fpOnAffairOverTime(m_dwUserCookie);

    return 1;
    SCATCH;
    return -1;
}

int CCachedAffair::DoOnGotData(BYTE* pData, int dataLen)
{
    STRY;
    if (m_fpOnGotData)//m_fpOnGotData不为0，为异步
    {
        m_fpOnGotData(m_dwUserCookie,pData,dataLen);
        return 1;
    }
    else if (m_handleOverTime)
    {
        m_Conditionmutex->lock();
        if(m_recvDataCanceled==true)
        {
            m_Conditionmutex->unlock();
            return 3;
        }

        m_recvDataSize	= dataLen;
        m_pRecvDataBuf	= (BYTE*)malloc(m_recvDataSize);

        if (NULL != m_pRecvDataBuf)
            memcpy(m_pRecvDataBuf,pData,dataLen);

        //////////////////////////SetEvent(m_handleOverTime);
        m_handleOverTime->wakeOne();
        m_Conditionmutex->unlock();
        return 2;
    }
    return 1;
    SCATCH;
    return -1;
}

void CCachedAffair::SetCommandIdxPair(int outCmdIdx,int exptedRecvCmdIdx)
{
    m_nOutCmdIdx			= outCmdIdx;
    m_nExptedRecvCmdIdx		= exptedRecvCmdIdx;
}

void CCachedAffair::SetSequencePair(int outSeqIdx)
{
    m_nOutSeqIdx			= outSeqIdx;
}


CCachedAffairMap* CCachedAffairMap::GetInstance()
{
    static CCachedAffairMap *s_map=NULL;
    if(s_map==NULL)
    {   //need double check ???
        s_map = new CCachedAffairMap();
    }
    return s_map;
}
CCachedAffairMap::CCachedAffairMap() : m_lastSeq(0)
{

}
int CCachedAffairMap::PushNewAffair(ST_AFFAIR_CALLBACK* pAffairCallBack
                                    ,int nOutSeqId,int nOutCmdId,int nExpetedCmdId,DWORD dwDevId)
{
    if (NULL == pAffairCallBack )
        return -2;

    STRY;
    //默认事务超时时间为1秒
    int nOverTime	= pAffairCallBack->m_nOverTime;

    CCachedAffair* pCachedAffairItem = new CCachedAffair(pAffairCallBack,dwDevId);
    if (NULL == pCachedAffairItem)
        return -2;

    pCachedAffairItem ->SetSequencePair(nOutSeqId);
    pCachedAffairItem ->SetCommandIdxPair(nOutCmdId,nExpetedCmdId);

    UINT64 overTime_t=0;
    {
        //缩小加锁范围
        QMutexLocker simpleLock(&m_simpleCS);
        overTime_t = (UINT64)++m_lastSeq;
        m_cachedAffairMap [overTime_t] = pCachedAffairItem;
    }

    //判断是否进行同步操作
    if (NULL == pAffairCallBack->m_pOnGotData || NULL == pAffairCallBack->m_pOnAffairOverTime)
    {
        //是,等待事件返回
        bool res=false;
        pCachedAffairItem->m_Conditionmutex->lock();
        if(pCachedAffairItem ->m_pRecvDataBuf==NULL)
            res = pCachedAffairItem->m_handleOverTime->wait(pCachedAffairItem->m_Conditionmutex, nOverTime);
        if(res==false)
        {
            //等待超时
            pCachedAffairItem->m_recvDataCanceled = true;
        }

        if (pCachedAffairItem->m_recvDataSize && pCachedAffairItem->m_pRecvDataBuf)
            //&& !::IsBadWritePtr (pCachedAffairItem ->m_pRecvDataBuf,pCachedAffairItem->m_recvDataSize))
        {
            pAffairCallBack ->m_pRecvSize	= pCachedAffairItem->m_recvDataSize;
            pAffairCallBack ->m_pRecvData  = pCachedAffairItem->m_pRecvDataBuf;

            pCachedAffairItem->m_recvDataSize = 0;
            pCachedAffairItem->m_pRecvDataBuf =0;
            //memcpy(pAffairCallBack ->m_pRecvData,pCachedAffairItem ->m_pRecvDataBuf,pAffairCallBack ->m_pRecvSize);
        }

        pCachedAffairItem->m_Conditionmutex->unlock();

        QMutexLocker simpleLock(&m_simpleCS);
        map<UINT64,CCachedAffair*>::iterator iterDel = m_cachedAffairMap.find (overTime_t);
        if (iterDel != m_cachedAffairMap.end ())
        {
            m_cachedAffairMap.erase(iterDel);
            delete iterDel->second; //delete pCachedAffairItem;
        }

        return pAffairCallBack ->m_pRecvSize ;
    }

    return 1;
    SCATCH;
    return -1;
}

int CCachedAffairMap::CheckBeExptedData(BYTE* pData, int dataLen)
{
    STRY;

    ST_ICMS_CMD_HEADER* pCmdHeader = (ST_ICMS_CMD_HEADER*)pData;
    if(!pCmdHeader) //|| IsBadReadPtr(pCmdHeader,sizeof(ST_ICMS_CMD_HEADER)))
        return -1;

    CCachedAffair* pAffairItem=NULL;
    {
        QMutexLocker simpleLock(&m_simpleCS);
        map<UINT64,CCachedAffair*>::iterator iter = find_if (m_cachedAffairMap.begin (),m_cachedAffairMap.end ()
            ,CBeExpectedDataComing<UINT64,CCachedAffair*> (pCmdHeader->dwCmdSubType,pCmdHeader->dwSeqID));
        if (iter != m_cachedAffairMap.end ())
        {
            pAffairItem = (CCachedAffair*)iter->second ;
            m_cachedAffairMap.erase (iter);
        }
    }

    if(pAffairItem)
    {
        pAffairItem ->DoOnGotData(pData,dataLen);
        delete pAffairItem;
    }

    return 1;
    SCATCH;
    return -1;
}

int CCachedAffairMap::CheckBeOverTime(DWORD nowTime)
{
    STRY;
    list<CCachedAffair*>				listNeedRemove ;
    {
        QMutexLocker simpleLock(&m_simpleCS);
        if (m_cachedAffairMap.size () < 1)
            return 1;

        map<UINT64, CCachedAffair*>::iterator iter = m_cachedAffairMap.begin ();
        iter = find_if (iter ,m_cachedAffairMap.end (),CCachedAffairMap::CBeOverTime<UINT64,CCachedAffair*> (nowTime));
        while (iter != m_cachedAffairMap.end ())
        {
            CCachedAffair* pAffairItem = (CCachedAffair*)iter->second ;
            listNeedRemove.push_back (pAffairItem);
            m_cachedAffairMap.erase(iter);

            ++ iter;
            if (iter == m_cachedAffairMap.end ())
                break;
            iter = find_if (iter ,m_cachedAffairMap.end (),CCachedAffairMap::CBeOverTime<UINT64,CCachedAffair*> (nowTime));
        }
    }

    list<CCachedAffair*>::iterator iterRemove =	listNeedRemove.begin () ;
    while (iterRemove != listNeedRemove.end ())
    {
        if (*iterRemove && 2 != (*iterRemove)->DoOverTime() )
            delete (*iterRemove);
        ++ iterRemove;
    }
    return 1;
    SCATCH;
    return -1;
}
int CCachedAffairMap::ClearCachedItem()
{
    STRY;

    QMutexLocker simpleLock(&m_simpleCS);

    if(m_cachedAffairMap.size() < 1)
        return -2;

    map<UINT64,CCachedAffair*>::iterator iter = m_cachedAffairMap.begin();
    while (iter != m_cachedAffairMap.end ())
    {
        CCachedAffair* pAffairItem = (CCachedAffair*)iter->second ;
        if (pAffairItem)
        {
            delete pAffairItem;
        }
        ++ iter;
    }
    m_cachedAffairMap.clear();
    return 1;
    SCATCH;
    return -1;
}

