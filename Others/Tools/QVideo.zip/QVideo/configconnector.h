﻿#ifndef ConfigConnector_H
#define ConfigConnector_H

#include <QHostAddress>
#include <QTcpSocket>
#include <COMM_HEADER.h>
typedef struct stJtDeviceInfo
{
    QMap<QString, struct st_sean_netinterface> NetIFaceInfoS;
    int ConfigServerPort;
    QString RemoteUdpIp;
    int RemoteUdpPort;
    QString DeviceUuid;

    QString LocalIp;
}JtDeviceInfo;

class ConfigConnector : public QTcpSocket
{
    Q_OBJECT

private:
    unsigned int SeqID;
    int RecvBufLen;
    char *CmdBuf;
    int m_cmdlen;
    JtDeviceInfo m_Info;
public:
    explicit ConfigConnector(QObject *parent = 0);
    ~ConfigConnector();
    int SendCmd(const char* cmd);
    int setJtDeviceInfo(JtDeviceInfo Info);
    JtDeviceInfo getJtDeviceInfo();
signals:
    void OnRecved(char* Data, int Len);
public slots:
    void OnReciveData();
    void OnDisConnected();
};

#endif // CONNECTOR_H
