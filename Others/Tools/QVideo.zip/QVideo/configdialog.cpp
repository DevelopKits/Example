﻿#include "configdialog.h"
#include "ui_configdialog.h"
#include <QtGui>

#include "updateform.h"
#include "netconfigform.h"
#include "formsysteminfo.h"
#include "seanfileserver.h"
#include "dhconfig.h"

ConfigDialog::ConfigDialog(JtDeviceInfo DeviceInfo, QWidget *parent) : m_DeviceInfo(DeviceInfo),
    QDialog(parent),
    ui(new Ui::ConfigDialog)
{
    ui->setupUi(this);
    this->setWindowTitle(m_DeviceInfo.RemoteUdpIp);
    ConfigConn = new ConfigConnector();

    connect(ConfigConn, SIGNAL(OnRecved(char*, int)), this, SLOT(OnRecvData(char*, int)));
    connect(ConfigConn, SIGNAL(disconnected()), this, SLOT(OnClosed()));
    connect(ConfigConn, SIGNAL(connected()), this, SLOT(OnConnected()));

    //connect(ConfigConn, SIGNAL(connected()), this, SLOT(OnConnected()));
    //void error(QAbstractSocket::SocketError);

    ConfigConn->connectToHost(m_DeviceInfo.RemoteUdpIp, m_DeviceInfo.ConfigServerPort);
    ConfigConn->setJtDeviceInfo(DeviceInfo);
    contentsWidget = new QListWidget;
    contentsWidget->setViewMode(QListView::ListMode);
    contentsWidget->setIconSize(QSize(96, 84));
    contentsWidget->setMovement(QListView::Static);
    contentsWidget->setMaximumWidth(100);
    contentsWidget->setSpacing(1);
    contentsWidget->resize(100, 900);

    pagesWidget = new QStackedWidget;
    pagesWidget->addWidget(new UpdateForm(ConfigConn));//0
    pagesWidget->addWidget(new NetConfigForm(ConfigConn, m_DeviceInfo));//1
    pagesWidget->addWidget(new FormSystemInfo(ConfigConn));//2
    pagesWidget->addWidget(new Dhconfig(ConfigConn));//3


    //pagesWidget->addWidget(new UpdatePage);
    //pagesWidget->addWidget(new QueryPage);

    //QPushButton *closeButton = new QPushButton(tr("Close"));

    createIcons();
    contentsWidget->setCurrentRow(4);

    //connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));

    QHBoxLayout *horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(contentsWidget);
    horizontalLayout->addWidget(pagesWidget, 1);
    //horizontalLayout->addStretch(0);

    setLayout(horizontalLayout);


}
void ConfigDialog::OnRecvData(char* data, int len)
{
    QString ack(data);

    int cnt=0;
    int pos[2]={0};
    for(int i=0; i<ack.length(); ++i)
    {
        if(ack[i]==':')
        {
            pos[cnt] = i;
            ++cnt;
            if(cnt==2)
            {
                break;
            }
        }
    }

    if(cnt!=2)
    {
        return;
    }

    QStringList strlist;
    strlist.push_back(ack.left(pos[0]));//模块
    strlist.push_back(ack.mid(pos[0]+1, pos[1]-pos[0]-1));//命令
    strlist.push_back(ack.mid(pos[1]+1));

    if(strlist.size())
    {
        if(strlist[0]=="updaterobackup")
        {
            UpdateForm *Form = (UpdateForm *)pagesWidget->widget(0);
            Form->HandleUpdateAck(strlist);
        }
        else if(strlist[0]=="sysconfig")
        {
            FormSystemInfo *Form = (FormSystemInfo *)pagesWidget->widget(2);
            Form->HandleSystemInfoAck(strlist);
        }
        else if(strlist[0]=="storageconfig")
        {
            Dhconfig *Form = (Dhconfig *)pagesWidget->widget(3);
            Form->HandleSystemInfoAck(strlist);
        }
    }

}
void ConfigDialog::OnClosed()
{


}
void ConfigDialog::OnConnected()
{


}
ConfigDialog::~ConfigDialog()
{
    //ConfigConn->close();
    delete ConfigConn;
    delete ui;
}
void ConfigDialog::createIcons()
{
    QListWidgetItem *updateButton = new QListWidgetItem(contentsWidget);
    //updateButton->setIcon(QIcon(":/images/update.png"));
    updateButton->setText(tr("更新"));
    //updateButton->setTextAlignment(Qt::AlignHCenter);
    //updateButton->setFlags(Qt::NoItemFlags);//| Qt::ItemIsSelectable | Qt::ItemIsEnabled

    QListWidgetItem *NetButton = new QListWidgetItem(contentsWidget);
    //NetButton->setIcon(QIcon(":/images/query.png"));
    NetButton->setText(tr("网络配置"));


    QListWidgetItem *SysButton = new QListWidgetItem(contentsWidget);
    //NetButton->setIcon(QIcon(":/images/query.png"));
    SysButton->setText(tr("系统管理"));

    QListWidgetItem *ServerInfoButton = new QListWidgetItem(contentsWidget);
    //NetButton->setIcon(QIcon(":/images/query.png"));
    ServerInfoButton->setText(tr("服务器配置"));


    connect(contentsWidget,
            SIGNAL(currentItemChanged(QListWidgetItem*,QListWidgetItem*)),
            this, SLOT(changePage(QListWidgetItem*,QListWidgetItem*)));
}
void ConfigDialog::changePage(QListWidgetItem *current, QListWidgetItem *previous)
{
    if (!current)
        current = previous;
    int row = contentsWidget->row(current);
    if(row == 0)
    {
        ConfigConn->SendCmd("gb28181:getinfo");
    }
    else if(row == 2)
    {
        ConfigConn->SendCmd("plugconfig:getinfo");
    }
    else if(row == 4)
    {
        //ConfigConn->SendCmd("plugconfig:getinfo");
    }

    pagesWidget->setCurrentIndex(row);
}
