﻿#ifndef MCSERVERPEER_H
#define MCSERVERPEER_H

#include <QtGui>
#include "connector.h"
#include <map>
#include "CachedAffair.h"
using namespace std;

class CCachedAffair;
class ISystemInitProgressSubscriber
{
public:
    ISystemInitProgressSubscriber(){}
    virtual ~ISystemInitProgressSubscriber(){}

    virtual void OnLogin()=0;
    //当系统开始一个初始化动作时调用该函数
    virtual int OnSysInitProgressInfo(QString strProgressInfo)=0;
    virtual int OnSysInitFinish(bool bLoadData)=0;
};

class McServerPeer : public ITcpCallbackSink
{
public:
    static McServerPeer* GetInstance();

    virtual int OnRecvData(char* pData, int dataLen);
    virtual int OnConnected();
    virtual int OnClosed();
    //virtual int OnReConnected(UINT64 fromAddr);

    int OnRun2Time(DWORD nowTime);
    int DoCheckNetConnection(DWORD nowTime);
    void SetSrcType(WORD wSrcType);
    int AddSysInitProgressSubscriber(ISystemInitProgressSubscriber* pSbuscriber);
    int RemoveSysInitProgressSubscriber(ISystemInitProgressSubscriber* pSbuscriber);

    int DoLogin2CmsServer(ST_ICMSLOGIN_PARAM* pLoginParam);
    static int Static_OnLoginOverTime(DWORD cookie);
    static int Static_OnGotLoginData(DWORD cookie,BYTE* pData,int dataLen);
    int OnLoginOverTime();
    int OnGotLoginData(BYTE* pData,int dataLen);

    int DoLogout2CmsServer(ST_AFFAIR_CALLBACK* pAffairCallBack);

    int SendData2Mc(DWORD cmdID,char* pData,int dataLen,ST_AFFAIR_CALLBACK* pAffairCallBack
        ,int dataType = 0,int ackCmd = 0,int mainType=3);
    int SendMonitorData2Mc(DWORD cmdID,char* pData,int dataLen,ST_AFFAIR_CALLBACK* pAffairCallBack
        ,int dataType = 0,int ackCmd = 0);
    int OnStageInitFinished(int stageIdx);
    DWORD GetUserId();

    long						m_lastServerIp;
    QString						m_strICMSSign;
    DWORD						m_dwUserInfoID;
private:
    McServerPeer(void);
    virtual ~McServerPeer(void);

    ///////////////////int DoCheckUserLoginRespond(BYTE* pData, int dataLen);
    //int DealUserLoginNotify(BYTE* pData, int dataLen);
    int OnLogin();
    int PublishProgressing(QString info);
    int PublishProgressFinish(bool bLoadData);
    int DoCheckHeartBeatPacket();

    enum {DEVICE_STAGE=1,PLAN_STAGE,ALARM_STAGE,MAP_STAGE,USER_STAGE,TOUR_STAGE,LOG_STAGE
        ,SERVER_STAGE,DISK_STAGE,STORAGE_STAGE,END_STORAGE}INIT_STAGE;

    Connector*      			m_pTcpConnect2Mc;

    QString						m_strUserName;//登录用户名
    QString						m_strUserPassword;//登录用户密码

    QString						m_ServerIp;//登录服务器IP
    short						m_ServerPort;//登录服务器端口

    DWORD						m_lastRetryConnectTime;
    DWORD						m_nLastInitTime;


    //系统初始化进度信息订阅者map
    typedef	 std::map<ISystemInitProgressSubscriber*,ISystemInitProgressSubscriber*> SYSTEM_INIT_PROGRESS_SSUBSCRIBER_MAP ;  //结点变更订阅者Map类型
    SYSTEM_INIT_PROGRESS_SSUBSCRIBER_MAP m_mapSystemInitProgressSubscriber;
    QMutex                      m_simpleCS;

    QMutex                      m_simpleOrgCS;
    WORD						m_wSrcType;			//源类型
    map<UINT64,CCachedAffair*>	m_cachedAffairMap;
    int							m_nLastSendSeq;

};

#define GetMcPeer() McServerPeer::GetInstance()

#endif // MCSERVERPEER_H
