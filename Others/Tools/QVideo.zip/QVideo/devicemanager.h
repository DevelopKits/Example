#ifndef DEVICEMANAGER_H
#define DEVICEMANAGER_H
#include <QString>
#include <list>
#include <map>

#include <QMutex>
#include "COMM_HEADER.h"
using namespace std;

class IDeviceChangeSink;
class McServerPeer;

class DeviceManager
{
public:
    static DeviceManager* GetDeviceManager();
    enum MAIN_DEV_TYPE{DVR=0x0101,NVR=0x0102,IPC=0x0103,DVS=0x0104,ALARM_MACHINE=0x0105};
//	enum SUB_DEV_TYPE{CHANNEL=0x0201,INPUT=0x0202,OUTPUT=0x0203};
//	enum VIDEO_TYPE{FAST_BALL=0X0301,GUN_BALL=0X0302,HALF_BALL=0x0303};

    int DoInitialize(int stageIndex);
    int AddNodeChangeSink(IDeviceChangeSink* pSink);//注册
    int RemoveNodeChangeSink(IDeviceChangeSink* pSink);//注销
    int OnRecvData(UINT64 fromAddr, BYTE* pData, int dataLen);

    struct Product
    {
        QString					ProductName;
        int						EquType;
        int						FactoryId;
    };
    struct Equipment
    {
        QString                 FactoryName;
        QString					EquTypeName;
    };
    struct OrgNode
    {
        int						OrgNodeId;
        QString					ICMSSign;
        int						ICMSSignOrgNodeId;
        QString					OrgNodeName;
        int						HigherOrgNodeId;
        int						OrgNodeLevel;
    };
    struct PreSetPoint
    {
        int						presetId;
        int                     presetSeq;
        QString					presetName;
    };
    struct CurisePoint
    {
        int						curiseId;
        QString					curiseName;
    };

    struct DevInfoUnit
    {
        struct MainDevInfo
        {
            int					EquId;
            QString             FactoryName;
            QString				SpeDevTypeId;
            QString				MainDevName;
            QString				IpAddr;
            int					Port;
            QString				UserName;
            QString				PassWord;
            int                 ChannelNum;
            int                 InputNum;
            int                 OutputNum;
            QString             Extend;
            int					CtlgId;
        };

        struct SubDevInfo
        {
            SubDevInfo():m_pMainDevInfo(NULL),SubEquId(0),SubEquSeq(0),SubType(0)
            {}
            DevInfoUnit*		m_pMainDevInfo;		//主设备
            int					SubEquId;			//子设备号
            int					SubType;			//子设备类型
            int					SubEquSeq;			//子设备序号
            int					OrgNodeId;			//所在节点
            int					UnitEquipmentCode;	//全局唯一编码
            QString				SubDevName;			//子设备名
        };

        struct SubVideoDevInfo
        {
            SubVideoDevInfo():DetailedType(0),BeSuportPTZ(0),BeWithButton(0),BeWithDemist(0),BeWithRainBrush(0){}

            struct SubDevInfo	SubInfo;

            int					DetailedType;
            int					BeSuportPTZ;
            int					BeWithButton;
            int					BeWithDemist;
            int					BeWithRainBrush;
            QString				DetailSet;
            list<PreSetPoint>	presetList;
            list<CurisePoint>	curiseList;
        };

        struct SubInOutputDevInfo
        {
            SubInOutputDevInfo():bInput(FALSE){}

            struct SubDevInfo	SubInfo;

            QString				DetailedDesc;
            QString				DetailSet;
            BOOL				bInput;
        };

        MainDevInfo					m_mainDevInfo;
        list<SubVideoDevInfo>		m_subVideoDevList;
        list<SubInOutputDevInfo>	m_subInputDevList;
        list<SubInOutputDevInfo>	m_subOutputDevList;
    };

    //添加组织节点信令：ADD_ORG_NODE_REQ
    int AddOrgNode(int OSuperiorID,QString& OName);
    static int Static_OnGotAddOrgNodeAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnGotAddOrgNodeAck(BYTE* pData,int dataLen);


    //修改组织节点名称信令：MOD_ORG_NODE_NAME_REQ
    int ModifyOrgNodeName(int OrganizeID,QString& OName);
    static int Static_OnGotModifyOrgNodeNameAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnGotModifyOrgNodeNameAck(BYTE* pData,int dataLen);

    //删除组织节点信令：RMV_ORG_NODE_REQ
    int RemoveOrgNode(int OrganizeID);
    static int Static_OnRemoveOrgNodeAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnRemoveOrgNodeAck(BYTE* pData,int dataLen);

    //查询主设备属性信令：LST_MAIN_DEVDICE_REQ
    int QueryMainDeviceReq(int EquipmentID);
    static int Static_OnQueryMainDeviceAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnQueryMainDeviceAck(BYTE* pData,int dataLen);

    //添加主设备信令：ADD_MAIN_DEVDICE_REQ
    int AddMainDeviceReq(DevInfoUnit* pDevInfoUnit);
    static int Static_OnAddMainDeviceReqAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnAddMainDeviceReqAck(BYTE* pData,int dataLen);

    //修改设备信令：MOD_DEVDICE_REQ
    int ModifyDeviceReq(DevInfoUnit* pDevInfoUnit);
    static int Static_OnModifyDeviceAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnModifyDeviceAck(BYTE* pData,int dataLen);

    //修改子设备信令：MOD_SUB_DEVDICE_REQ
    int ModifySubDeviceReq(DevInfoUnit* pDevInfoUnit,DevInfoUnit::SubDevInfo* pSubInfo, int oldCtlgId, int newCtlgId, int SpecficType);
    static int Static_OnModifySubDeviceAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnModifySubDeviceAck(BYTE* pData,int dataLen);

    //删除子设备信令：RMV_SUB_DEVDICE_REQ
    int RemoveSubDeviceReq(DevInfoUnit * pDevInfoUnit,DevInfoUnit::SubVideoDevInfo * pSubInfo);
    static int Static_OnRemoveSubDeviceAck(DWORD cookie,BYTE * pData,int dataLen);
    int OnRemoveSubDeviceAck(BYTE * pData,int dataLen);

    //删除主设备信令：RMV_MAIN_DEVDICE_REQ
    int RemoveMainDeviceReq(DevInfoUnit* pDevInfoUnit);
    static int Static_OnRemoveMainDeviceAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnRemoveMainDeviceAck(BYTE* pData,int dataLen);

    //连接设备：CONNECT_EQU_REQ
    int ConnectDeviceReq(DevInfoUnit* pDevInfoUnit);
    static int Static_OnConnectDeviceAck(DWORD cookie,BYTE* pData,int dataLen);
    int OnConnectDeviceAck(BYTE* pData,int dataLen);

    DeviceManager::DevInfoUnit::SubVideoDevInfo* GetSubDev(int devId);//获取视频子设备
    DeviceManager::DevInfoUnit::SubInOutputDevInfo* GetSubInOutputDev(int nSubEquId);//获取输入输出子设备


    map<QString, QString>   m_factoryMap;
    map<int,Product>		m_productList;
    list<Equipment>			m_EquipmentList;
    map<int,OrgNode>		m_OrgNodeList;

    map<int,DevInfoUnit>	m_devInfoList;
    QMutex                  m_devInfoLock;

    DevInfoUnit				m_lastDevInfo;
    list<DevInfoUnit::SubVideoDevInfo*>	m_reqPresetList;
    DevInfoUnit::SubVideoDevInfo*		m_pLastSubDev;

private:
    DeviceManager(void);
    ~DeviceManager(void);

    int NotifyOrgnizeChange(OrgNode* pOrgNode,int changeType);
    int NotifyDeviceChange(void* pDevInfo,int changeType);

    static int Static_OnAffairOverTime(DWORD cookie);
    int DoGetOrganizeTree(int nOrganizeParentId = -1, int nOrganizeId = -1);
    static int Static_OnGetOrganizeInfoData(DWORD cookie,BYTE* pData,int dataLen);
    int OnGetOrganizeInfoData(BYTE* pData,int dataLen);
    int DoGetEquInfo(int nEquId = -1);
    static int Static_OnGetEquInfoData(DWORD cookie,BYTE* pData,int dataLen);
    int OnGetEquInfoData(BYTE* pData,int dataLen);
    int DoGetSubEquInfo(int nSubEquId = -1);
    static int Static_OnGetSubEquInfoData(DWORD cookie,BYTE* pData,int dataLen);
    int OnGetSubEquInfoData(BYTE* pData,int dataLen);

    //获取设备类型型号信令：GET_SPE_DEVICE_TYPE_REQ
    int DoGetDeviceType();
    static int Static_OnGotDeviceType(DWORD cookie,BYTE* pData,int dataLen);
    int OnGotDeviceType(BYTE* pData,int dataLen);

    int DoRequestPreset(int SubEquId);
    static int Static_OnGotPresetOvertime(DWORD cookie);
    static int Static_OnGotPreset(DWORD cookie,BYTE* pData,int dataLen);
    int OnGotPresetOvertime();
    int OnGotPreset(BYTE* pData,int dataLen);

    int DoRequestCurise(int SubEquId);
    static int Static_OnGotCuriseOvertime(DWORD cookie);
    static int Static_OnGotCurise(DWORD cookie,BYTE* pData,int dataLen);
    int OnGotCuriseOvertime();
    int OnGotCurise(BYTE* pData,int dataLen);

    McServerPeer*				m_pMcServerPeer;
    int							m_stageIndex;
    list<IDeviceChangeSink*>	m_devChangeSinkList;
    QMutex                      m_simpleCS;

    QString						m_lastOrgName;
    int                         m_lastLevel;

    QString                     m_lastSubEquName;
    int                         m_lastEquId;
    int                         m_lastOldCtlgId;
    int                         m_lastNewCtlgId;

    //set<long int>				m_Cookie;//记录cookie值，只有
};

class IDeviceChangeSink
{
public:
    enum {ADD=0,MODIFY,REMOVE,REMOVE_SUB,MODIFY_SUB}CHANGE_TYPE;
    virtual int OnOrgnizeNodeChange(DeviceManager::OrgNode* pOrgNode,int changeType){return 0;}
    virtual int OnDeviceChange(void* pDevInfo,int changeType){return 0;}

    //通知1、获取到预置点、巡航
    virtual int OnDeviceNotify(int Type, void* Data){return 0;}
};

#define GetDevManager() DeviceManager::GetDeviceManager()

#endif // DEVICEMANAGER_H
