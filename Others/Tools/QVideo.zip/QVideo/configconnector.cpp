﻿#include "configconnector.h"
#include <string.h>
#include <QMessageBox>
ConfigConnector::ConfigConnector(QObject *parent) :
    QTcpSocket(parent), m_cmdlen(0)
{
    RecvBufLen = 4096;
    CmdBuf = new char[RecvBufLen*8];

    QObject::connect(this, SIGNAL(readyRead()), this, SLOT(OnReciveData()));
    QObject::connect(this, SIGNAL(disconnected()), this, SLOT(OnDisConnected()));
    //QObject::connect(this, SIGNAL(connected()), this, SLOT(OnConnected()));
}
ConfigConnector::~ConfigConnector()
{
    delete CmdBuf;
}

void ConfigConnector::OnDisConnected()
{
    QMessageBox::about(NULL, tr("失败"), tr("disconnect"));
    return;
}
void ConfigConnector::OnReciveData()
{
    while(bytesAvailable()>0)
    {
        if(m_cmdlen==0)
        {
            if(bytesAvailable()<2)
            {
                return ;
            }
            unsigned char bylen[2];
            if(-1==read((char*)bylen, sizeof(bylen)))
            {
                return;
            }

            m_cmdlen = bylen[1] << 8 | bylen[0];
        }

        if(bytesAvailable()<m_cmdlen)
        {
            return;
        }

        int len = read((char *)CmdBuf, m_cmdlen);
        if(-1 == len)
        {
           return;
        }

        emit OnRecved(CmdBuf, m_cmdlen);

        m_cmdlen = 0;
        //CmdBuf[cmdlen] = 0;
    }

    //emit OnRecved(CmdBuf, m_cmdlen);
}
int ConfigConnector::SendCmd(const char* buffer)
{
    unsigned short head = strlen(buffer)+1;

    int err = write((const char*)&head, sizeof(head));
    if(err<0)
    {
        return err;
    }

    write(buffer, head);
    if(err<0)
    {
        return err;
    }

    return err;
}
int ConfigConnector::setJtDeviceInfo(JtDeviceInfo Info)
{
    m_Info = Info;
    return 0;
}
JtDeviceInfo ConfigConnector::getJtDeviceInfo()
{
    return m_Info;
}
