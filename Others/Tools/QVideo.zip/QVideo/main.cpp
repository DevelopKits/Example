﻿#include "mainwindow.h"
#include "logindialog.h"
#include <QApplication>

#include <QHostAddress>
#include <QTcpSocket>
#include <QTextCodec>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QTextCodec *codec = QTextCodec::codecForName("GB2312");
    //QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);
    QTextCodec::setCodecForTr(codec);

    QTextCodec::setCodecForTr(QTextCodec::codecForName("system"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("system"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("system"));

    //QTcpSocket *tcpSocket = new QTcpSocket();
    //tcpSocket->connectToHost("10.6.30.240", 33322);

    Connector* Conn = new Connector();

    LoginDialog *L = new LoginDialog(Conn);
    L->show();
    if(L->exec()==QDialog::Accepted)
    {
        delete L;
        MainWindow w(Conn);
        w.showMaximized();
        return a.exec();
    }
    else
        return 0;
}
