#include "review.h"
#include "ui_review.h"

VReview::VReview(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Review)
{
    ui->setupUi(this);
}

VReview::~VReview()
{
    delete ui;
}
