#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "view.h"
#include "review.h"
//#include "ui_view.h"
//#include "ui_review.h"
#include <QtGui>
MainWindow::MainWindow(Connector* Conn, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_pConn(Conn)
{
    ui->setupUi(this);
    CreateActions();

    //pViewWidget = new QWidget(ui->stackedWidget);
    //pReviewWidget = new QWidget(ui->stackedWidget);
    pView = new VView(ui->stackedWidget, Conn);
    pReview = new VReview(ui->stackedWidget);
    //pView->setupUi(ui->stackedWidget);
    //pReview->setupUi(ui->stackedWidget);
    ui->stackedWidget->addWidget(pView);
    ui->stackedWidget->addWidget(pReview);

    setCentralWidget(ui->stackedWidget);
    ui->stackedWidget->setCurrentIndex(2);


}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::CreateActions()
{
    ViewAction = new QAction(QIcon(":/images/view.png"),tr("&view"), this);
    ViewAction->setShortcut(tr("View"));
    ViewAction->setStatusTip(tr("View Video"));
    connect(ViewAction, SIGNAL(triggered()), this, SLOT(View()));
    ui->toolBar->addAction(ViewAction);

    ReviewAction = new QAction(QIcon(":/images/review.png"),tr("&Review"), this);
    ReviewAction->setShortcut(tr("Review"));
    ReviewAction->setStatusTip(tr("Review Video"));
    connect(ReviewAction, SIGNAL(triggered()),this, SLOT(Review()));
    ui->toolBar->addAction(ReviewAction);
}
void MainWindow::View()
{
    //QMessageBox::about(NULL, "dd", "dsdf");
    ui->stackedWidget->setCurrentIndex(2);
}
void MainWindow::Review()
{
    ui->stackedWidget->setCurrentIndex(3);
}
