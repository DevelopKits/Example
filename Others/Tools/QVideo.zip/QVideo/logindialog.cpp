﻿#include "logindialog.h"
#include "ui_logindialog.h"
#include <qvalidator.h>
#include <QMessageBox>
#include "COMM_HEADER.h"

#include "mcserverpeer.h"
#include "configdialog.h"
#include "MutilCastCmd.h"
#include <QtXml>
#include <QTime>
#include <time.h>

#include <QNetworkInterface>
#include "dialogenterip.h"

#define JT_C_IP "224.0.0.87" //客户端的多播组
#define JT_S_IP "224.0.0.88" //服务端的多播组

LoginDialog::LoginDialog(Connector* Conn, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog),
    m_pConn(Conn)
{
    ui->setupUi(this);
    int width = this->geometry().width();
        int height = this->geometry().height();
        this->setFixedSize(width,height); //设置窗体固定大小

    qsrand(time(NULL));
    m_uMagic = qrand();

    m_SearchUdpSocket = new QUdpSocket(this);
    if (!m_SearchUdpSocket->bind()){//60001, QUdpSocket::ShareAddress
        qErrnoWarning("Binding error!");
        //exit(1);
    }

    m_SearchUdpSocket->localPort();
    const QHostAddress groupAddress(JT_C_IP);
    m_SearchUdpSocket->joinMulticastGroup(groupAddress);

    connect(m_SearchUdpSocket, SIGNAL(readyRead()),
            this, SLOT(GetSearchResponsDatagrams()));

    QValidator* validator = new QIntValidator( 4096, 65535, this );
    ui->lineEditPort->setValidator(validator);

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
    validator = new QRegExpValidator(regx);
    ui->lineEditIp->setValidator(validator);
    ui->lineEdit_Ipv4->setValidator(validator);
    ui->lineEdit_Mask->setValidator(validator);
    ui->lineEdit_NetGate->setValidator(validator);

    GetMcPeer()->AddSysInitProgressSubscriber(this);

    QList<QHostAddress> AddressS = QNetworkInterface().allAddresses();
    for(int i=0; i<AddressS.size(); i++)
    {
        QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
        if(AddressS[i].protocol() == QAbstractSocket::IPv4Protocol)
        {
            if(regx.exactMatch(AddressS[i].toString()) && AddressS[i].toString()!="127.0.0.1")
            {
                ui->comboBoxloginlocalip->addItem(AddressS[i].toString());
            }
        }
    }
}

LoginDialog::~LoginDialog()
{
    delete m_SearchUdpSocket;
    GetMcPeer()->RemoveSysInitProgressSubscriber(this);
    delete ui;
}

void LoginDialog::on_pushButtonLogin_clicked()
{
    ST_ICMSLOGIN_PARAM LoginParam;
    LoginParam.cmsServerIp = ui->lineEditIp->text();
    LoginParam.cmsServerPort = ui->lineEditPort->text().toInt();
    LoginParam.userName = ui->lineEditUser->text();
    LoginParam.userPass = ui->lineEditPassword->text();
    GetMcPeer()->DoLogin2CmsServer(&LoginParam);
}

void LoginDialog::OnLogin()
{
    accept();
}
int LoginDialog::OnSysInitProgressInfo(QString strProgressInfo)
{

    return 0;
}
int LoginDialog::OnSysInitFinish(bool bLoadData)
{

    return 0;
}
/*void LoginDialog::OnReciveData(char* Data, int Len)
{

}*/

struct stmsend
{
    char info[16];
    char mip[32];
    int mport;
};

void LoginDialog::on_SearchButton_clicked()
{
    ui->DeviceListWidget->clear();
    m_DeviceInfoS.clear();
    m_Order = 0;

    ui->lineEdit_Ipv4->clear();
    ui->lineEdit_Mask->clear();
    ui->lineEdit_NetGate->clear();
    ui->lineEditnetname->clear();

    QHostAddress mcast_addr(JT_S_IP);
    QHostAddress mcast_addr2(JT_C_IP);

    struct MuiltCastCmd Cmd;
    Cmd.uMagic = m_uMagic;
    Cmd.nCmdType = SEAN_GET_ADDR_INFO_REQ;
    Cmd.nCmdSeq = 0;
    Cmd.uIp[0] = mcast_addr2.toIPv4Address();
    Cmd.uRPort =  m_SearchUdpSocket->localPort();
    Cmd.nContentSize = 0;
    Cmd.cChecksum = 0;

    m_SearchUdpSocket->writeDatagram((const char *)&Cmd, sizeof(Cmd)+Cmd.nContentSize, mcast_addr, 62626);
}
void LoginDialog::HandleUdpCmd_GetAddrInfoRsp(struct MuiltCastCmd *Cmd)
{
    char* xml = (char*)(Cmd+1);
    QString s(xml);

    QDomDocument doc;
    QString errorStr;
    int errorLine;
    int errorColumn;

    if (!doc.setContent(s, false, &errorStr, &errorLine,
                        &errorColumn)) {
    }

    QDomElement root = doc.documentElement();
    if(root.tagName()!="ExGetAddrInfoRsp")
    {
        //
        return;
    }

    JtDeviceInfo DeviceInfo;
    DeviceInfo.RemoteUdpPort = root.attribute("configport").toInt();

    QString HostName = root.attribute("HostName");
    HostName = QString("%1(%2)").arg(HostName).arg(++m_Order);

    DeviceInfo.DeviceUuid = root.attribute("Uuid");

    QDomElement NetInterfaceListNode  = root.firstChildElement("NetInterfaceList");
    if(NetInterfaceListNode.isNull())
    {
         return;
    }

    QMap<QString, struct st_sean_netinterface> MapOneDev;
    for (QDomElement NetInterfaceNode=NetInterfaceListNode.firstChildElement("NetInterface")
         ; !NetInterfaceNode.isNull()
         ; NetInterfaceNode = NetInterfaceNode.nextSiblingElement("NetInterface"))
    {
        struct st_sean_netinterface netinterfaceinfo;

        netinterfaceinfo.name = NetInterfaceNode.text().trimmed();
        if(netinterfaceinfo.name=="lo") continue;

        netinterfaceinfo.state = NetInterfaceNode.attribute("state").toInt();
        netinterfaceinfo.ipv4 = NetInterfaceNode.attribute("ipv4");
        netinterfaceinfo.netmask = NetInterfaceNode.attribute("netmask");
        netinterfaceinfo.netgate = NetInterfaceNode.attribute("netgate");

        DeviceInfo.NetIFaceInfoS[netinterfaceinfo.name]=netinterfaceinfo;

        for (QDomElement SubNetInterfaceNode=NetInterfaceNode.firstChildElement("SubNetInterface")
             ; !SubNetInterfaceNode.isNull()
             ; SubNetInterfaceNode = SubNetInterfaceNode.nextSiblingElement("SubNetInterface"))
        {
            struct st_sean_sub_netinterface sub_netinterface;
            sub_netinterface.name = SubNetInterfaceNode.attribute("name");
            sub_netinterface.ipv4 = SubNetInterfaceNode.attribute("ipv4");
            sub_netinterface.netmask = SubNetInterfaceNode.attribute("netmask");
            DeviceInfo.NetIFaceInfoS[netinterfaceinfo.name].SubInterfaceS[sub_netinterface.name] = sub_netinterface;
        }
    }

    m_DeviceInfoS[HostName] = DeviceInfo;

    ui->DeviceListWidget->clear();

    QMap<QString, JtDeviceInfo>::iterator iterx = m_DeviceInfoS.begin();
    for(; iterx!=m_DeviceInfoS.end(); ++iterx)
    {
        QMap<QString, struct st_sean_netinterface>::iterator iter2 =iterx.value().NetIFaceInfoS.begin();
        for(; iter2!=iterx.value().NetIFaceInfoS.end(); ++iter2)
        {
            if(iter2->ipv4.length())
                ui->DeviceListWidget->addItem(new QListWidgetItem(iterx.key() + QString(":") + iter2->name + QString(":") + iter2->ipv4));
        }
    }
}
void LoginDialog::GetSearchResponsDatagrams()
{
    while (m_SearchUdpSocket->hasPendingDatagrams()) {

        QByteArray ResponsDatagrams;
        ResponsDatagrams.resize(m_SearchUdpSocket->pendingDatagramSize());
        QHostAddress address;
        quint16 port;
        m_SearchUdpSocket->readDatagram(ResponsDatagrams.data(), ResponsDatagrams.size(), &address, &port);
        m_SearchUdpSocket->peerAddress();

        struct MuiltCastCmd *Cmd = (struct MuiltCastCmd *)ResponsDatagrams.data();
        if(Cmd->uMagic==m_uMagic)
        {
            if(Cmd->nCmdType==SEAN_GET_ADDR_INFO_RSP)
            {
                HandleUdpCmd_GetAddrInfoRsp(Cmd);
            }
        }
    }
}

void LoginDialog::on_ConfigButton_clicked()
{
    QListWidgetItem *item = ui->DeviceListWidget->currentItem();
    if(item)
    {
        QStringList strlist = item->text().split(":");
        //m_DeviceInfoS.find(strlist[0]).value(). .find(strlist[1]).value();

        QMap<QString, JtDeviceInfo>::iterator iter1;
        iter1 = m_DeviceInfoS.find(strlist[0]);
        if(iter1!=m_DeviceInfoS.end())
        {
            QMap<QString, struct st_sean_netinterface>::iterator iter2 = iter1.value().NetIFaceInfoS.find(strlist[1]);
            if(iter2!=iter1.value().NetIFaceInfoS.end())
            {
                JtDeviceInfo DeviceInfo;
                DeviceInfo.ConfigServerPort = iter1.value().RemoteUdpPort;
                DeviceInfo.RemoteUdpIp = strlist[2];
                DeviceInfo.NetIFaceInfoS = iter1.value().NetIFaceInfoS;
                DeviceInfo.LocalIp =ui->comboBoxloginlocalip->itemText(ui->comboBoxloginlocalip->currentIndex());;
                ConfigDialog Dialog(DeviceInfo);
                Dialog.setModal(true);
                Dialog.show();
                if(Dialog.exec()==QDialog::Accepted)
                {

                }
            }
        }
    }
    else
    {
        //没有选择，就要求手动输入一个
        DialogEnterIp EnterIp;
        EnterIp.setModal(true);
        EnterIp.show();
        if(EnterIp.exec()==QDialog::Accepted)
        {
            JtDeviceInfo DeviceInfo;
            DeviceInfo.ConfigServerPort = 52626;
            DeviceInfo.RemoteUdpIp = EnterIp.m_IP;
            DeviceInfo.NetIFaceInfoS;// = iter1.value().NetIFaceInfoS;
            DeviceInfo.LocalIp =ui->comboBoxloginlocalip->itemText(ui->comboBoxloginlocalip->currentIndex());;
            ConfigDialog Dialog(DeviceInfo);
            Dialog.setModal(true);
            Dialog.show();
            if(Dialog.exec()==QDialog::Accepted)
            {

            }
        }
    }

}

void LoginDialog::on_DeviceListWidget_itemClicked(QListWidgetItem *item)
{
    QStringList strlist = item->text().split(":");

    struct st_sean_netinterface NetIFaceInfo=
    m_DeviceInfoS.find(strlist[0]).value().NetIFaceInfoS.find(strlist[1]).value();

    ui->lineEdit_Ipv4->setText(NetIFaceInfo.ipv4);
    ui->lineEdit_Mask->setText(NetIFaceInfo.netmask);
    ui->lineEdit_NetGate->setText(NetIFaceInfo.netgate);
    ui->lineEditnetname->setText(NetIFaceInfo.name);
}

void LoginDialog::on_pushButton_modifyip_clicked()
{
//修改ip
//<?xml version=\"1.0\" encoding=\"gb2312\"?>\n"
//<ExSetAddrInfoReq>
//	<NetInterfaceList>
//		<NetInterface state="0" ipv4="192.168.3.4" ipv6=""  netmask="255.255.255.0" netgate="192.168.13.1" dns="192.168.13.1" >eth0</NetInterface>
//	</NetInterfaceList>
//<ExSetAddrInfoReq/>
    QListWidgetItem *item = ui->DeviceListWidget->currentItem();
    if(item==NULL)
    {
        return;
    }

    QStringList strlist = item->text().split(":");

    QMap<QString, JtDeviceInfo>::iterator iter1;
    iter1 = m_DeviceInfoS.find(strlist[0]);
    if(iter1==m_DeviceInfoS.end())
    {
        return;
    }

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");

    if(regx.exactMatch(ui->lineEdit_Ipv4->text())==false)
    {
        QMessageBox::about(NULL, tr("ip地址错误"), tr("ip地址错误"));
        return;
    }

    if(regx.exactMatch(ui->lineEdit_Mask->text())==false)
    {
        QMessageBox::about(NULL, tr("掩码错误"), tr("掩码错误"));
        return;
    }

    if(regx.exactMatch(ui->lineEdit_NetGate->text())==false)
    {
       //QMessageBox::about(NULL, tr("网关错误"), tr("网关错误"));
       // return;
    }

    if(QMessageBox::information(NULL, "确认", "确定要修改ip?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QHostAddress NewIP(ui->lineEdit_Ipv4->text());
    QHostAddress NewMask(ui->lineEdit_Mask->text());

    quint32 dd = NewIP.toIPv4Address();
    quint32 mm = NewMask.toIPv4Address();

    quint32 test = dd&mm;

    if(ui->lineEdit_NetGate->text().size())
    {
        //填写了网关的，就要验证网路是否一致
        QHostAddress NeGate(ui->lineEdit_NetGate->text());
        quint32 gg = NeGate.toIPv4Address();
        quint32 testg = gg&mm;
        if(testg!=test)
        {
            //网络不一致，返回
            QMessageBox::about(NULL, tr("网关错误"), tr("网关错误"));
            return;
        }
    }

    //检查是否是双网络，双网络时不能处于同一网络中
   // for(QMap<QString, JtDeviceInfo>::Iterator iter2 = m_DeviceInfoS.begin(); iter2!=m_DeviceInfoS.end(); ++iter2)
   // {
   //     QString tt1 =iter2.key();

  //      tt1 =tt1;

        for(QMap<QString, struct st_sean_netinterface>::Iterator iter3 = iter1.value().NetIFaceInfoS.begin()
            ; iter3!=iter1.value().NetIFaceInfoS.end(); ++iter3)
        {
            QString sd = iter3.key();
            sd = sd;
            if(iter3.key()!=strlist[1])//不是本网口的记录，检查是否要改为同一网段的，要禁止
            {
                QHostAddress NewIP2(iter3.value().ipv4);
                QHostAddress NewMask2(iter3.value().netmask);
                quint32 dd2 = NewIP2.toIPv4Address();
                quint32 mm2 = NewMask2.toIPv4Address();
                quint32 test2 = dd2&mm2;
                if(test==test2)//同一网段，禁止修改
                {
                    QMessageBox::about(NULL, tr(" 同一网段，禁止修改 "), tr(" 同一网段，禁止修改 " ));
                    return;
                }

                QString newGate_ = ui->lineEdit_NetGate->text();
                if(newGate_.size())//双网口时，填写了网关，那么另一个网口就不能有网关
                {
                    if(iter3.value().netgate.size())
                    {
                        //有网管了，报错，
                        QMessageBox::about(NULL, tr(" 另一网口已填写网关 "), tr(" 另一网口已填写网关 " ));
                        return;
                    }
                }
            }
        }
   // }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExSetAddrInfoReq></ExSetAddrInfoReq>"),false);

    QDomElement root = doc.documentElement();
    root.setAttribute("Uuid", iter1.value().DeviceUuid);

    QDomElement NetInterfaceListNode = doc.createElement("NetInterfaceList");
    doc.documentElement().appendChild(NetInterfaceListNode);
    QDomElement NetInterface = doc.createElement("NetInterface");

    NetInterface.appendChild(doc.createTextNode(ui->lineEditnetname->text()));
    NetInterface.setAttribute("state", 0);
    NetInterface.setAttribute("ipv4", ui->lineEdit_Ipv4->text());
    NetInterface.setAttribute("ipv6", 0);
    NetInterface.setAttribute("netmask", ui->lineEdit_Mask->text());
    NetInterface.setAttribute("netgate", ui->lineEdit_NetGate->text());
    NetInterface.setAttribute("dns", 0);
    NetInterfaceListNode.appendChild(NetInterface);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QByteArray ba = XMLStr.toLatin1();

    char* cCmd =new char[sizeof(struct MuiltCastCmd)+ba.length()];

    QHostAddress mcast_addr(JT_S_IP);
    QHostAddress mcast_addr2(JT_C_IP);

    struct MuiltCastCmd *pMuiltCastCmd = (struct MuiltCastCmd *)cCmd;
    pMuiltCastCmd->uMagic = 0x31239000;
    pMuiltCastCmd->nCmdType = SEAN_SET_ADDR_INFO_REQ;
    pMuiltCastCmd->nCmdSeq = 0;
    pMuiltCastCmd->uIp[0] = mcast_addr2.toIPv4Address();
    pMuiltCastCmd->uRPort =  m_SearchUdpSocket->localPort();
    pMuiltCastCmd->nContentSize = ba.length();
    pMuiltCastCmd->cChecksum = 0;

    memcpy(pMuiltCastCmd+1, ba.data(), ba.length());

    m_SearchUdpSocket->writeDatagram((const char *)cCmd, sizeof(struct MuiltCastCmd)+pMuiltCastCmd->nContentSize, mcast_addr, 62626);
}

void LoginDialog::on_pushButton_reboot_clicked()
{
    QListWidgetItem *item = ui->DeviceListWidget->currentItem();
    if(item==NULL)
    {
        return;
    }

    QStringList strlist = item->text().split(":");

    QMap<QString, JtDeviceInfo>::iterator iter1;
    iter1 = m_DeviceInfoS.find(strlist[0]);
    if(iter1==m_DeviceInfoS.end())
    {
        return;
    }

    if(QMessageBox::information(NULL, "确认", "确定要重启 ?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExRebootReq></ExRebootReq>"),false);

    QDomElement root = doc.documentElement();
    root.setAttribute("Uuid", iter1.value().DeviceUuid);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QByteArray ba = XMLStr.toLatin1();

    char* cCmd =new char[sizeof(struct MuiltCastCmd)+ba.length()];

    QHostAddress mcast_addr(JT_S_IP);
    QHostAddress mcast_addr2(JT_C_IP);

    struct MuiltCastCmd *pMuiltCastCmd = (struct MuiltCastCmd *)cCmd;
    pMuiltCastCmd->uMagic = 0x31239000;
    pMuiltCastCmd->nCmdType = SEAN_SET_REBOOT_REQ;
    pMuiltCastCmd->nCmdSeq = 0;
    pMuiltCastCmd->uIp[0] = mcast_addr2.toIPv4Address();
    pMuiltCastCmd->uRPort =  m_SearchUdpSocket->localPort();
    pMuiltCastCmd->nContentSize = ba.length();
    pMuiltCastCmd->cChecksum = 0;

    memcpy(pMuiltCastCmd+1, ba.data(), ba.length());

    m_SearchUdpSocket->writeDatagram((const char *)cCmd, sizeof(struct MuiltCastCmd)+pMuiltCastCmd->nContentSize, mcast_addr, 62626);
}

void LoginDialog::on_pushButton_halt_clicked()
{
    QListWidgetItem *item = ui->DeviceListWidget->currentItem();
    if(item==NULL)
    {
        return;
    }

    QStringList strlist = item->text().split(":");

    QMap<QString, JtDeviceInfo>::iterator iter1;
    iter1 = m_DeviceInfoS.find(strlist[0]);
    if(iter1==m_DeviceInfoS.end())
    {
        return;
    }

    if(QMessageBox::information(NULL, "确认", "确定要关机 ?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExHaltReq></ExHaltReq>"),false);

    QDomElement root = doc.documentElement();
    root.setAttribute("Uuid", iter1.value().DeviceUuid);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QByteArray ba = XMLStr.toLatin1();

    char* cCmd =new char[sizeof(struct MuiltCastCmd)+ba.length()];

    QHostAddress mcast_addr(JT_S_IP);
    QHostAddress mcast_addr2(JT_C_IP);

    struct MuiltCastCmd *pMuiltCastCmd = (struct MuiltCastCmd *)cCmd;
    pMuiltCastCmd->uMagic = 0x31239000;
    pMuiltCastCmd->nCmdType = SEAN_SET_HALT_REQ;
    pMuiltCastCmd->nCmdSeq = 0;
    pMuiltCastCmd->uIp[0] = mcast_addr2.toIPv4Address();
    pMuiltCastCmd->uRPort =  m_SearchUdpSocket->localPort();
    pMuiltCastCmd->nContentSize = ba.length();
    pMuiltCastCmd->cChecksum = 0;

    memcpy(pMuiltCastCmd+1, ba.data(), ba.length());

    m_SearchUdpSocket->writeDatagram((const char *)cCmd, sizeof(struct MuiltCastCmd)+pMuiltCastCmd->nContentSize, mcast_addr, 62626);
}
