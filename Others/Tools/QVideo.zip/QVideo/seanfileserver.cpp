#include "seanfileserver.h"
#include <QUuid>
#include <QCryptographicHash>
#include <QFile>
#include <QFileInfo>
#include <QNetworkInterface>
#include <QRegExp>
#include <QMessageBox>

SeanFilePeer::SeanFilePeer(QTcpSocket *Conn, QObject *parent)
    :m_Conn(Conn),QObject(parent)
{
    m_GetId = 0;

    QObject::connect(m_Conn, SIGNAL(readyRead()), this, SLOT(OnReciveData()));
    QObject::connect(m_Conn, SIGNAL(disconnected()), this, SLOT(OnDisConnected()));
    QObject::connect(m_Conn, SIGNAL(bytesWritten(qint64)), this, SLOT(OnSendData(qint64)));
}
SeanFilePeer::~SeanFilePeer()
{


}

void SeanFilePeer::OnReciveData()
{
    if(m_GetId==0)
    {
        QByteArray uuid = m_Conn->read(38+1);//{6838e60a-2306-4008-83d9-d778aa7741b8}\0
        qDebug() << "QString(uuid)"<<QString(uuid);
        QMap<QString, SeanUploadFileInfo>::iterator iter = SeanFileServer::Instance()->m_UploadFileInfoS.find(QString(uuid));
        if(iter!=SeanFileServer::Instance()->m_UploadFileInfoS.end())
        {
            m_UploadFileInfo = iter.value();
            if(m_UploadFileInfo.upordown==2)
            {
                StartSendFile(m_UploadFileInfo.m_FilePath);
                SendFile(localFile, m_SendCtrlInfo);
            }
            else if(m_UploadFileInfo.upordown==3)
            {
                StartRecvFile(m_UploadFileInfo.m_FilePath);
                RecvFile(localFile, m_SendCtrlInfo);
            }
        }
        m_GetId = 1;
    }
    else
    {
        if(m_UploadFileInfo.upordown==2)
        {
            SendFile(localFile, m_SendCtrlInfo);
        }
        else if(m_UploadFileInfo.upordown==3)
        {
            RecvFile(localFile, m_SendCtrlInfo);
        }

    }
}
void SeanFilePeer::OnDisConnected()
{
    qDebug() << "SeanFilePeer";

    if(m_SendCtrlInfo.totalBytes!=m_SendCtrlInfo.bytesWritten)
        m_UploadFileInfo.Owner->OnSeanFileSendError(-1);
    delete this;
}
void SeanFilePeer::OnSendData(qint64 bytes)
{
    if(m_UploadFileInfo.upordown==2)
    {
        m_SendCtrlInfo.bytesWritten+=bytes;
        m_UploadFileInfo.Owner->OnSeanFileSending(m_SendCtrlInfo);
        SendFile(localFile, m_SendCtrlInfo);
    }
}
int SeanFilePeer::StartSendFile(QString filePath)
{
    localFile.setFileName(filePath);
    if (!localFile.open(QFile::ReadOnly))
    {
        qDebug() << "file open error.";
        return 0;
    }

    m_SendCtrlInfo.init();
    m_SendCtrlInfo.totalBytes = localFile.size();
    m_SendCtrlInfo.bytesToWrite = m_SendCtrlInfo.loadSize;

    return 0;
}
int SeanFilePeer::SendFile(QFile &localFile, SeanUploadFileCtrlInfo &SendCtrlInfo)
{
    SendCtrlInfo.buf = localFile.read(SendCtrlInfo.loadSize);
    if(SendCtrlInfo.buf.length())
    {
        if(m_Conn->write(SendCtrlInfo.buf)<=0)
        {
            m_UploadFileInfo.Owner->OnSeanFileSendError(-1);
        }
    }
    else
    {
        m_UploadFileInfo.Owner->OnSeanFileSendFinish();
    }

    return 0;
}
int SeanFilePeer::StartRecvFile(QString filePath)
{
    localFile.setFileName(filePath);
    if (!localFile.open(QIODevice::WriteOnly))
    {
        qDebug() << "file open error.";
        return 0;
    }

    m_SendCtrlInfo.init();
    m_SendCtrlInfo.totalBytes = 0;
    m_SendCtrlInfo.bytesToWrite = 0;

    return 0;
}
int SeanFilePeer::RecvFile(QFile &localFile, SeanUploadFileCtrlInfo &SendCtrlInfo)
{
    QByteArray Data = m_Conn->readAll();

    SendCtrlInfo.bytesWritten += localFile.write(Data);

    m_UploadFileInfo.Owner->OnSeanFileSending(SendCtrlInfo);

    return 0;
}

SeanFileServer *gSeanFileServer=NULL;

SeanFileServer::SeanFileServer(QObject *parent):
QObject(parent)
{
    m_pTcpServer =new QTcpServer(this);
    m_pTcpServer->listen(QHostAddress::Any, 51697);
    connect(m_pTcpServer, SIGNAL(newConnection()), this, SLOT(NewConnect()));
}
SeanFileServer::~SeanFileServer()
{


}
SeanFileServer *SeanFileServer::Instance()
{
    if(gSeanFileServer==NULL)
    {
        gSeanFileServer = new SeanFileServer();
    }

    return gSeanFileServer;
}
void SeanFileServer::NewConnect()
{
    QTcpSocket *pNewConnection = m_pTcpServer->nextPendingConnection();
    while(pNewConnection)
    {
        SeanFilePeer *Peer = new SeanFilePeer(pNewConnection);

        qDebug() << "get local ip -------------------------------------\r\n";


        pNewConnection = m_pTcpServer->nextPendingConnection();
    }
}
QString SeanFileServer::GenSendFileTask(QString FilePath, SeanUploadFileInfo &Info, SeanSendFileTaskOwner *Owner)
{
    QFileInfo info1(FilePath);
    Info.m_Size = info1.size();

    QUuid id = QUuid::createUuid();
    QString strId = id.toString();

    QByteArray Md5 = getFileMd5(FilePath);

    Info.m_FilePath = FilePath;
    Info.m_Md5 = Md5.toHex().constData();
    Info.m_Token = strId;
    Info.Owner = Owner;
    Info.upordown = 2;
    m_UploadFileInfoS[strId] = Info;

    return strId;
}
QString SeanFileServer::GenRecvFileTask(QString FilePath, SeanUploadFileInfo &Info, SeanSendFileTaskOwner *Owner)
{
    QFileInfo info1(FilePath);
    QFile file(FilePath);
    file.open(QIODevice::ReadOnly);
    Info.m_Size = info1.size();
    file.close();

    QUuid id = QUuid::createUuid();
    QString strId = id.toString();

    QByteArray Md5 = getFileMd5(FilePath);

    Info.m_FilePath = FilePath;
    Info.m_Md5 = Md5.toHex().constData();
    Info.m_Token = strId;
    Info.Owner = Owner;
    Info.upordown = 3;

    m_UploadFileInfoS[strId] = Info;

    return strId;
}
int SeanFileServer::StopSendFileTask(QString TaskSn)
{

    return 0;
}
QString SeanFileServer::GetServiceIp()
{
    qDebug() << "ip------ " << m_pTcpServer->serverAddress().toString();

    QList<QHostAddress> AddressS = QNetworkInterface().allAddresses();
    for(int i=0; i<AddressS.size(); i++)
    {
        QMessageBox::about(NULL, tr("ip"), AddressS[i].toString());
    }

    for(int i=0; i<AddressS.size(); i++)
    {
        QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
        if(AddressS[i].protocol() == QAbstractSocket::IPv4Protocol)
        {
            if(regx.exactMatch(AddressS[i].toString()))
            {
                qDebug() << "ip " << AddressS[i].toString();



                return AddressS[i].toString();
            }
        }

        qDebug() << "ip " << AddressS[i].toString();
    }



    return "192.168.21.44";
    //return m_pTcpServer->serverAddress();
}
quint16 SeanFileServer::GetServicePort()
{
    return m_pTcpServer->serverPort();
}
QByteArray SeanFileServer::getFileMd5(QString filePath)
{
    QFile localFile(filePath);
    if (!localFile.open(QFile::ReadOnly))
    {
        qDebug() << "file open error.";
        return 0;
    }

    QCryptographicHash ch(QCryptographicHash::Md5);

    quint64 totalBytes = 0;
    quint64 bytesWritten = 0;
    quint64 bytesToWrite = 0;
    quint64 loadSize = 1024 * 4;
    QByteArray buf;

    totalBytes = localFile.size();
    bytesToWrite = totalBytes;

    while(1)
    {
        if(bytesToWrite > 0)
        {
            buf = localFile.read(qMin(bytesToWrite, loadSize));
            ch.addData(buf);
            bytesWritten += buf.length();
            bytesToWrite -= buf.length();
            buf.resize(0);
        }
        else
        {
            break;
        }

        if(bytesWritten == totalBytes)
        {
            break;
        }
    }

    localFile.close();
    QByteArray md5 = ch.result();
    return md5;
}










