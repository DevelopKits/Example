#ifndef REVIEW_H
#define REVIEW_H

#include <QWidget>

namespace Ui {
class Review;
}

class VReview : public QWidget
{
    Q_OBJECT
    
public:
    explicit VReview(QWidget *parent = 0);
    ~VReview();
    
private:
    Ui::Review *ui;
};

#endif // REVIEW_H
