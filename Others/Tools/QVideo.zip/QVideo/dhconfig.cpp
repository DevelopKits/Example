#include "dhconfig.h"
#include "ui_dhconfig.h"

#include <QtXml>
#include <QRegExp>
#include <QMessageBox>

Dhconfig::Dhconfig(ConfigConnector *conn,QWidget *parent):
    m_conn(conn), QWidget(parent),
    ui(new Ui::Dhconfig)
{
    ui->setupUi(this);

    ui->lineEdit_UserName->setText("admin");
    ui->lineEdit_UserPwd->setText("admin");

    ui->lineEdit_HostIp->setText("0.0.0.0");
    ui->lineEdit_HostPort->setText("37777");

    ui->comboBox_devtype->addItem("NVD");
    ui->comboBox_devtype->addItem("UDS");
}

Dhconfig::~Dhconfig()
{
    delete ui;
}
int Dhconfig::HandleSystemInfoAck(QStringList cmdlist)
{
    return 0;
}


void Dhconfig::on_pushButton_SubMit_clicked()
{
    QString ip = ui->lineEdit_HostIp->text();
    QString port = ui->lineEdit_HostPort->text();

    QString usr = ui->lineEdit_UserName->text();
    QString pwd = ui->lineEdit_UserPwd->text();
    QString type = ui->comboBox_devtype->itemText(ui->comboBox_devtype->currentIndex());;

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"utf-8\"?><dhconfig version=\"1\"/>"),false);

    QDomElement usrinfoNode = doc.createElement("usrinfo");

    QDomElement usrNode = doc.createElement("usr");
    QDomText usrtext = doc.createTextNode(usr);
    usrNode.appendChild(usrtext);

    QDomElement pwdNode = doc.createElement("pwd");
    QDomText pwdtext = doc.createTextNode(pwd);
    pwdNode.appendChild(pwdtext);

    usrinfoNode.appendChild(usrNode);
    usrinfoNode.appendChild(pwdNode);
    doc.documentElement().appendChild(usrinfoNode);

    QDomElement hostinfoNode = doc.createElement("hostinfo");

    QDomElement ipNode = doc.createElement("ip");
    QDomText iptext = doc.createTextNode(ip);
    ipNode.appendChild(iptext);

    QDomElement portNode = doc.createElement("port");
    QDomText porttext = doc.createTextNode(port);
    portNode.appendChild(porttext);

    hostinfoNode.appendChild(ipNode);
    hostinfoNode.appendChild(portNode);
    doc.documentElement().appendChild(hostinfoNode);

    QDomElement devinfoNode = doc.createElement("devinfo");

    QDomElement typeNode = doc.createElement("type");
    QDomText typetext = doc.createTextNode(type);
    typeNode.appendChild(typetext);

    devinfoNode.appendChild(typeNode);
    doc.documentElement().appendChild(devinfoNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    //dhconfig according to libdhconfig.so
    //dhsetconfig according to function dhsetconfig_withfd
    QString cmd("dhconfig:dhsetconfig:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());

    QMessageBox::information(NULL, "config UDSMgrServer", "config UDSMgrServer success, please reboot!", QMessageBox::Ok, QMessageBox::Ok);
}

void Dhconfig::on_pushButton_reboot_clicked()
{
    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"utf-8\"?><ExPowerReq/>"),false);

    QDomElement powerinfoNode = doc.createElement("powerinfo");
    powerinfoNode.setAttribute(tr("type"), 1);

    doc.documentElement().appendChild(powerinfoNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();
    //dhconfig according to libdhconfig.so
    //dhsetconfig according to function dhsetconfig_withfd
    QString cmd("dhconfig:dhpower:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    if(QMessageBox::Yes == QMessageBox::information(NULL, "config UDSMgrServer", "the system will reboot?", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes))
    {
        m_conn->SendCmd(ACmd.data());
    }
}

void Dhconfig::on_pushButton_shutdown_clicked()
{
    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"utf-8\"?><ExPowerReq/>"),false);

    QDomElement powerinfoNode = doc.createElement("powerinfo");
    powerinfoNode.setAttribute(tr("type"), 0);

    doc.documentElement().appendChild(powerinfoNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();
    //dhconfig according to libdhconfig.so
    //dhsetconfig according to function dhsetconfig_withfd
    QString cmd("dhconfig:dhpower:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    if(QMessageBox::Yes == QMessageBox::information(NULL, "config UDSMgrServer", "the system will shutdown?", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes))
    {
        m_conn->SendCmd(ACmd.data());
    }
}

