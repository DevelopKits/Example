﻿#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>
#include "configconnector.h"

namespace Ui {
class ConfigDialog;
}

QT_BEGIN_NAMESPACE
class QListWidget;
class QListWidgetItem;
class QStackedWidget;
QT_END_NAMESPACE

class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(JtDeviceInfo, QWidget *parent = 0);
    ~ConfigDialog();
    void createIcons();
public slots:
    void changePage(QListWidgetItem *current, QListWidgetItem *previous);

    void OnRecvData(char*, int);
    void OnClosed();
    void OnConnected();

private:
    Ui::ConfigDialog *ui;
    QListWidget *contentsWidget;
    QStackedWidget *pagesWidget;

    ConfigConnector *ConfigConn;
    JtDeviceInfo m_DeviceInfo;

    struct st_sean_netinterface ;
};

#endif // CONFIGDIALOG_H
