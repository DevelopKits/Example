#ifndef MutilCastCmd_h
#define MutilCastCmd_h

#define SEAN_GET_ADDR_INFO_REQ          0X0b00
#define SEAN_GET_ADDR_INFO_RSP          0X0b01

#define SEAN_SET_ADDR_INFO_REQ          0X0b02
#define SEAN_SET_ADDR_INFO_RSP          0X0b03

#define SEAN_SET_REBOOT_REQ             0X0b04
#define SEAN_SET_REBOOT_RSP             0X0b05

#define SEAN_SET_HALT_REQ               0X0b06
#define SEAN_SET_HALT_RSP               0X0b07

//�ⲿ����̶�ͷ���ṹ
#pragma pack(push,1)
struct MuiltCastCmd
{
	unsigned int          uMagic;        //0x31239000
	unsigned short        nCmdType;      //
	unsigned int          nCmdSeq;       // ���
	unsigned int          uIp[4];        //����ʱ��˭��
	unsigned int short    uRPort;        //����ʱ��˭��
	unsigned int 	      nContentSize;  //
	unsigned char         cChecksum;     //
};

#pragma pack(pop)












#endif
