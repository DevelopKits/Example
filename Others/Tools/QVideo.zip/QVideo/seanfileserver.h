#ifndef SEANFILESERVER_H
#define SEANFILESERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QMap>
#include <QFile>

class SeanSendFileTaskOwner
{
public:
    virtual void OnSeanFileSending(struct SeanUploadFileCtrlInfo CtrlInfo)=0;
    virtual void OnSeanFileSendError(int Error)=0;
    virtual void OnSeanFileSendFinish()=0;
};

struct SeanUploadFileCtrlInfo
{
    SeanUploadFileCtrlInfo()
    {
        totalBytes = 0;
        bytesWritten = 0;
        bytesToWrite = 0;
        loadSize = 1024 * 4;
    }
    void init()
    {
        totalBytes = 0;
        bytesWritten = 0;
        bytesToWrite = 0;
        loadSize = 1024 * 4;
    }

    quint64 totalBytes;
    quint64 bytesWritten;
    quint64 bytesToWrite;
    quint64 loadSize;
    QByteArray buf;
};
struct SeanUploadFileInfo
{
    SeanUploadFileInfo()
    {
        upordown = 0;
        m_Size = 0;
    }

    QString m_FilePath;
    QString m_Md5;
    QString m_Token;
    qint64 m_Size;
    int    upordown;
    SeanSendFileTaskOwner *Owner;
};

class SeanFilePeer : public QObject
{
    Q_OBJECT

private:
    QTcpSocket *m_Conn;

    SeanUploadFileCtrlInfo m_SendCtrlInfo;
    SeanUploadFileInfo m_UploadFileInfo;
    QFile localFile;

    int m_GetId;

    int StartSendFile(QString filePath);
    int SendFile(QFile &localFile, SeanUploadFileCtrlInfo &SendCtrlInfo);

    int StartRecvFile(QString filePath);
    int RecvFile(QFile &localFile, SeanUploadFileCtrlInfo &SendCtrlInfo);

signals:
    void OnDataSending(int Len);
    void OnDataSendError(int Error);
    void OnDataSendFinish();
private slots:
    void OnReciveData();
    void OnDisConnected();
    void OnSendData(qint64 bytes);
public:

public:
    explicit SeanFilePeer(QTcpSocket *Conn, QObject *parent = 0);
    ~SeanFilePeer();
};

class SeanFileServer : public QObject
{
    Q_OBJECT

private:
    explicit SeanFileServer(QObject *parent = 0);
    ~SeanFileServer();
    QByteArray getFileMd5(QString filePath);
    int SendFile(QString filePath, QTcpSocket *pConnection);
    QTcpServer *m_pTcpServer;
private slots:
    void NewConnect();
public:
    static SeanFileServer *Instance();

    QMap<QString, SeanUploadFileInfo> m_UploadFileInfoS;

    QString GenSendFileTask(QString FilePath, SeanUploadFileInfo &Info, SeanSendFileTaskOwner *Owner);
    QString GenRecvFileTask(QString FilePath, SeanUploadFileInfo &Info, SeanSendFileTaskOwner *Owner);

    int StopSendFileTask(QString TaskSn);
    QString GetServiceIp();
    quint16 GetServicePort();
};

#endif // SEANFILESERVER_H
