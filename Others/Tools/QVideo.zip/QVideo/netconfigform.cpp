﻿#include "netconfigform.h"
#include "ui_netconfigform.h"
#include "dialognetbind.h"
#include "dialogaddnewip.h"
#include <QtXml>
#include <QMessageBox>
NetConfigForm::NetConfigForm(ConfigConnector *conn, JtDeviceInfo DeviceInfo, QWidget *parent) :
    m_conn(conn),m_DeviceInfo(DeviceInfo), QWidget(parent),
    ui(new Ui::NetConfigForm)
{
    ui->setupUi(this);

    QRegExp regx("((?:(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(?:25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d))))");
    QValidator* validator = new QRegExpValidator(regx);
    ui->lineEdit_ip->setValidator(validator);
    ui->lineEdit_NetConfigMask->setValidator(validator);

    NetStateDescriptionS[0] = tr("空闲网口");
    NetStateDescriptionS[1] = tr("独立网口");
    NetStateDescriptionS[2] = tr("绑定网口");
    NetStateDescriptionS[3] = tr("从属网口");
    NetStateDescriptionS[99] = tr("无该网口");

    //ui->treeWidget_netinterface->setHeaderLabel(QTextCodec::setCodecForCStrings(QTextCodec::codecForName("网络接口")));

    ui->treeWidget_netinterface->setHeaderLabel(QString(tr("网络接口")));

    for(QMap<QString, struct st_sean_netinterface>::iterator iter = m_DeviceInfo.NetIFaceInfoS.begin(); iter!=m_DeviceInfo.NetIFaceInfoS.end(); ++iter)
    {
        ui->treeWidget_netinterface->addTopLevelItem(new QTreeWidgetItem(QStringList(iter.key())));
        //ui->lineEdit_state->setText(NetStateDescriptionS[iter.value().state]);
        //ui->lineEdit_mac->setText(iter.value().mac);
    }

    //ui->tableWidget_subifacelist->selectColumn(3);
    QStringList header;
    header<<tr("地址")<<tr("掩码")<<tr("名称");
    ui->tableWidget_subifacelist->setHorizontalHeaderLabels(header);
    //ui->tableWidget_subifacelist->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

NetConfigForm::~NetConfigForm()
{
    delete ui;
}


void NetConfigForm::on_treeWidget_netinterface_itemClicked(QTreeWidgetItem *item, int column)
{
    QMap<QString, struct st_sean_netinterface>::iterator iter = m_DeviceInfo.NetIFaceInfoS.find(item->text(0));
    if(iter!=m_DeviceInfo.NetIFaceInfoS.end())
    {
        ui->lineEdit_state->setText(NetStateDescriptionS[iter.value().state]);
        ui->lineEdit_ip->setText(iter.value().ipv4);
        ui->lineEdit_mac->setText(iter.value().mac);
        ui->lineEdit_NetConfigMask->setText(iter.value().netmask);
        ui->lineEdit_NetConfigGateway->setText(iter.value().netgate);

        //ui->tableWidget_subifacelist->clear();
        ui->tableWidget_subifacelist->setRowCount(0);
        ui->tableWidget_subifacelist->setRowCount(10);
        int i=0;
        for(QMap<QString, struct st_sean_sub_netinterface>::iterator iter2 = iter.value().SubInterfaceS.begin()
            ;iter2!=iter.value().SubInterfaceS.end();++iter2)
        {
            ui->tableWidget_subifacelist->setItem(i,0,new QTableWidgetItem(iter2.value().ipv4));//new QTableWidgetItem(iter2.value().ipv4)
            ui->tableWidget_subifacelist->setItem(i,1,new QTableWidgetItem(iter2.value().netmask));
            ui->tableWidget_subifacelist->setItem(i,2,new QTableWidgetItem(iter2.value().name));
            ++i;
        }
        //ui->tableWidget_subifacelist->show();
    }
}

void NetConfigForm::on_pushButton_netbind_clicked()
{
    QList<QTreeWidgetItem*> NetIfaceS = ui->treeWidget_netinterface->selectedItems();
    if(NetIfaceS.size()<2)
    {
        QMessageBox::about(NULL, tr(" 请选中两以上网口 "), tr(" 请选中两以上网口 "));
        return;
    }

    QMap<QString, struct st_sean_netinterface> NetIFaceInfoS;
    for(QList<QTreeWidgetItem*>::iterator iter = NetIfaceS.begin(); iter!=NetIfaceS.end(); ++iter)
    {
        QMap<QString, struct st_sean_netinterface>::iterator iter2 = m_DeviceInfo.NetIFaceInfoS.find((*iter)->text(0));
        if(iter2!=m_DeviceInfo.NetIFaceInfoS.end())
        {
            NetIFaceInfoS[iter2.key()] = iter2.value();
        }
    }

    DialogNetBind Dialog(NetIFaceInfoS);
    Dialog.setModal(true);
    Dialog.show();
    if(Dialog.exec()==QDialog::Accepted)
    {
        QDomDocument doc;
        doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExSetNetBindReq/>"),false);

        QDomElement BindInfoNode = doc.createElement("BindInfo");
        BindInfoNode.setAttribute(tr("Ip"),Dialog.m_BindIp);
        BindInfoNode.setAttribute(tr("Mask"),Dialog.m_BindMask);
        BindInfoNode.setAttribute(tr("Gateway"),Dialog.m_BindGate);
        BindInfoNode.setAttribute(tr("BindMode"),Dialog.m_BindMode);
        doc.documentElement().appendChild(BindInfoNode);

        QDomElement NetInterfaceListNode = doc.createElement("NetInterfaceList");

        for(QMap<QString, struct st_sean_netinterface>::iterator iter = Dialog.m_NetIfaceS.begin(); iter!=Dialog.m_NetIfaceS.end(); ++iter)
        {
            QDomElement NetInterfaceNode = doc.createElement("NetInterface");
            NetInterfaceNode.appendChild(doc.createTextNode(iter.key()));
            NetInterfaceListNode.appendChild(NetInterfaceNode);
        }

        doc.documentElement().appendChild(NetInterfaceListNode);
        QString XMLStr = doc.toString(0);
        XMLStr = XMLStr.simplified();

        QString cmd("netconfig:setbind:");
        QByteArray ACmd = cmd.append(XMLStr).toLatin1();

        /*
        //<?xml version=\"1.0\" encoding=\"gb2312\"?>\n"
        //<ExSetNetBindReq>
        //  <BindInfo Ip="192.168.3.3" Mask="255.255.255.0" Gateway="192.168.3.1" BindMode="0" >
        //	<NetInterfaceList>
        //		<NetInterface>eth0</NetInterface>
        //		<NetInterface>eth1</NetInterface>
        //	</NetInterfaceList>
        //<ExSetNetBindReq/>
        */

        m_conn->SendCmd(ACmd.data());
    }
    else
    {


    }
}

void NetConfigForm::on_pushButtonnetunbind_clicked()
{
    m_conn->SendCmd("netconfig:rmvbind:bind0");
}

void NetConfigForm::on_pushButton_ChangeIP_clicked()
{
    //<?xml version=\"1.0\" encoding=\"gb2312\"?>\n"
    //<ExSetNetIpReq>
    //    <IFace NewIp="192.168.3.1" NewMask="255.255.255.0" >eth0</IFace>
    //<ExSetNetIpReq/>
    QList<QTreeWidgetItem*> NetIfaceS = ui->treeWidget_netinterface->selectedItems();
    if(NetIfaceS.size()!=1)
    {
        QMessageBox::about(NULL, tr(" 请只选择一个网口 "), tr(" 请只选择一个网口 "));
        return;
    }


    if(QMessageBox::information(NULL, "确认", "确定要修改ip?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }


    QHostAddress NewIP(ui->lineEdit_ip->text());
    QHostAddress NewMask(ui->lineEdit_NetConfigMask->text());

    quint32 dd = NewIP.toIPv4Address();
    quint32 mm = NewMask.toIPv4Address();

    quint32 test = dd&mm;

    if(ui->lineEdit_NetConfigGateway->text().size())
    {
        //填写了网关的，就要验证网路是否一致
        QHostAddress NeGate(ui->lineEdit_NetConfigGateway->text());
        quint32 gg = NeGate.toIPv4Address();
        quint32 testg = gg&mm;
        if(testg!=test)
        {
            //网络不一致，返回
            QMessageBox::about(NULL, tr("网关错误 网络不一致"), tr("网关错误 网络不一致"));
            return;
        }
    }

    for(QMap<QString, struct st_sean_netinterface>::Iterator iter3 = m_DeviceInfo.NetIFaceInfoS.begin()
        ; iter3!=m_DeviceInfo.NetIFaceInfoS.end(); ++iter3)
    {
        QString sd = iter3.key();
        sd = sd;
        if(iter3.key()!=NetIfaceS[0]->text(0))//不是本网口的记录，检查是否要改为同一网段的，要禁止
        {
            QHostAddress NewIP2(iter3.value().ipv4);
            QHostAddress NewMask2(iter3.value().netmask);
            quint32 dd2 = NewIP2.toIPv4Address();
            quint32 mm2 = NewMask2.toIPv4Address();
            quint32 test2 = dd2&mm2;
            if(test==test2)//同一网段，禁止修改
            {
                QMessageBox::about(NULL, tr(" 同一网段，禁止修改 "), tr(" 同一网段，禁止修改 " ));
                return;
            }

            QString newGate_ = ui->lineEdit_NetConfigGateway->text();
            if(newGate_.size())//双网口时，填写了网关，那么另一个网口就不能有网关
            {
                if(iter3.value().netgate.size())
                {
                    //有网关了，报错，
                    QMessageBox::about(NULL, tr(" 另一网口已填写网关 "), tr(" 另一网口已填写网关 " ));
                    return;
                }
            }
        }
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExSetNetIpReq/>"),false);
    QDomElement IFaceNode = doc.createElement("IFace");
    IFaceNode.appendChild(doc.createTextNode(NetIfaceS[0]->text(0)));
    IFaceNode.setAttribute(tr("NewIp"),ui->lineEdit_ip->text());
    IFaceNode.setAttribute(tr("NewMask"),ui->lineEdit_NetConfigMask->text());
    IFaceNode.setAttribute(tr("NewGateway"),ui->lineEdit_NetConfigGateway->text());
    doc.documentElement().appendChild(IFaceNode);
    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("netconfig:setnewip:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void NetConfigForm::on_pushButton_clicked()
{
    //删除一个配置
    QList<QTreeWidgetItem*> NetIfaceS = ui->treeWidget_netinterface->selectedItems();
    if(NetIfaceS.size()!=1)
    {
        QMessageBox::about(NULL, tr(" 请只选择一个网口 "), tr(" 请只选择一个网口 "));
        return;
    }

    if(QMessageBox::information(NULL, tr("确认"), tr("确定要删除网口"), QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExRmvNetIpReq/>"),false);
    QDomElement IFaceNode = doc.createElement("IFace");
    //IFaceNode.appendChild(doc.createTextNode(StrIface));
    IFaceNode.setAttribute(tr("Name"),NetIfaceS[0]->text(0));
    //IFaceNode.setAttribute(tr("Ip"),StrIp);
    //IFaceNode.setAttribute(tr("Mask"),StrMask);
    doc.documentElement().appendChild(IFaceNode);
    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("netconfig:rmifaceip:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void NetConfigForm::on_pushButtonsubifaceadd_clicked()
{
//<?xml version=\"1.0\" encoding=\"gb2312\"?>\n"
//<ExAddNetIpReq>
//    <IFace NewIp="192.168.3.1" NewMask="255.255.255.0" Name="eth0" />
//<ExAddNetIpReq/>

    QList<QTreeWidgetItem*> NetIfaceS = ui->treeWidget_netinterface->selectedItems();
    if(NetIfaceS.size()!=1)
    {
        QMessageBox::about(NULL, tr(" 请只选择一个网口 "), tr(" 请只选择一个网口 "));
        return;
    }

    //添加一个ip地址
    DialogAddNewIP Dialog;
    Dialog.setModal(true);
    Dialog.show();
    if(Dialog.exec()==QDialog::Accepted)
    {
        QDomDocument doc;
        doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExAddNetIpReq/>"),false);
        QDomElement IFaceNode = doc.createElement("IFace");
        //IFaceNode.appendChild(doc.createTextNode(StrIface));
        IFaceNode.setAttribute(tr("Name"),NetIfaceS[0]->text(0));
        IFaceNode.setAttribute(tr("Ip"),Dialog.newIp);
        IFaceNode.setAttribute(tr("Mask"),Dialog.newMask);
        doc.documentElement().appendChild(IFaceNode);
        QString XMLStr = doc.toString(0);
        XMLStr = XMLStr.simplified();

        QString cmd("netconfig:addifaceip:");
        QByteArray ACmd = cmd.append(XMLStr).toLatin1();

        m_conn->SendCmd(ACmd.data());
    }
}
void NetConfigForm::on_pushButtonaubifacedel_clicked()
{
    //<?xml version=\"1.0\" encoding=\"gb2312\"?>\n"
    //<ExRmvNetIpReq>
    //    <IFace NewIp="192.168.3.1" NewMask="255.255.255.0" Name="eth0" />
    //<ExRmvNetIpReq/>

    //删除一个ip
    //当前行
    int Row = ui->tableWidget_subifacelist->currentRow();
    if(Row==-1)
    {
        return;
    }

    QTableWidgetItem *IpItem = ui->tableWidget_subifacelist->item(Row,0);
    QTableWidgetItem *MaskItem = ui->tableWidget_subifacelist->item(Row,1);
    QTableWidgetItem *IfaceItem = ui->tableWidget_subifacelist->item(Row,2);
    QString StrIp = IpItem->text();
    QString StrMask = MaskItem->text();
    QString StrIface = IfaceItem->text();

    QString Msg = tr("确定要删除\n")+StrIp+tr("\n")+StrMask+tr("\n")+StrIface;
    if(QMessageBox::information(NULL, tr("确认"), Msg, QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExRmvNetIpReq/>"),false);
    QDomElement IFaceNode = doc.createElement("IFace");
    //IFaceNode.appendChild(doc.createTextNode(StrIface));
    IFaceNode.setAttribute(tr("Name"),StrIface);
    IFaceNode.setAttribute(tr("Ip"),StrIp);
    IFaceNode.setAttribute(tr("Mask"),StrMask);
    doc.documentElement().appendChild(IFaceNode);
    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("netconfig:rmifaceip:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}
