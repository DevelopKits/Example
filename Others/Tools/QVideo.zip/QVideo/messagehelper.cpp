#include "messagehelper.h"

#include "COMM_HEADER.h"

int MessageHelper::BuildCmdMsg(BYTE** ppOutMsg, int& nCmdLen, int nSrcType, int nCmdType, int nCmdSeq, iCMSP_XmlParser& xmlParser)
{
    STRY;

    const TCHAR* pchXmlOut	= xmlParser.GetDoc();
    //const TCHAR* pchXmlOut = _T("大地母亲");
    int nOutXmlLen			= _tcslen(pchXmlOut);

    char* pOutUtf8 = new char[4*nOutXmlLen + sizeof(ST_ICMS_CMD_HEADER)];
    memset(pOutUtf8, 0, 4*nOutXmlLen + sizeof(ST_ICMS_CMD_HEADER));
    if (NULL == pOutUtf8)
        return -1;

    int nOutLength = nOutXmlLen;
    char* pTmePtr = pOutUtf8 + sizeof(ST_ICMS_CMD_HEADER);
#ifdef _UNICODE
    nOutLength = WideCharToMultiByte(CP_UTF8, 0, pchXmlOut, nOutXmlLen, pTmePtr, 4*nOutXmlLen, NULL,0);
    if(nOutLength < 0)
    {
        delete pOutUtf8;
        pOutUtf8 = NULL;
        return -2;
    }
#else
    memcpy(pTmePtr, pchXmlOut, nOutLength);
#endif

    ST_ICMS_CMD_HEADER stCmdHeader;
    stCmdHeader.wSrcType			= nSrcType;
    stCmdHeader.dwCmdSubType		= nCmdType;
    stCmdHeader.dwSeqID				= nCmdSeq;
    stCmdHeader.dwExndSize			= nOutLength;
    CopyMemory(pOutUtf8, &stCmdHeader, sizeof(ST_ICMS_CMD_HEADER));

    *ppOutMsg = (BYTE*)pOutUtf8;
    nCmdLen = nOutLength + sizeof(ST_ICMS_CMD_HEADER);

    SCATCH;
    return 0;
}

int MessageHelper::ParseCmdMsg(iCMSP_XmlParser& xmlParser, TCHAR** pCmdMsg, ST_ICMS_CMD_HEADER& stCmdHeader, BYTE* pInMsg)
{
    STRY;

    CopyMemory(&stCmdHeader, pInMsg, sizeof(ST_ICMS_CMD_HEADER));
    int nInXmlLen			= stCmdHeader.dwExndSize;

    TCHAR* pTCHAR = new TCHAR[nInXmlLen + 10];
    memset(pTCHAR, 0, sizeof(TCHAR) * (nInXmlLen + 10));
    if (NULL == pTCHAR)
        return -1;

    char* pTmePtr = (char*)(pInMsg + sizeof(ST_ICMS_CMD_HEADER));
    int nInLength = nInXmlLen;

#ifdef _UNICODE
    nInLength = MultiByteToWideChar(CP_UTF8, 0, pTmePtr, nInXmlLen, pTCHAR, nInXmlLen + 10);
    if(nInLength < 0)
    {
        delete pTCHAR;
        pTCHAR = NULL;
        return -2;
    }
#else
    memcpy(pTCHAR, pTmePtr, nInLength);
#endif

    xmlParser.SetDoc(pTCHAR, nInLength);
    *pCmdMsg = pTCHAR;

    SCATCH;
    return 0;
}


int MessageHelper::BuildCmdXml(BYTE** ppOutMsg, int& nCmdLen, iCMSP_XmlParser& xmlParser)
{
    STRY;

    const TCHAR* pchXmlOut	= xmlParser.GetDoc();
    int nOutXmlLen			= _tcslen(pchXmlOut);

    char* pOutUtf8 = new char[4*nOutXmlLen];
    memset(pOutUtf8, 0, 4*nOutXmlLen);
    if (NULL == pOutUtf8)
        return -1;

    int nOutLength = nOutXmlLen;

#ifdef _UNICODE
    nOutLength = WideCharToMultiByte(CP_UTF8, 0, pchXmlOut, nOutXmlLen, pOutUtf8, 4*nOutXmlLen, NULL,0);
    if(nOutLength < 0)
    {
        delete pOutUtf8;
        pOutUtf8 = NULL;
        return -2;
    }
#else
    memcpy(pOutUtf8, pchXmlOut, nOutLength);
#endif

    *ppOutMsg = (BYTE*)pOutUtf8;
    nCmdLen = nOutLength;

    SCATCH;
    return 0;
}

int MessageHelper::FreeTcharMsg(TCHAR* pCmdMsg)
{
    if(pCmdMsg)
    {
        delete pCmdMsg;
        pCmdMsg = NULL;
    }
    return 0;
}

int MessageHelper::FreeByteMsg(BYTE* pCmdMsg)
{
    if(pCmdMsg)
    {
        delete pCmdMsg;
        pCmdMsg = NULL;
    }
    return 0;
}
