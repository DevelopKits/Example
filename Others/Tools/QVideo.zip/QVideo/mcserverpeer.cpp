﻿#include "COMM_HEADER.h"
#include "CachedAffair.h"
#include "mcserverpeer.h"
#include <QtXml>
McServerPeer::McServerPeer(void)
:m_lastServerIp(0),m_lastRetryConnectTime(0),m_nLastSendSeq(0)
,m_dwUserInfoID(0),m_strUserName(""),m_strUserPassword(""),m_wSrcType(EX_CLIENT_CONFIGER)
,m_nLastInitTime(0)
{
    m_pTcpConnect2Mc = new Connector();

    m_pTcpConnect2Mc->SetCallBackSink (this, EX_CLIENT_CONFIGER);
}

McServerPeer::~McServerPeer(void)
{
    CCachedAffairMap::GetInstance()->ClearCachedItem();
}

McServerPeer* McServerPeer::GetInstance()
{
    static McServerPeer g_McServerPeer;
    return &g_McServerPeer;
}

int McServerPeer::OnRecvData(char* pData, int dataLen)
{
    if (NULL == pData || dataLen < sizeof(ST_ICMS_CMD_HEADER))
        return -2;

    STRY;
    ST_ICMS_CMD_HEADER* pCmdHeader = (ST_ICMS_CMD_HEADER*)pData;
    /*switch (pCmdHeader->dwCmdSubType)
    {
    case EX_LOGIN_RSP:
        {
            DoCheckUserLoginRespond(pData,dataLen);
            LOGLINE;
        }
        break;

    case EX_EQU_CATALOG_UPDATE_NOTIFY://添加组织节点更新通知,修改组织节点名称更新通知,删除组织节点更新通知
    case EX_SUB_EQU_UPDATE_NOTIFY://添加子设备更新通知,修改子设备更新通知,删除子设备更新通知
        return DeviceManager::GetDeviceManager()->OnRecvData(fromAddr,pData,dataLen);

    case EX_MANUAL_INSPECTION_RESULT_NOTIFY:
        return TourManager::GetTourManager()->OnGetInspectionInfNotify(pData,dataLen);
        break;
    }*/
    SCATCH;

    STRY;
    //iCMSP_SimpleLock simpleLock(&m_simpleCS,__FUNCTION__);
    CCachedAffairMap::GetInstance()->CheckBeExptedData((BYTE*)pData,dataLen);
    return 1;
    SCATCH;

    return -1;
}

int McServerPeer::OnConnected()
{
    STRY;

    char strSendXmlBuf[256] = {0};
    sprintf(strSendXmlBuf, "<?xml version=\"1.0\" encoding=\"gb2312\"?>"
                        "<LoginIn_Req>"
                            "<EncryptType>1</EncryptType>"
                            "<UserName>%s</UserName>"
                            "<Password>%s</Password>"
                            "<ClientIP>0.0.0.0</ClientIP>"
                        "</LoginIn_Req>",m_strUserName.toLatin1().data()
                                        , m_strUserPassword.toLatin1().data());

    ST_AFFAIR_CALLBACK stAffairCallBack((DWORD)this,Static_OnGotLoginData,Static_OnLoginOverTime,30*1000);
    CCachedAffairMap::GetInstance()->PushNewAffair(&stAffairCallBack
        , m_nLastSendSeq, ICMS_TYPE_TOMC_LOGIN_REQ, ICMS_TYPE_TOMC_LOGIN_REQ+1);

    //登陆
    m_pTcpConnect2Mc->SendCmd(0xff01, 0x0001, ICMS_TYPE_TOMC_LOGIN_REQ, strSendXmlBuf);

    return 1;
    SCATCH;
    return -1;
}

/*int McServerPeer::OnReConnected(UINT64 fromAddr )
{
    //not need it,do it in timer check thread.terrywang edit at 2009-8-12
    return 0;
}*/

int McServerPeer::OnClosed()
{
    STRY;
    //ASSERT(m_McServerAddr == fromAddr);
    //m_McServerAddr			= 0;
    //m_lastRetryConnectTime	= -1;
    SCATCH;
    return -1;
}

int McServerPeer::DoCheckNetConnection(DWORD nowTime)
{
    static const DWORD CHECK_TCP_CONNECT_BE_LOST	= 2 *1000;
    STRY;

    //每10秒检测一次检测是否被断开
    if (0 == m_lastRetryConnectTime)
        m_lastRetryConnectTime = nowTime;
    if (m_lastRetryConnectTime + CHECK_TCP_CONNECT_BE_LOST > nowTime)
        return 1;

    m_lastRetryConnectTime = nowTime;
    //if (0 == m_McServerAddr && m_lastServerIp && m_lastServerPort)
    //{
        /*ST_ICMSLOGIN_PARAM	stIcmsLoginParam;
        _tcscpy(stIcmsLoginParam.userName, m_strUserName);
        _tcscpy(stIcmsLoginParam.userPass, m_strUserPassword);
        stIcmsLoginParam.cmsServerIp		= m_lastServerIp;
        stIcmsLoginParam.cmsSlaveServerIp	= m_lastSlaveServerIp;
        stIcmsLoginParam.cmsServerPort		= m_lastServerPort;

        return DoLogin2CmsServer(&stIcmsLoginParam, NULL);*/
    //}
    return DoCheckHeartBeatPacket();
    SCATCH;
    return -1;
}

int McServerPeer::OnRun2Time(DWORD nowTime)
{
    STRY;
    /*iCMSP_SimpleLock simpleLock(&m_simpleCS, _T(__FUNCTION__));
    CCachedAffair::Static_CheckBeOverTime(m_cachedAffairMap,nowTime);
    SCATCH;

    STRY;
    if (m_dwUserInfoID &&  nowTime > m_nLastInitTime + 10000 )
    {
        m_nLastInitTime = nowTime;
    }
    return DoCheckNetConnection(nowTime);*/
    SCATCH;
    return -1;
}

void McServerPeer::SetSrcType(WORD wSrcType)
{
    m_wSrcType = wSrcType;
}

DWORD McServerPeer::GetUserId()
{
    return m_dwUserInfoID;
}

int McServerPeer::AddSysInitProgressSubscriber(ISystemInitProgressSubscriber* pSbuscriber)
{
    if (NULL == pSbuscriber)
        return -2;

    STRY;
    QMutexLocker simpleLock(&m_simpleCS);
    m_mapSystemInitProgressSubscriber [pSbuscriber] = pSbuscriber;
    return 1;
    SCATCH;
    return -1;
}

int McServerPeer::RemoveSysInitProgressSubscriber(ISystemInitProgressSubscriber* pSbuscriber)
{
    if (NULL == pSbuscriber)
        return -2;
    STRY;
    QMutexLocker simpleLock(&m_simpleCS);
    SYSTEM_INIT_PROGRESS_SSUBSCRIBER_MAP::iterator iterFind = m_mapSystemInitProgressSubscriber.find(pSbuscriber);
    if (iterFind != m_mapSystemInitProgressSubscriber.end ())
    {
        m_mapSystemInitProgressSubscriber.erase (iterFind);
        return 1;
    }
    return 0;
    SCATCH;
    return -1;
}
int McServerPeer::OnLogin()
{
    STRY;
    QMutexLocker simpleLock(&m_simpleCS);
    map<ISystemInitProgressSubscriber*,ISystemInitProgressSubscriber*>::iterator iter = m_mapSystemInitProgressSubscriber.begin();
    while (iter != m_mapSystemInitProgressSubscriber.end ())
    {
        STRY;
        ISystemInitProgressSubscriber* pSubscriber = iter ->second ;
        if (NULL != pSubscriber )
            pSubscriber->OnLogin();
        SCATCH;
        ++ iter;
    }
    return 1;
    SCATCH;
    return -1;
}
int McServerPeer::PublishProgressing(QString info)
{
    STRY;
    QMutexLocker simpleLock(&m_simpleCS);
    map<ISystemInitProgressSubscriber*,ISystemInitProgressSubscriber*>::iterator iter = m_mapSystemInitProgressSubscriber.begin();
    while (iter != m_mapSystemInitProgressSubscriber.end ())
    {
        STRY;
        ISystemInitProgressSubscriber* pSubscriber = iter ->second ;
        if (NULL != pSubscriber )
            pSubscriber->OnSysInitProgressInfo(info);
        SCATCH;
        ++ iter;
    }
    return 1;
    SCATCH;
    return -1;
}
int McServerPeer::PublishProgressFinish(bool bLoadData)
{
    STRY;
    QMutexLocker simpleLock(&m_simpleCS);
    map<ISystemInitProgressSubscriber*,ISystemInitProgressSubscriber*>::iterator iter = m_mapSystemInitProgressSubscriber.begin();
    while (iter != m_mapSystemInitProgressSubscriber.end ())
    {
        STRY;
        ISystemInitProgressSubscriber* pSubscriber = iter ->second ;
        if (NULL != pSubscriber)
            pSubscriber->OnSysInitFinish(bLoadData);
        SCATCH;
        ++ iter;
    }
    return 1;
    SCATCH;
    return -1;
}

int McServerPeer::DoLogin2CmsServer(ST_ICMSLOGIN_PARAM* pLoginParam)
{
    STRY;

    m_ServerIp = pLoginParam->cmsSlaveServerIp;
    m_ServerPort	= pLoginParam->cmsServerPort;
    m_strUserName		= pLoginParam->userName;
    m_strUserPassword	= pLoginParam->userPass;
    m_dwUserInfoID		= 0;
    //if(!m_pTcpConnect2Mc->connected())
    m_pTcpConnect2Mc->connectToHost(pLoginParam->cmsServerIp, pLoginParam->cmsServerPort);


    SCATCH;
    return -1;
}

int McServerPeer::Static_OnLoginOverTime(DWORD cookie)
{
    STRY;
    McServerPeer* pSelf = (McServerPeer*)cookie;
    pSelf->OnLoginOverTime();
    return 1;
    SCATCH;
    return -1;
}
int McServerPeer::OnLoginOverTime()
{
    return 0;
}
int McServerPeer::Static_OnGotLoginData(DWORD cookie,BYTE* pData,int dataLen)
{
    /*
    <?xml version="1.0" encoding=" gb2312"?>
    <ExLoginRsp Cache="">
        <RetVal Code="0" Remark="success"/>
        <UserId>1</UserId>
        <ServerInfo Name="myserver" ServerUuid="" ServerType="NVR100"  Version="0.130616">
    </ExLoginRsp>
    */
    STRY;
    McServerPeer* pSelf = (McServerPeer*)cookie;
    pSelf->OnGotLoginData(pData, dataLen);
    return 1;
    SCATCH;
    return -1;
}
int McServerPeer::OnGotLoginData(BYTE* pData,int dataLen)
{
    ICMS_CMD_HEADER* pHead = (ICMS_CMD_HEADER*)pData;
    QString Xml((char*)(pData+sizeof(ICMS_CMD_HEADER)));
    QMessageBox::about(NULL, Xml, Xml);

    //Len =0;
    if(pHead->dwCmdSubType==0x0a08)
    {
        QDomDocument doc;
        QString errorStr;
        int errorLine;
        int errorColumn;

        if (!doc.setContent(Xml, false, &errorStr, &errorLine,
                            &errorColumn)) {
            QMessageBox::about(NULL, errorStr, errorStr);
        }

        QDomElement root = doc.documentElement();
        QString roname = root.tagName();
        QMessageBox::about(NULL, roname, roname);
        if(root.tagName()!="LoginIn_ACK")
        {
            QMessageBox::about(NULL, tr("登陆失败"), tr("登陆失败"));
            return -1;
        }
        QDomElement UserInfoIDNode = root.firstChildElement("UserInfoID");
        if(UserInfoIDNode.isNull())
        {
            QMessageBox::about(NULL, tr("登陆失败"), tr("登陆失败"));
            return -1;
        }
        QDomElement ResultCodeNode = root.firstChildElement("ResultCode");
        if(ResultCodeNode.isNull())
        {
            QMessageBox::about(NULL, tr("登陆失败"), tr("登陆失败"));
            return -1;
        }
        if(ResultCodeNode.text().toInt()!=1)
        {
            QMessageBox::about(NULL, tr("登陆失败"), tr("登陆失败"));
            return -1;
        }
    }

    OnLogin();
    return 0;
}
int McServerPeer::DoLogout2CmsServer( ST_AFFAIR_CALLBACK* pAffairCallBack)
{
    STRY;

    char strSendXmlBuf[256] = {0};
    sprintf(strSendXmlBuf, "<?xml version=\"1.0\" encoding=\"gb2312\"?>"
                        "<ServerUnRegist_Req>"
                            "<ServerManageID/>"
                            "<MSCSID/>"
                            "<ServiceIP/>"
                            "<ClientIP>0.0.0.0</ClientIP>"
                        "</ServerUnRegist_Req>");

    m_pTcpConnect2Mc->SendCmd(0xff01, 0x0001, 0x0a07, strSendXmlBuf);

    return 1;

    SCATCH;
    return -1;
}

/*int McServerPeer::DoCheckUserLoginRespond(BYTE* pData, int dataLen)
{
    STRY;
    iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExLoginRsp")))
    {
        return -2;
    }

    xmlParser.IntoElem();
    if(false == xmlParser.FindElem(_T("RetVal")))
    {
        return -3;
    }

    int retVal = xmlParser.GetChildAttribInt(_T("Code"));
    if(retVal != 0)
    {
        return -4;
    }

    DWORD lastUserId = m_dwUserInfoID;
    if (true == xmlParser.FindElem(_T("UserId")))
    {
        m_dwUserInfoID = xmlParser.GetDataDWORD();
    }

    if (0 == lastUserId && m_dwUserInfoID)
    {
        return DeviceManager::GetDeviceManager()->DoInitialize(DEVICE_STAGE);
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);
    return m_dwUserInfoID >0 ? 1 : -3;

    SCATCH;
    return -1;
}
*/
/*int McServerPeer::DealUserLoginNotify(BYTE* pData, int dataLen)
{
    STRY;
    ST_ICMS_CMD_HEADER* pStCmdHeader	= (ST_ICMS_CMD_HEADER*)pData;

    const TCHAR* pXmlStart				= (const TCHAR*)pData + sizeof(ST_ICMS_CMD_HEADER);
    iCMSP_XmlParser	xmlParser1;
    xmlParser1.SetDoc(pXmlStart,pStCmdHeader->dwExndSize);

    if (true == xmlParser1.FindChildElem(_T("LoginId")))
    {
        m_dwUserInfoID = xmlParser1.GetChildDataDWORD ();
    }

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("LoginManagerNotifyRsp"));
    xmlParser.AddChildElem(_T("ResltId"),0);
    xmlParser.AddChildElem(_T("LoginId"),m_dwUserInfoID );

    const TCHAR* pchXmlOut	= xmlParser.GetDoc ();
    int nOutXmlLen			= _tcslen(pchXmlOut);
    BYTE* pDataOut			= new BYTE [sizeof(ST_ICMS_CMD_HEADER)+nOutXmlLen +8 ];
    if (NULL == pDataOut)
        return -3;

    ATLTRACE("%s send out :%s\r\n",__FUNCTION__,pchXmlOut);

    pStCmdHeader	= (ST_ICMS_CMD_HEADER*)pDataOut;
    pStCmdHeader->wSrcType				= m_wSrcType;
    pStCmdHeader->dwCmdSubType			= 0x0604;
    pStCmdHeader->dwSeqID				= ++m_nLastSendSeq;
    pStCmdHeader->dwExndSize			= nOutXmlLen;

    //send data to mc server
    BYTE* pRealDataStart				= pDataOut + sizeof(ST_ICMS_CMD_HEADER);
    CopyMemory(pRealDataStart,pchXmlOut,nOutXmlLen);
    LOGLINE;
    m_pTcpConnect2Mc ->SendData (m_McServerAddr,pDataOut,sizeof(ST_ICMS_CMD_HEADER)+nOutXmlLen);
    delete []pDataOut;

    SCATCH;
    return -1;
}*/

int McServerPeer::SendData2Mc(DWORD cmdID,char* pData,int dataLen,ST_AFFAIR_CALLBACK* pAffairCallBack
                              ,int dataType,int ackCmd,int mainType)
{
    int nResult				= -1;
    BYTE* pDataOut			= new BYTE [sizeof(ST_ICMS_CMD_HEADER)+dataLen +8 ];
    STRY;
    ST_ICMS_CMD_HEADER* pStCmdHeader	= (ST_ICMS_CMD_HEADER*)pDataOut;
    pStCmdHeader->wSrcType				= m_wSrcType;
    pStCmdHeader->dwCmdSubType			= cmdID;
    pStCmdHeader->dwSeqID				= ++m_nLastSendSeq;
    pStCmdHeader->dwExndSize			= dataLen;

    if (0 == ackCmd)
        ackCmd = cmdID + 1;
    if (pAffairCallBack)
    {
        CCachedAffairMap::GetInstance()->PushNewAffair(pAffairCallBack,m_nLastSendSeq,cmdID,ackCmd);
    }

    //send data to mc server
    BYTE* pRealDataStart				= pDataOut + sizeof(ST_ICMS_CMD_HEADER);
    memcpy(pRealDataStart,pData,dataLen);
    nResult = m_pTcpConnect2Mc ->SendData (pDataOut,sizeof(ST_ICMS_CMD_HEADER)+dataLen);
    SCATCH;

    delete []pDataOut;
    return nResult;
}

int McServerPeer::SendMonitorData2Mc(DWORD cmdID,char* pData,int dataLen,ST_AFFAIR_CALLBACK* pAffairCallBack
                              ,int dataType,int ackCmd)
{
    int nResult				= -1;
    BYTE* pDataOut			= new BYTE [sizeof(ST_ICMS_CMD_HEADER)+dataLen +8 ];
    STRY;
    ST_ICMS_CMD_HEADER* pStCmdHeader	= (ST_ICMS_CMD_HEADER*)pDataOut;
    pStCmdHeader->wSrcType				= EX_CLIENT_CONFIGER;
    pStCmdHeader->dwCmdSubType			= cmdID;
    pStCmdHeader->dwSeqID				= ++m_nLastSendSeq;
    pStCmdHeader->dwExndSize			= dataLen;

    if (0 == ackCmd)
        ackCmd = cmdID + 1;
    if (pAffairCallBack)
    {
        CCachedAffairMap::GetInstance()->PushNewAffair(pAffairCallBack,m_nLastSendSeq,cmdID,ackCmd);
    }

    //send data to mc server
    BYTE* pRealDataStart				= pDataOut + sizeof(ST_ICMS_CMD_HEADER);
    memcpy(pRealDataStart,pData,dataLen);
    nResult = m_pTcpConnect2Mc ->SendData (pDataOut,sizeof(ST_ICMS_CMD_HEADER)+dataLen);
    SCATCH;

    delete []pDataOut;
    return nResult;
}

int McServerPeer::OnStageInitFinished(int stageIdx)
{
    switch (stageIdx)
    {
    case DEVICE_STAGE:
        //LOGLINE;
        ///PublishProgressing(_T("计划初始化..."));
        ////PlanManager::GetPlanManager()->DoInitialize(PLAN_STAGE);
        break;
    case PLAN_STAGE:
        //LOGLINE;
        ///PublishProgressing(_T("报警初始化..."));
        ///AlarmManager::GetAlarmManager()->DoInitialize(ALARM_STAGE);
        break;
    case ALARM_STAGE:
        //LOGLINE;
        ///PublishProgressing(_T("地图初始化..."));
       /// MapManager::GetMapManager()->DoInitialize(MAP_STAGE);
        break;
    case MAP_STAGE:
        //LOGLINE;
        ////////////PublishProgressing(_T("用户管理初始化..."));
       ////////////////// UserManager::GetUserManager()->DoInitialize(USER_STAGE);
        break;
    case USER_STAGE:
        //LOGLINE;
        ///PublishProgressing(_T("巡检初始化..."));
        ///TourManager::GetTourManager()->DoInitialize(TOUR_STAGE);
        break;
    case TOUR_STAGE:
        //LOGLINE;
        ////PublishProgressing(_T("日志初始化..."));
        ///LogManager::GetLogManager()->DoInitialize(LOG_STAGE);
        break;
    case LOG_STAGE:
        //LOGLINE;
        /////PublishProgressing(_T("服务器管理初始化..."));
        ////ServerManager::GetServerManager()->DoInitialize(SERVER_STAGE);
        break;
    case SERVER_STAGE:
//		LOGLINE;
//		DiskManager::GetDiskManager()->DoInitialize(DISK_STAGE);
//		break;

//	case DISK_STAGE:
        //LOGLINE;
        //////////////////StorageManager::GetStorageManager()->DoInitialize(STORAGE_STAGE);
        break;
    case STORAGE_STAGE:
        //LOGLINE;
        PublishProgressFinish(true);
        break;

    }
    return 0;
}

int McServerPeer::DoCheckHeartBeatPacket()
{
    STRY;
    /*BYTE* pDataOut = new BYTE [sizeof(ST_ICMS_CMD_HEADER)+8 ];

    ST_ICMS_CMD_HEADER* pStCmdHeader	= (ST_ICMS_CMD_HEADER*)pDataOut;
    pStCmdHeader->wSrcType				= m_wSrcType;
    pStCmdHeader->dwCmdSubType			= EX_HEART_BEAT_REQ;
    pStCmdHeader->dwSeqID				= ++m_nLastSendSeq;
    pStCmdHeader->dwExndSize			= 0;

    //send data to alarm server
    LOGLINE;
    m_pTcpConnect2Mc ->SendData (pDataOut,sizeof(ST_ICMS_CMD_HEADER));

    delete []pDataOut;*/
    return 1;

    SCATCH;
    return -1;
}
