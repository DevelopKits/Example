#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "connector.h"
#include "view.h"
#include "review.h"
namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(Connector* Conn, QWidget *parent = 0);
    ~MainWindow();

private slots:
    void View();
    void Review();
private:
    void CreateActions();
    Ui::MainWindow *ui;
    VReview *pReview;
    VView *pView;

    //QWidget* pViewWidget;
    //QWidget* pReviewWidget;
    QAction *ViewAction;
    QAction *ReviewAction;
    Connector* m_pConn;


};

#endif // MAINWINDOW_H
