#ifndef FORMSYSTEMINFO_H
#define FORMSYSTEMINFO_H

#include <QWidget>
#include "configconnector.h"
#include <qdatetime.h>

namespace Ui {
class FormSystemInfo;
}

class FormSystemInfo : public QWidget
{
    Q_OBJECT
    
public:
    explicit FormSystemInfo(ConfigConnector *conn, QWidget *parent = 0);
    ~FormSystemInfo();
    
    int HandleSystemInfoAck(QStringList cmdlist);
private slots:
    void on_pushButton_SynDateTime_clicked();

    void on_pushButton_getsysinfo_clicked();

    void on_pushButton_onekeyrestore_clicked();

    void on_pushButtonrestartctrlsave_clicked();

    void timerUpDate();
    void on_pushButton_synccomputer_clicked();

private:


    Ui::FormSystemInfo *ui;
    ConfigConnector *m_conn;
    QTimer *timer;


};

#endif // FORMSYSTEMINFO_H
