#ifndef MESSAGEHELPER_H
#define MESSAGEHELPER_H

#include <QtXml>

class MessageHelper
{
public:
    static int BuildCmdMsg(BYTE** ppOutMsg, int& nCmdLen, int nSrcType, int nCmdType, int nCmdSeq, QDomDocument& xmlDoc);

    static int ParseCmdMsg(QDomDocument& xmlDoc, TCHAR** pCmdMsg, ST_ICMS_CMD_HEADER& stCmdHeader, BYTE* pInMsg);

    static int BuildCmdXml(BYTE** ppOutMsg, int& nCmdLen, QDomDocument& xmlDoc); //unicode to utf8

    static int FreeTcharMsg(TCHAR* pCmdMsg);

    static int FreeByteMsg(BYTE* pCmdMsg);

};

#endif // MESSAGEHELPER_H
