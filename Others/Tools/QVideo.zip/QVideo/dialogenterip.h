#ifndef DIALOGENTERIP_H
#define DIALOGENTERIP_H

#include <QDialog>

namespace Ui {
class DialogEnterIp;
}

class DialogEnterIp : public QDialog
{
    Q_OBJECT
    

public:
    explicit DialogEnterIp(QWidget *parent = 0);
    ~DialogEnterIp();
    QString m_IP;
private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogEnterIp *ui;
};

#endif // DIALOGENTERIP_H
