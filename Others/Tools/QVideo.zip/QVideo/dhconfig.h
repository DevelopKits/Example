#ifndef DHCONFIG_H
#define DHCONFIG_H

#include <QWidget>
#include "configconnector.h"

namespace Ui {
class Dhconfig;
}

class Dhconfig : public QWidget
{
    Q_OBJECT
    
public:
    explicit Dhconfig(ConfigConnector *conn,QWidget *parent = 0);
    ~Dhconfig();

    int HandleSystemInfoAck(QStringList cmdlist);

private slots:
    void on_pushButton_SubMit_clicked();
    void on_pushButton_reboot_clicked();
    void on_pushButton_shutdown_clicked();

private:
    Ui::Dhconfig *ui;
    ConfigConnector *m_conn;
};

#endif // DHCONFIG_H
