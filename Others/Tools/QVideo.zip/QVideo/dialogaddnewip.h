﻿#ifndef DIALOGADDNEWIP_H
#define DIALOGADDNEWIP_H

#include <QDialog>

namespace Ui {
class DialogAddNewIP;
}

class DialogAddNewIP : public QDialog
{
    Q_OBJECT

public:
    explicit DialogAddNewIP(QWidget *parent = 0);
    ~DialogAddNewIP();

    QString newIp;
    QString newMask;
private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogAddNewIP *ui;
};

#endif // DIALOGADDNEWIP_H
