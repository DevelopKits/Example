﻿#include "updateform.h"
#include <QMessageBox>
#include "ui_updateform.h"
#include <QFileDialog>
#include "seanfileserver.h"
#include <QFileDialog>
#include <QtXml>
#include <QRegExp>
#include <QMessageBox>

UpdateForm::UpdateForm(ConfigConnector *conn, QWidget *parent) :
    m_conn(conn),
    QWidget(parent),
    ui(new Ui::UpdateForm)
{
    ui->setupUi(this);

    ui->progressBar->setValue(0);
    ui->lineEdit_doshname->setEnabled(ui->checkBox_dosh->isChecked());

    ui->checkBox_updateall1->setChecked(true);
    ui->groupBox_2->setVisible(false);
    ui->pushButton_restore_old_version->setVisible(false);
}

UpdateForm::~UpdateForm()
{
    delete ui;
}
int UpdateForm::HandleUpdateAck(QStringList cmdlist)
{
    qDebug() << cmdlist[1];
    qDebug() << cmdlist[2];

    if(cmdlist[1]=="updatenvrapp_withfd"
        ||cmdlist[1]=="updatenmc_withfd"
        ||cmdlist[1]=="updatendm_withfd"
        ||cmdlist[1]=="restoredatabase"
        ||cmdlist[1]=="updateall1_withfd"
        || cmdlist[1]=="dhupdateudsmgr_withfd")
    {
        if(cmdlist[2].mid(0,5)=="info=")
        {
            ui->textEdit_Info->append(cmdlist[2]);
        }
        else if(cmdlist[2].mid(0,7)=="result=")
        {
            ui->textEdit_Info->append(cmdlist[2]);
        }
        else if(cmdlist[2].mid(0,7)=="error=")
        {
            ui->textEdit_Info->append(cmdlist[2]);
        }
    }
    else if(cmdlist[1]=="restorelastnvrapp_withfd")
    {
        ui->textEdit_Info->append(cmdlist[2]);
    }
    else if(cmdlist[1]=="restoredatabase")
    {
        if(cmdlist[2]=="result=ok")
        {
            QMessageBox::about(NULL, tr(" 恢复成功  "), tr(" 恢复成功   "));
            return 0;
        }
        else
        {
            QMessageBox::about(NULL, tr(" 恢复失败  "), tr(" 恢复失败  "));
            return 0;
        }
    }
    else if(cmdlist[1]=="backupdatabase")
    {
        if(cmdlist[2]=="result=ok")
        {
            QMessageBox::about(NULL, tr(" 备份成功  "), tr(" 备份成功   "));
            return 0;
        }
        else
        {
            QMessageBox::about(NULL, tr(" 备份失败  "), tr(" 备份失败  "));
            return 0;
        }
    }

    return 0;
}

void UpdateForm::on_pushButtonUpdate_clicked()
{
    ui->progressBar->setValue(0);
}

void UpdateForm::on_pushButton_remote_chosefile_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
            tr("选择"),
            tr("*.*"),
            tr("remote(*.*)"));
    if (!fileName.isNull())
    {
        ui->textEdit_Info->setText(fileName);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_remote_upload_clicked()
{
    ui->progressBar->setValue(0);

    QString  fileName = ui->textEdit_Info->toPlainText();

    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    //QString Ip = SeanFileServer::Instance()->GetServiceIp();
    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExUpdateRemoteSoReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);

    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("updateorbackup:updateremoteso:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::OnSeanFileSending(struct SeanUploadFileCtrlInfo CtrlInfo)
{
    float f = (float)CtrlInfo.bytesWritten/CtrlInfo.totalBytes;

    ui->progressBar->setValue(f*100);
}
void UpdateForm::OnSeanFileSendError(int Error)
{


}
void UpdateForm::OnSeanFileSendFinish()
{


}

void UpdateForm::on_pushButton_nvrcore_backup_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this,
            tr("保存"),
            QString(tr("nvrcore")+m_conn->getJtDeviceInfo().RemoteUdpIp+QString(".sql.tar.gz")),
            tr("backupfile (*tar.gz)"));
    if (!fileName.isNull())
    {
        SeanUploadFileInfo UploadFileInfo;
        SeanFileServer::Instance()->GenRecvFileTask(fileName, UploadFileInfo, this);

        /*QFile file(fileName);
        if(!file.open(QIODevice::WriteOnly)) {

        }*/

        QString Ip = m_conn->getJtDeviceInfo().LocalIp;
        quint16 Port = SeanFileServer::Instance()->GetServicePort();

/*
<?xml version='1.0' encoding='gb2312'?>
<ExBackupNvrDatabaseReq>
    <File Token="{5ae2fa6a-a9ec-4114-9d45-44ffb94caa46}">nvrcore.sql.tar.gz</File>
    <Connect Mode="Tcp" Ip="192.168.0.100" Port="19999"/>
</ExBackupNvrDatabaseReq>
*/

        QDomDocument doc;
        doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExBackupNvrDatabaseReq/>"),false);

        QDomElement FileNode = doc.createElement("File");
        FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);

        QFileInfo fi = QFileInfo(fileName);
        FileNode.appendChild(doc.createTextNode(fi.fileName()));
        doc.documentElement().appendChild(FileNode);

        QDomElement ConnectNode = doc.createElement("Connect");
        ConnectNode.setAttribute(tr("Ip"),Ip);
        ConnectNode.setAttribute(tr("Port"),Port);
        ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
        doc.documentElement().appendChild(ConnectNode);

        QString XMLStr = doc.toString(0);
        XMLStr = XMLStr.simplified();

        QString cmd("updateorbackup:backupdatabase:");

        QByteArray ACmd = cmd.append(XMLStr).toLatin1();

        m_conn->SendCmd(ACmd.data());
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_5_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
            tr("打开"),
            tr("nvrcore.sql.tar.gz"),
            tr("gz(*.gz)"));
    if (!fileName.isNull())
    {
        ui->textEdit_Info->setText(fileName);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_restoredatabase_clicked()
{
    if(QMessageBox::information(NULL, "确认", "导入数据后回格式化存储，是否继续？  ", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    ui->progressBar->setValue(0);

    QString  fileName = ui->textEdit_Info->toPlainText();
    if(fileName.length()==0)
    {
        QMessageBox::about(NULL, tr(" 选择文件  "), tr(" 选择文件   "));
        return;
    }


    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExRestoreNvrDatabaseReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);

    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("updateorbackup:restoredatabase:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::on_pushButton_commonupgedate_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
            tr("打开"),
            tr(""),
            tr("common(*.*)"));
    if (!fileName.isNull())
    {
        ui->textEdit_Info->setText(fileName);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_2_clicked()
{
/*
<?xml version='1.0' encoding='gb2312'?>
<ExUpdateRemoteSoReq>
<File Size="142875" Token="{f08b5318-2729-4cc5-baff-a8cd934c5d50}" md5="131973246ea8a04817080441bf06a251" Path="/home/" >libupdateorbackup.so</File>
<Action AddX="" Unzip="" Dosh="" shName="" />
<Connect Mode="Tcp" Ip="192.168.0.100" Port="10239"/>
</ExUpdateRemoteSoReq>
*/

    ui->progressBar->setValue(0);

    QString  fileName = ui->textEdit_Info->toPlainText();

    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExCommonUpdateReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);

    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ActionNode = doc.createElement("Action");
    ActionNode.setAttribute(tr("AddX"),  UploadFileInfo.m_Size);
    ActionNode.setAttribute(tr("Unzip"), UploadFileInfo.m_Md5);
    ActionNode.setAttribute(tr("Dosh"),  UploadFileInfo.m_Token);
    ActionNode.setAttribute(tr("shName"),UploadFileInfo.m_Token);
    doc.documentElement().appendChild(ActionNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("updateorbackup:restoredatabase:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::on_checkBox_dosh_clicked()
{
    ui->lineEdit_doshname->setEnabled(ui->checkBox_dosh->isChecked());
}

void UpdateForm::on_pushButton_restore_old_version_clicked()
{
    QString cmd("updateorbackup:restorelastnvrapp:");
    QByteArray ACmd = cmd.toLatin1();
    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::on_pushButton_updateall1_clicked()
{
    fileNameAll1 = QFileDialog::getOpenFileName(this,
            tr("打开"),
            tr(""),
            tr("(*.update)"));
    if (!fileNameAll1.isNull())
    {
        ui->textEdit_Info->setText(fileNameAll1);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_startupdateall1_clicked()
{
    ui->progressBar->setValue(0);

    QString  fileName = fileNameAll1;

    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExUpdateAll1AppReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);
    if(ui->checkBox_updateall1->isChecked())
    {
        FileNode.setAttribute(tr("New"),1);
    }
    else
    {
        FileNode.setAttribute(tr("New"),0);
    }

       FileNode.setAttribute(tr("WithStorage"),0);

    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("updateorbackup:updateall1:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::on_pushButton_choose_uds_clicked()
{
    fileNameUDSMgr = QFileDialog::getOpenFileName(this,
            tr("打开"),
            tr(""));
    if (!fileNameUDSMgr.isNull())
    {
        ui->textEdit_Info->setText(fileNameUDSMgr);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_uds_update_clicked()
{
    ui->progressBar->setValue(0);

    QString  fileName = fileNameUDSMgr;

    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExUpdateUDSMgrReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);


    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("dhconfig:dhupdateudsmgr:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void UpdateForm::on_pushButton_choose_udsall_clicked()
{
    fileNameUDSMgr = QFileDialog::getOpenFileName(this,
            tr("打开"),
            tr(""));
    if (!fileNameUDSMgr.isNull())
    {
        ui->textEdit_Info->setText(fileNameUDSMgr);
    }
    else
    {
        //点的是取消
    }
}

void UpdateForm::on_pushButton_udsall_update_clicked()
{
    ui->progressBar->setValue(0);

    QString  fileName = fileNameUDSMgr;

    SeanUploadFileInfo UploadFileInfo;
    SeanFileServer::Instance()->GenSendFileTask(fileName, UploadFileInfo, this);

    QString Ip = m_conn->getJtDeviceInfo().LocalIp;
    quint16 Port = SeanFileServer::Instance()->GetServicePort();

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExUpdateUDSMgrAllReq/>"),false);

    QDomElement FileNode = doc.createElement("File");
    FileNode.setAttribute(tr("Size"),UploadFileInfo.m_Size);
    FileNode.setAttribute(tr("md5"),UploadFileInfo.m_Md5);
    FileNode.setAttribute(tr("Token"),UploadFileInfo.m_Token);


    QFileInfo fi = QFileInfo(fileName);
    FileNode.appendChild(doc.createTextNode(fi.fileName()));
    doc.documentElement().appendChild(FileNode);

    QDomElement ConnectNode = doc.createElement("Connect");
    ConnectNode.setAttribute(tr("Ip"),Ip);
    ConnectNode.setAttribute(tr("Port"),Port);
    ConnectNode.setAttribute(tr("Mode"),tr("Tcp"));
    doc.documentElement().appendChild(ConnectNode);

    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("dhconfig:dhUpdateUdsMgrAll:");

    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());
}

