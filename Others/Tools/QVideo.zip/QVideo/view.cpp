#include "view.h"
#include "ui_view.h"
#include <QMessageBox>
#include "COMM_HEADER.h"
VView::VView(QWidget *parent, Connector* Conn) :
    QWidget(parent),Conn(Conn),
    ui(new Ui::View)
{
    QMessageBox::about(NULL, "dd", "dsdf");
    ui->setupUi(this);

    ui->treeWidget->setColumnCount(1);
    ui->treeWidget->setHeaderLabel(tr("设备"));
    QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("图像1")));
    QTreeWidgetItem *imageItem1_1 = new QTreeWidgetItem(imageItem1,QStringList(QString("图像2")));
    imageItem1->addChild(imageItem1_1);
    ui->treeWidget->expandAll(); //结点全部展开

    QObject::connect(Conn, SIGNAL(OnRecved(char*, int)), this, SLOT(OnReciveData(char*, int)));
}

VView::~VView()
{
    delete ui;
}
void VView::on_pushButton_clicked(void)
{
    QMessageBox::about(NULL, " 点击 ", " 点击2 ");
}
void VView::OnReciveData(char* Data, int Len)
{
    ICMS_CMD_HEADER* pHead = (ICMS_CMD_HEADER*)Data;
    QString Xml(Data+sizeof(ICMS_CMD_HEADER));
    QMessageBox::about(NULL, Xml, Xml);

    switch(pHead->dwCmdSubType)
    {
        case 0x0a08://获取组织机构数
        break;
        case 0x0a09://获取设备信息
        break;
        default:
        ;
    }
}
