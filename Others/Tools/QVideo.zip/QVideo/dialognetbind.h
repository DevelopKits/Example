﻿#ifndef DIALOGNETBIND_H
#define DIALOGNETBIND_H

#include <QDialog>
#include <COMM_HEADER.h>
#include <QMap>
namespace Ui {
class DialogNetBind;
}

class DialogNetBind : public QDialog
{
    Q_OBJECT

public:
    explicit DialogNetBind(QMap<QString, struct st_sean_netinterface> NetIfaceS, QWidget *parent = 0);
    ~DialogNetBind();

    QString m_BindIp;
    QString m_BindMask;
    QString m_BindGate;
    QMap<QString, struct st_sean_netinterface> m_NetIfaceS;
    int m_BindMode;
private slots:
    void on_buttonBox_accepted();

private:
    Ui::DialogNetBind *ui;
};

#endif // DIALOGNETBIND_H
