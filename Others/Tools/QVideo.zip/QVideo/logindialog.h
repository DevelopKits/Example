﻿#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QtNetwork>
#include "connector.h"
#include "configconnector.h"
#include "mcserverpeer.h"
#include "COMM_HEADER.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog, public ISystemInitProgressSubscriber
{
    Q_OBJECT
    
public:
    explicit LoginDialog(Connector* Conn, QWidget *parent = 0);
    ~LoginDialog();
public slots:
    void on_pushButtonLogin_clicked();
private slots:
    void on_SearchButton_clicked();
    void GetSearchResponsDatagrams();

    void on_ConfigButton_clicked();

    void on_DeviceListWidget_itemClicked(QListWidgetItem *item);

    void on_pushButton_modifyip_clicked();

    void on_pushButton_reboot_clicked();

    void on_pushButton_halt_clicked();

private:
    virtual void OnLogin();
    virtual int OnSysInitProgressInfo(QString strProgressInfo);
    virtual int OnSysInitFinish(bool bLoadData);

    void HandleUdpCmd_GetAddrInfoRsp(struct MuiltCastCmd *Cmd);

    Ui::LoginDialog *ui;
    Connector* m_pConn;
    QUdpSocket *m_SearchUdpSocket;
    QMap<QString, JtDeviceInfo> m_DeviceInfoS;

    //QMap<QString, QMap<QString, struct st_sean_netinterface> > m_DeviceNetinterfaceInfoS;

    int m_uMagic;//发送组播时识别自身的随机数
    int m_Order;
};

#endif // LOGINDIALOG_H
