﻿void on_pushButtonaubifacedel_clicked();
void on_pushButtonaubifacedel_clicked();
void on_pushButtonsubifaceadd_clicked();
#ifndef NETCONFIGFORM_H
#define NETCONFIGFORM_H

#include <QWidget>
#include "configconnector.h"
#include <QtGui/QTreeWidget>
namespace Ui {
class NetConfigForm;
}

class NetConfigForm : public QWidget
{
    Q_OBJECT
    
public:
    explicit NetConfigForm(ConfigConnector *conn, JtDeviceInfo DeviceInfo, QWidget *parent = 0);
    ~NetConfigForm();
    
private slots:

    void on_treeWidget_netinterface_itemClicked(QTreeWidgetItem *item, int column);

    void on_pushButton_netbind_clicked();

    void on_pushButtonnetunbind_clicked();

    void on_pushButton_ChangeIP_clicked();

    void on_pushButtonsubifaceadd_clicked();

    void on_pushButton_clicked();

    void on_pushButtonaubifacedel_clicked();

private:
    Ui::NetConfigForm *ui;

    ConfigConnector *m_conn;

    JtDeviceInfo m_DeviceInfo;

    QMap<int,QString> NetStateDescriptionS;
};

#endif // NETCONFIGFORM_H
