#include "connector.h"
#include "COMM_HEADER.h"
#include <string.h>

Connector::Connector(QObject *parent) :
    QTcpSocket(parent)
{
    RecvBufLen = 4096;
    RecvBuf = new char[RecvBufLen];
    CmdBuf = new char[RecvBufLen*4];

    QObject::connect(this, SIGNAL(readyRead()), this, SLOT(OnReciveData()));
    //QObject::connect(this, SIGNAL(disconnected()), this, SLOT(OnDisConnected()));
    //QObject::connect(this, SIGNAL(connected()), this, SLOT(OnConnected()));
}
Connector::~Connector()
{
    delete RecvBuf;
    delete CmdBuf;
}
int Connector::SetCallBackSink(ITcpCallbackSink* pSink, int serverType)
{
    QObject::connect(this, SIGNAL(OnRecved(char*, int)), pSink, SLOT(OnRecvData(char*, int)));
    QObject::connect(this, SIGNAL(disconnected()), pSink, SLOT(OnClosed()));
    QObject::connect(this, SIGNAL(connected()), pSink, SLOT(OnConnected()));
    //QObject::connect(this, SIGNAL(connected()), pSink, SLOT(OnConnected()));

    return 0;
}

void Connector::OnReciveData()
{
    COMM_HEADER	commhead;
    int dwRecvLen = 0;
    do
    {
        if(-1==read((char*)&commhead, sizeof(COMM_HEADER)))
        {
            //error!!!!!
            break;
        }

        int dwNowRecvLen = 0;
        while(dwNowRecvLen<commhead.nowPacketSize)
        {
            int len = (RecvBufLen < (commhead.nowPacketSize-dwNowRecvLen)) ? RecvBufLen : (commhead.nowPacketSize-dwNowRecvLen);
            len = read((char *)RecvBuf, len);
            if(-1 == len)
            {
                //error!!!!!
                break;
            }
            memcpy(CmdBuf+dwRecvLen+dwNowRecvLen, RecvBuf, len);
            dwNowRecvLen += len;
        }
        dwRecvLen += dwNowRecvLen;
    }while(dwRecvLen < commhead.totalPacketSize);

    CmdBuf[dwRecvLen] = 0;

    emit OnRecved(CmdBuf, dwRecvLen);
}
int Connector::SendCmd(unsigned short wSrcType, unsigned short wCmdMainType, unsigned int dwCmdSubType,char *strXml)
{
    int nXmlLen = strlen(strXml) + 1;

    char* pDataOut= new char [sizeof(COMM_HEADER) + sizeof(ST_ICMS_CMD_HEADER) + nXmlLen];
    if (NULL == pDataOut)
        return -1;

    COMM_HEADER *pCOMM_HEADER = (COMM_HEADER*)pDataOut;
    pCOMM_HEADER->seqId = 1;
    pCOMM_HEADER->nowPacketSize = sizeof(ICMS_CMD_HEADER)+nXmlLen;
    pCOMM_HEADER->totalPacketSize = sizeof(ICMS_CMD_HEADER)+nXmlLen;

    ST_ICMS_CMD_HEADER* pStCmdHeader	= (ICMS_CMD_HEADER*)(pDataOut + sizeof(COMM_HEADER));
    pStCmdHeader->wSrcType				= wSrcType;
    pStCmdHeader->wCmdMainType			= wCmdMainType;
    pStCmdHeader->dwCmdSubType			= dwCmdSubType;
    pStCmdHeader->dwSeqID				= ++SeqID;
    pStCmdHeader->wExtendType			= 1;
    pStCmdHeader->dwExndSize			= nXmlLen;

    char* pRealDataStart				= pDataOut + sizeof(ST_ICMS_CMD_HEADER) + sizeof(COMM_HEADER);
    memcpy(pRealDataStart, strXml, nXmlLen);
    pDataOut[sizeof(COMM_HEADER) + sizeof(ST_ICMS_CMD_HEADER) + nXmlLen-1]=0;

    int err = write(pDataOut, sizeof(ICMS_CMD_HEADER) + sizeof(COMM_HEADER) + nXmlLen);
    if(-1==err)
    {
        //emit ;
    }
    //int err = send(m_fd,(const char *)pDataOut,sizeof(ICMS_CMD_HEADER) + sizeof(COMM_HEADER) + nXmlLen, 0);

    delete [] pDataOut;

    return err;
}
int Connector::SendData(const BYTE* Data, int Len)
{
    int err = write((char*)Data, Len);
    if(-1==err)
    {
        //emit ;
    }

    return err;
}
