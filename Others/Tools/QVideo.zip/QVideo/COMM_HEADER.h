﻿#ifndef COMM_HEADER_H
#define COMM_HEADER_H

#include <stdlib.h>
#include <QString>
#include <QMap>
#ifndef WORD
    #define WORD unsigned short
#endif

#ifndef DWORD
    #define DWORD unsigned long
#endif

#ifndef BYTE
    #define BYTE unsigned char
#endif

#ifndef UINT64
    #define UINT64 unsigned long long
#endif

#ifndef BOOL
    #define BOOL bool
#endif

#ifndef NULL
    #define NULL  0
#endif

#define STRY	try{
#define SCATCH		}catch(...){};

#define LOGLINE

#pragma pack(push, 1)

typedef struct  stCOMM_HEADER
{
    int				seqId;
    int				totalPacketSize;
    int				nowPacketSize;
}COMM_HEADER;

typedef struct ST_ICMS_CMD_HEADER
{
    unsigned short				wSrcType;			//源的类型
    unsigned short				wCmdMainType;       //信令的主类型
    unsigned int				dwCmdSubType;       //信令的子类型
    unsigned int				dwSeqID;            //信令序号
    unsigned short				wExtendType;        //扩展数据类型
    unsigned int				dwExndSize;         //扩展数据大小
}ICMS_CMD_HEADER;

#pragma pack(pop)

struct ST_ICMSLOGIN_PARAM
{
    QString		userName;
    QString		userPass;
    QString		cmsServerName;
    QString		cmsServerIp;
    short		cmsServerPort;
    QString		cmsSlaveServerIp;
    //WORD		cmsAppType;		//系统类型 monitor=ICMS_CLIENT_MONITOR matrix_client=ICMS_CLIENT_MATRIX matrix_server=ICMS_SERVER_MATRIX
};
struct st_sean_sub_netinterface
{
    QString name;
    QString ipv4;
    QString netmask;
};
struct st_sean_netinterface
{
    QString name;

    int state; //是否有类似ifcfg-eth0的配置文件

    int receive_bytes;
    int receive_packets;

    int transmit_bytes;
    int transmit_packets;

    int type; //  1: 独立 2: slave 3 bond
    QString bindto;
    QString ipv4;
    QString netmask;
    QString netgate;
    QString mac;
    QString dns1;
    QString dns2;
    QString ipv6;

    QMap<QString, struct st_sean_sub_netinterface> SubInterfaceS;
};


#define EX_CLIENT_CONFIGER 1

//iSwitch,iAlarm,iMap,iMonitor,iManager主动发起的公共请求-> MC
#define		ICMS_TYPE_TOMC_LOGIN_REQ								0x0a07
#define		ICMS_TYPE_TOMC_LOGIN_ACK								0x0a08

#endif // COMM_HEADER_H
