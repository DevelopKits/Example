﻿#ifndef CACHEDAFFAIR_H
#define CACHEDAFFAIR_H

#include <map>
using namespace std;

#include <QtGui>

#include "COMM_HEADER.h"

struct ST_AFFAIR_CALLBACK
{
public:
    typedef int (*OnGotData)(DWORD cookie,BYTE* pData,int dataLen);
    typedef int (*OnAffairOverTime)(DWORD cookie);

    ST_AFFAIR_CALLBACK (DWORD cookie
                        ,OnGotData pOnGotData = NULL//收到数据的回调函数
                        ,OnAffairOverTime pOnAffairOverTime = NULL//事务超时回调函数
                        ,int overTime = 4000)//超时时间,毫秒为单位
        :m_dwUserCookie(cookie),m_pOnGotData(pOnGotData),m_pOnAffairOverTime(pOnAffairOverTime)
        ,m_nOverTime(overTime),m_pRecvData(NULL),m_pRecvSize(0)
    {};
    ~ST_AFFAIR_CALLBACK()
    {
        if (NULL != m_pRecvData)
        {
            free(m_pRecvData);
            m_pRecvData	= 0;
        }
            m_pRecvSize = 0;
    }

    DWORD					m_dwUserCookie;
    OnGotData				m_pOnGotData;
    OnAffairOverTime		m_pOnAffairOverTime;
    int						m_nOverTime;
    BYTE*					m_pRecvData;
    int						m_pRecvSize;
};

class CCachedAffair
{
public:

    QWaitCondition*								m_handleOverTime;
    QMutex*                                     m_Conditionmutex;
    BYTE*										m_pRecvDataBuf;
    DWORD										m_recvDataSize;
    DWORD										m_recvDataCanceled;

    CCachedAffair(ST_AFFAIR_CALLBACK* pAffairCallBack,DWORD dwDevId);
    virtual ~CCachedAffair(void);
    void SetCommandIdxPair(int outCmdIdx,int exptedRecvCmdIdx);
    void SetSequencePair(int outSeqIdx);
    int DoOverTime();
    int DoOnGotData(BYTE* pData, int dataLen);

    ST_AFFAIR_CALLBACK::OnGotData				m_fpOnGotData;
    ST_AFFAIR_CALLBACK::OnAffairOverTime		m_fpOnAffairOverTime;
    DWORD										m_dwUserCookie;
    DWORD										m_dwPushedTime;
    int											m_nOverTime;
    int											m_nOutCmdIdx;
    int											m_nExptedRecvCmdIdx;
    int											m_nOutSeqIdx;
    DWORD										m_dwDevId;
    BOOL										m_bOverTime;
};

class CCachedAffairMap
{
private:
    map<UINT64,CCachedAffair*>			m_cachedAffairMap;
    UINT64								m_lastSeq;
    QMutex                               m_simpleCS;

    template <class K,class V>
    class CBeOverTime
    {
    public:
        CBeOverTime(DWORD nowTime)
            :m_dwNowTime(nowTime){}
        bool operator() (const pair<UINT64,CCachedAffair*> &rhs)
        {
            CCachedAffair* pSelf = rhs.second ;
            if (NULL == pSelf)
                return false;

            return rhs.second ->m_dwPushedTime + rhs.second ->m_nOverTime < m_dwNowTime ? true : false ;
        }
    private:
        DWORD			m_dwNowTime;
    };

    template <class K,class V>
    class CBeExpectedDataComing
    {
    public:
        CBeExpectedDataComing(int recvCmdIdx,int recvSeqIdx)
            : m_nRecvCmdIdx(recvCmdIdx),m_nRecvSeqIdx(recvSeqIdx){}
        bool operator() (const pair<UINT64,CCachedAffair*> &rhs)
        {
            CCachedAffair* pAffairItem = rhs.second ;
            if (NULL == pAffairItem)
                return false;

            return (pAffairItem->m_nExptedRecvCmdIdx == m_nRecvCmdIdx ) ? true : false;
            //because of mc team not do the right sequence number,so comment following
            //return (   pAffairItem->m_nExptedRecvCmdIdx == m_nRecvCmdIdx
            //	    && pAffairItem->m_nOutSeqIdx		 == m_nRecvSeqIdx) ? true : false;
        }
    private:
        int				m_nRecvCmdIdx;
        int				m_nRecvSeqIdx;
    };
protected:
    CCachedAffairMap();
    ~CCachedAffairMap();
public:
    static CCachedAffairMap* GetInstance();

    int PushNewAffair(ST_AFFAIR_CALLBACK* pAffairCallBack,int nOutSeqId,int nOutCmdId,int nExpetedCmdId,DWORD dwDevId = 0);
    int CheckBeOverTime(DWORD nowTime);
    int CheckBeExptedData(BYTE* pData, int dataLen);
    int ClearCachedItem();
};

#endif // CACHEDAFFAIR_H
