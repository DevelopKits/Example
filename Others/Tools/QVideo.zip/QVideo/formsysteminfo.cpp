#include <QMessageBox>
#include "formsysteminfo.h"
#include "ui_formsysteminfo.h"
#include <QtCore>
#include <QtXml>

static QCheckBox * WeekCboxS[7];



FormSystemInfo::FormSystemInfo(ConfigConnector *conn, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormSystemInfo),m_conn(conn)
{
    ui->setupUi(this);

    const QDateTime DateTime = QDateTime::currentDateTime();
    ui->textEdit_SysInfo->append(DateTime.toString());
    ui->dateTimeEdit->setDateTime(DateTime);

    //timer = new QTimer(this);
    //connect(timer,SIGNAL(timeout()),this,SLOT(timerUpDate()));
    //timer->start(1000);

    ui->timeEditrestarttime->setTime(QTime(2,0,0,0));

    QString cmd("sysconfig:restartcontrolget:");
    QByteArray ACmd = cmd.toLatin1();
    m_conn->SendCmd(ACmd.data());

    WeekCboxS[0] =ui->checkBoxSun;   ///星期日
    WeekCboxS[1] =ui->checkBoxMon;
    WeekCboxS[2] =ui->checkBoxTue;
    WeekCboxS[3] =ui->checkBoxWed;
    WeekCboxS[4] =ui->checkBoxThu;
    WeekCboxS[5] =ui->checkBoxFri;
    WeekCboxS[6] =ui->checkBoxSat;

    ui->groupBox->setVisible(false);
}

FormSystemInfo::~FormSystemInfo()
{
    delete ui;
}
void FormSystemInfo::timerUpDate()
{
    const QDateTime DateTime = QDateTime::currentDateTime();
    ui->dateTimeEdit->setDateTime(DateTime);
}
int FormSystemInfo::HandleSystemInfoAck(QStringList cmdlist)
{
    qDebug() << cmdlist[1];
    qDebug() << cmdlist[2];

    if(cmdlist[1]=="getsysteminfo_withfd")
    {
        ui->textEdit_SysInfo->append(cmdlist[2]);
    }
    else if(cmdlist[1]=="onekeyrestore_withfd")
    {
        ui->textEdit_SysInfo->append(cmdlist[2]);
    }
    else if(cmdlist[1]=="restartcontrolget")
    {
        /*
        <?xml version='1.0' encoding='gb2312'?>
        <ExSaveRestartCtrlReq>
            <DayList time="02:00:00" >
                <Day>1</Day>
                <Day>5</Day>
            </DayList>
        </ExSaveRestartCtrlReq>
        */

        QString s(cmdlist[2]);

        QDomDocument doc;
        QString errorStr;
        int errorLine;
        int errorColumn;

        if (!doc.setContent(s, false, &errorStr, &errorLine,
                            &errorColumn)) {
        }

        QDomElement root = doc.documentElement();

        WeekCboxS[0]->setChecked(false);
        WeekCboxS[1]->setChecked(false);
        WeekCboxS[2]->setChecked(false);
        WeekCboxS[3]->setChecked(false);
        WeekCboxS[4]->setChecked(false);
        WeekCboxS[5]->setChecked(false);
        WeekCboxS[6]->setChecked(false);

        if(root.tagName()=="ExGetRestartCtrlRsp")
        {
            QDomElement DayListNode  = root.firstChildElement("DayList");
            QString strtime = DayListNode.attribute("time");

            QDomElement DayNode  = DayListNode.firstChildElement("Day");
            while(!DayNode.isNull())
            {
                QString Week = DayNode.text();
                if(Week=="*") return 0;

                int nWeek = Week.toInt();
                if(nWeek<7)
                    WeekCboxS[nWeek]->setChecked(true);

                DayNode = DayNode.nextSiblingElement("Day");
            }

            //QTime::fromString(strtime);
            //QTime::fromString(strtime, const QString &format);
            QStringList sTime = strtime.split(":");

            ui->timeEditrestarttime->setTime(QTime(sTime[0].toInt()
                                                   ,sTime[1].toInt(),0,0));
        }
    }

    return 0;
}
void FormSystemInfo::on_pushButton_SynDateTime_clicked()
{
    ui->textEdit_SysInfo->append(ui->dateTimeEdit->dateTime().toString());

    QString cmd("sysconfig:syndatetime:");

    QByteArray ACmd = cmd.append(ui->dateTimeEdit->dateTime().toString("yyyy-MM-dd hh:mm:ss")).toLatin1();
    //QByteArray ACmd = cmd.toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void FormSystemInfo::on_pushButton_getsysinfo_clicked()
{
    QString cmd("sysconfig:getsysteminfo:");

    //QByteArray ACmd = cmd.append(XMLStr).toLatin1();
    QByteArray ACmd = cmd.toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void FormSystemInfo::on_pushButton_onekeyrestore_clicked()
{
    if(QMessageBox::information(NULL, "确认", "确定要还原吗  ", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QString cmd("sysconfig:onekeyrestore:");

    //QByteArray ACmd = cmd.append(XMLStr).toLatin1();
    QByteArray ACmd = cmd.toLatin1();

    m_conn->SendCmd(ACmd.data());
}

void FormSystemInfo::on_pushButtonrestartctrlsave_clicked()
{
    if(QMessageBox::information(NULL, "确认", "确定要保存吗  ", QMessageBox::Yes | QMessageBox::No, QMessageBox::No)==QMessageBox::No)
    {
        return;
    }

    QDomDocument doc;
    doc.setContent(tr("<?xml version=\"1.0\" encoding=\"gb2312\"?><ExSaveRestartCtrlReq/>"),false);

    QDomElement DayListListNode = doc.createElement("DayList");

    DayListListNode.setAttribute("time",ui->timeEditrestarttime->time().toString());

    //必须按从小到大的顺序排列
    if(ui->checkBoxSun->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("0"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxMon->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("1"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxTue->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("2"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxWed->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("3"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxThu->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("4"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxFri->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("5"));
        DayListListNode.appendChild(DayNode);
    }
    if(ui->checkBoxSat->isChecked())
    {
        QDomElement DayNode = doc.createElement("Day");
        DayNode.appendChild(doc.createTextNode("6"));
        DayListListNode.appendChild(DayNode);
    }

    doc.documentElement().appendChild(DayListListNode);
    QString XMLStr = doc.toString(0);
    XMLStr = XMLStr.simplified();

    QString cmd("sysconfig:restartcontrolsave:");
    QByteArray ACmd = cmd.append(XMLStr).toLatin1();

    m_conn->SendCmd(ACmd.data());

    QString cmd11("sysconfig:restartcontrolget:");

    QByteArray ACmd111 = cmd11.toLatin1();

    m_conn->SendCmd(ACmd111.data());
}

void FormSystemInfo::on_pushButton_synccomputer_clicked()
{
    ui->textEdit_SysInfo->append(ui->dateTimeEdit->dateTime().toString());

    QString cmd("sysconfig:syndatetime:");

    const QDateTime DateTime = QDateTime::currentDateTime();
    QByteArray ACmd = cmd.append(DateTime.toString("yyyy-MM-dd hh:mm:ss")).toLatin1();
    //QByteArray ACmd = cmd.toLatin1();

    m_conn->SendCmd(ACmd.data());
}
