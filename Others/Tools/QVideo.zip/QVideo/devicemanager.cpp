﻿#include "devicemanager.h"
#include "messagehelper.h"
#include "McServerPeer.h"


DeviceManager::DeviceManager(void)
:m_pMcServerPeer(NULL),m_stageIndex(0),m_pLastSubDev(NULL)
{
}

DeviceManager::~DeviceManager(void)
{
}

DeviceManager* DeviceManager::GetDeviceManager()
{
    static DeviceManager g_DeviceManager;
    return &g_DeviceManager;
}

int DeviceManager::DoInitialize(int stageIndex)
{
    m_pMcServerPeer = McServerPeer::GetInstance();
    m_stageIndex	= stageIndex;

    LOGLINE;
    return DoGetDeviceType();
}

int DeviceManager::DoGetOrganizeTree(int nOrganizeParentId, int nOrganizeId)
{
   /* iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetEquCatalogReq"));

    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("UserId"), McServerPeer::GetInstance()->m_dwUserInfoID);
    xmlParser.AddChildElem (_T("EquCtlgParentId"),nOrganizeParentId);
    xmlParser.AddChildElem (_T("EquCtlgId"),nOrganizeId);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取组织结构树信息信令：EX_GET_EQU_CATALOG_REQ
    LOGLINE;
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGetOrganizeInfoData,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_EQU_CATALOG_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::DoGetEquInfo(int nEquId)
{
    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetMainEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem(_T("EquIdSet"));
    xmlParser.AddChildAttrib(_T("Value"), nEquId);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取组织结构树信息信令：EX_GET_MAIN_EQU_REQ
    LOGLINE;
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGetEquInfoData,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_MAIN_EQU_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::DoGetSubEquInfo(int nSubEquId)
{
    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetSubEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("SubEquIdSet"));
    xmlParser.AddChildAttrib(_T("Value"), nSubEquId);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取组织结构树信息信令：EX_GET_SUB_EQU_REQ
    LOGLINE;
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGetSubEquInfoData,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_SUB_EQU_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnAffairOverTime(DWORD cookie)
{
    return 0;
}

int DeviceManager::Static_OnGetEquInfoData(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    pDeviceManager->OnGetEquInfoData(pData,dataLen);
    return pDeviceManager->DoGetSubEquInfo();
}

int DeviceManager::OnGetEquInfoData(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExGetMainEquRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetChildAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("EquInfoList")))
        return -4;

    xmlParser.IntoElem();
    while(xmlParser.FindElem(_T("EquInfo")))
    {
        DevInfoUnit devInfoUnit;

        DevInfoUnit::MainDevInfo* pMainDevInfo	= &devInfoUnit.m_mainDevInfo;
        pMainDevInfo->EquId		= xmlParser.GetAttribInt(_T("EquId"));
        pMainDevInfo->MainDevName = xmlParser.GetAttrib(_T("EquName"));
        pMainDevInfo->FactoryName = xmlParser.GetAttrib(_T("FactoryName"));
        pMainDevInfo->IpAddr	= xmlParser.GetAttrib(_T("Ip"));
        pMainDevInfo->Port		= xmlParser.GetAttribInt(_T("Port"));
        pMainDevInfo->UserName	= xmlParser.GetAttrib(_T("UserName"));
        pMainDevInfo->PassWord	= xmlParser.GetAttrib(_T("Password"));
        pMainDevInfo->OutputNum = xmlParser.GetAttribInt(_T("OutputNum"));
        pMainDevInfo->ChannelNum	= xmlParser.GetAttribInt(_T("ChannelNum"));
        pMainDevInfo->InputNum	= xmlParser.GetAttribInt(_T("InputNum"));
        pMainDevInfo->Extend = xmlParser.GetAttrib(_T("Extend"));

        m_devInfoList[devInfoUnit.m_mainDevInfo.EquId] = devInfoUnit;
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::Static_OnGetSubEquInfoData(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    pDeviceManager->OnGetSubEquInfoData(pData,dataLen);

    return GetMcPeer()->OnStageInitFinished(pDeviceManager->m_stageIndex);//获取到设备后街结束了，预置点等需要时动态获取
    //return pDeviceManager->DoRequestPreset();
}

int DeviceManager::OnGetSubEquInfoData(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExGetSubEquRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("SubEquList")))
        return -4;

    xmlParser.IntoElem();
    while(xmlParser.FindElem(_T("SubEquInfo")))
    {
        int subEquType = xmlParser.GetAttribInt(_T("SubType"));
        int equID = xmlParser.GetAttribInt(_T("EquId"));
        switch(subEquType)
        {
        case SUB_EQU_TYPE_VEDIO:
            {
                DevInfoUnit::SubVideoDevInfo subVideoDevInfo;
                subVideoDevInfo.SubInfo.SubEquId	= xmlParser.GetAttribInt(_T("SubEquId"));
                subVideoDevInfo.SubInfo.SubEquSeq	= xmlParser.GetAttribInt(_T("SubSeq"));
                subVideoDevInfo.SubInfo.SubDevName	= xmlParser.GetAttrib(_T("SubName"));
                subVideoDevInfo.SubInfo.OrgNodeId	= xmlParser.GetAttribInt(_T("CtlgId"));
                subVideoDevInfo.SubInfo.SubType = SUB_EQU_TYPE_VEDIO;

                subVideoDevInfo.BeSuportPTZ	= xmlParser.GetAttribInt(_T("HasPTZ"));
                subVideoDevInfo.BeWithButton= xmlParser.GetAttribInt(_T("HasLamp"));
                subVideoDevInfo.BeWithDemist= xmlParser.GetAttribInt(_T("HasDemist"));
                subVideoDevInfo.BeWithRainBrush= xmlParser.GetAttribInt(_T("HasRainBrush"));
                m_devInfoList[equID].m_subVideoDevList.push_back(subVideoDevInfo);
            }
            break;
        case SUB_EQU_TYPE_INPUT:
            {
                DevInfoUnit::SubInOutputDevInfo subInputDevInfo;
                subInputDevInfo.SubInfo.SubEquId	= xmlParser.GetAttribInt(_T("SubEquId"));
                subInputDevInfo.SubInfo.SubEquSeq	= xmlParser.GetAttribInt(_T("SubSeq"));
                subInputDevInfo.SubInfo.SubDevName	= xmlParser.GetAttrib(_T("SubName"));
                subInputDevInfo.SubInfo.OrgNodeId	= xmlParser.GetAttribInt(_T("CtlgId"));
                subInputDevInfo.SubInfo.SubType = SUB_EQU_TYPE_INPUT;

                subInputDevInfo.bInput		= TRUE;
                m_devInfoList[equID].m_subInputDevList.push_back(subInputDevInfo);
            }
            break;
        case SUB_EQU_TYPE_OUTPUT:
            {
                DevInfoUnit::SubInOutputDevInfo subOutputDevInfo;
                subOutputDevInfo.SubInfo.SubEquId	= xmlParser.GetAttribInt(_T("SubEquId"));
                subOutputDevInfo.SubInfo.SubEquSeq	= xmlParser.GetAttribInt(_T("SubSeq"));
                subOutputDevInfo.SubInfo.SubDevName	= xmlParser.GetAttrib(_T("SubName"));
                subOutputDevInfo.SubInfo.OrgNodeId	= xmlParser.GetAttribInt(_T("CtlgId"));
                subOutputDevInfo.SubInfo.SubType = SUB_EQU_TYPE_OUTPUT;

                subOutputDevInfo.bInput		= FALSE;
                m_devInfoList[equID].m_subOutputDevList.push_back(subOutputDevInfo);
            }
            break;
        }

    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;

}

int DeviceManager::Static_OnGetOrganizeInfoData(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    pDeviceManager->OnGetOrganizeInfoData(pData,dataLen);
    return pDeviceManager->DoGetEquInfo();
}


int DeviceManager::OnGetOrganizeInfoData(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExGetEquCatalogRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("EquCtlgInfoList")))
        return -4;

    xmlParser.IntoElem();
    while(xmlParser.FindElem(_T("EquCtlgInfo")))
    {
        OrgNode orgnode;
        orgnode.OrgNodeId	= xmlParser.GetAttribInt(_T("CtlgId"));
        orgnode.OrgNodeName  = xmlParser.GetAttrib(_T("CtlgName"));
        orgnode.HigherOrgNodeId = xmlParser.GetAttribInt(_T("CtlgParentId"));
        m_OrgNodeList[orgnode.OrgNodeId] = orgnode;
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::DoGetDeviceType()
{
    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetAccessFactoryInfoReq"));
    xmlParser.AddAttrib(_T("Cache"), (DWORD)this);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取设备类型型号信令：EX_GET_ACCESS_FACTORY_INFO_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGotDeviceType,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_ACCESS_FACTORY_INFO_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnGotDeviceType(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    pDeviceManager->OnGotDeviceType(pData,dataLen);
    return pDeviceManager->DoGetOrganizeTree();
}

int DeviceManager::OnGotDeviceType(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExGetAccessFactoryInfoRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("FactoryInfoList")))
        return -4;

    xmlParser.IntoElem();
    while(xmlParser.FindElem(_T("FactoryInfo")))
    {
        Equipment equipment;
        equipment.FactoryName = xmlParser.GetAttrib(_T("FactoryName"));
        m_EquipmentList.push_back(equipment);
        m_factoryMap[equipment.FactoryName] = equipment.FactoryName;
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::AddOrgNode(int OSuperiorID,QString& OName)
{
    //检查是否有该名字的节点
    for(map<int,OrgNode>::iterator iter = m_OrgNodeList.begin() ; iter != m_OrgNodeList.end(); ++iter)
    {
        if(OName==iter->second.OrgNodeName)
        {
            map<int,OrgNode>::iterator iter2 = m_OrgNodeList.find(iter->second.HigherOrgNodeId);
            if(iter2 != m_OrgNodeList.end())
            {
                OName = iter2->second.OrgNodeName;
            }
            return -5;
        }
    }

    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetEquCatalogReq"));
    xmlParser.AddAttrib(_T("Cache"),OSuperiorID);
    xmlParser.AddChildElem(_T("EquCtlgInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem (_T("EquCtlgInfo"));
    xmlParser.AddChildAttrib(_T("OpSeq"),1);
    xmlParser.AddChildAttrib(_T("OpType"),0);
    xmlParser.AddChildAttrib(_T("CtlgParentId"),OSuperiorID);
    xmlParser.AddChildAttrib(_T("CtlgId"), -1);
    xmlParser.AddChildAttrib(_T("CtlgName"),OName);

    m_lastOrgName			= OName;

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //添加组织节点信令：EX_SET_EQU_CATALOG_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGotAddOrgNodeAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_EQU_CATALOG_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnGotAddOrgNodeAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnGotAddOrgNodeAck(pData,dataLen);
}

int DeviceManager::OnGotAddOrgNodeAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExSetEquCatalogRsp")))
        return -1;
    DWORD cookie = xmlParser.GetAttribInt(_T("Cache"));

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetValList")))
        return -2;

    xmlParser.FindChildElem(_T("EquCtlgInfo"));
    int nResultCode = xmlParser.GetChildAttribInt(_T("RetVal"));
    if(nResultCode !=0)
    {
        return -3;
    }
    int newId = xmlParser.GetChildAttribInt(_T("CtlgId"));

    OrgNode orgNode;
    orgNode.HigherOrgNodeId = cookie;
    orgNode.OrgNodeId = newId;

    orgNode.OrgNodeName				 = m_lastOrgName;
    m_OrgNodeList[orgNode.OrgNodeId] = orgNode;
    NotifyOrgnizeChange(&m_OrgNodeList[orgNode.OrgNodeId],IDeviceChangeSink::ADD);

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::ModifyOrgNodeName(int OrganizeID,QString& OName)
{
    /*map<int,OrgNode>::iterator iterNode = m_OrgNodeList.find(OrganizeID);
    if (iterNode == m_OrgNodeList.end())
        return -1;
    m_OrgNodeList[OrganizeID].OrgNodeName = OName;
    NotifyOrgnizeChange(&m_OrgNodeList[OrganizeID],IDeviceChangeSink::MODIFY);

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetEquCatalogReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("EquCtlgInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem (_T("EquCtlgInfo"));

    xmlParser.AddChildAttrib (_T("OpSeq"), 1);
    xmlParser.AddChildAttrib (_T("OpType"), 1);
    xmlParser.AddChildAttrib (_T("CtlgParentId"), m_OrgNodeList[OrganizeID].HigherOrgNodeId);
    xmlParser.AddChildAttrib (_T("CtlgId"), m_OrgNodeList[OrganizeID].OrgNodeId);
    xmlParser.AddChildAttrib (_T("CtlgName"),m_OrgNodeList[OrganizeID].OrgNodeName);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //修改组织节点名称信令：EX_SET_EQU_CATALOG_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGotModifyOrgNodeNameAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_EQU_CATALOG_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnGotModifyOrgNodeNameAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnGotModifyOrgNodeNameAck(pData,dataLen);
}

int DeviceManager::OnGotModifyOrgNodeNameAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExSetEquCatalogRsp")))
        return -1;
    if (false == xmlParser.FindChildElem(_T("RetValList")))
        return -2;

    xmlParser.IntoElem();
    if (false == xmlParser.FindChildElem(_T("EquCtlgInfo")))
        return -3;

    int nResultCode = xmlParser.GetChildAttribInt(_T("RetVal"));

    MessageHelper::FreeTcharMsg(pCmdMsg);
    return nResultCode;*/
    return 0;
}

int DeviceManager::RemoveOrgNode(int OrganizeID)
{
    /*map<int,OrgNode>::iterator iterNode = m_OrgNodeList.find(OrganizeID);
    if (iterNode == m_OrgNodeList.end())
        return -1;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetEquCatalogReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("EquCtlgInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem (_T("EquCtlgInfo"));

    xmlParser.AddChildAttrib (_T("OpSeq"),1);
    xmlParser.AddChildAttrib (_T("OpType"),2);
    xmlParser.AddChildAttrib (_T("CtlgParentId"), m_OrgNodeList[OrganizeID].HigherOrgNodeId);
    xmlParser.AddChildAttrib (_T("CtlgId"), m_OrgNodeList[OrganizeID].OrgNodeId);
    xmlParser.AddChildAttrib (_T("CtlgName"),m_OrgNodeList[OrganizeID].OrgNodeName);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //修改组织节点名称信令：EX_SET_EQU_CATALOG_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnRemoveOrgNodeAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_EQU_CATALOG_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnRemoveOrgNodeAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnRemoveOrgNodeAck(pData,dataLen);
}

int DeviceManager::OnRemoveOrgNodeAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExSetEquCatalogRsp")))
        return -1;
    if (false == xmlParser.FindChildElem(_T("RetValList")))
        return -2;

    xmlParser.IntoElem();
    if (false == xmlParser.FindChildElem(_T("EquCtlgInfo")))
        return -3;

    int nResultCode = xmlParser.GetChildAttribInt(_T("RetVal"));
    if (0 == nResultCode)
    {
        int OrganizeID = xmlParser.GetChildAttribInt(_T("CtlgId"));
        map<int,OrgNode>::iterator iterNode = m_OrgNodeList.find(OrganizeID);
        if (iterNode != m_OrgNodeList.end())
        {
            NotifyOrgnizeChange(&iterNode->second,IDeviceChangeSink::REMOVE);
            m_OrgNodeList.erase(iterNode);
        }
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);
    return nResultCode;*/
    return 0;
}

int DeviceManager::QueryMainDeviceReq(int EquipmentID)
{
    if(EquipmentID < -1 || EquipmentID == 0)
    {
        //非法
        return -1;
    }
    else if(EquipmentID > 0)
    {
        map<int,OrgNode>::iterator iterNode = m_OrgNodeList.find(EquipmentID);
        if (iterNode == m_OrgNodeList.end())
            return -1;
    }
    else if(EquipmentID == -1)
    {
        //-1表是查全部
    }

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetMainEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("EquIdSet"));
    xmlParser.AddChildAttrib(_T("Value"), EquipmentID);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取组织结构树信息信令：GET_ORG_TREE_INF_REQ
    LOGLINE;
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnQueryMainDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_MAIN_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);
    return 0;
}

int DeviceManager::Static_OnQueryMainDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;

    pDeviceManager->OnQueryMainDeviceAck(pData,dataLen);
    return GetMcPeer()->OnStageInitFinished(pDeviceManager->m_stageIndex);
}

int DeviceManager::OnQueryMainDeviceAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExGetMainEquRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetChildAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("EquInfoList")))
        return -4;

    xmlParser.IntoElem();
    while(xmlParser.FindElem(_T("EquInfo")))
    {
        DevInfoUnit devInfoUnit;

        DevInfoUnit::MainDevInfo* pMainDevInfo	= &devInfoUnit.m_mainDevInfo;
        pMainDevInfo->EquId		= xmlParser.GetAttribInt(_T("EquId"));
        pMainDevInfo->MainDevName = xmlParser.GetAttrib(_T("EquName"));
        pMainDevInfo->IpAddr	= xmlParser.GetAttrib(_T("Ip"));
        pMainDevInfo->Port		= xmlParser.GetAttribInt(_T("Port"));
        pMainDevInfo->UserName	= xmlParser.GetAttrib(_T("UserName"));
        pMainDevInfo->PassWord	= xmlParser.GetAttrib(_T("Password"));
        pMainDevInfo->ChannelNum	= xmlParser.GetAttribInt(_T("ChannelNum"));
        pMainDevInfo->InputNum	= xmlParser.GetAttribInt(_T("InputNum"));
        pMainDevInfo->OutputNum = xmlParser.GetAttribInt(_T("OutputNum"));
        pMainDevInfo->Extend = xmlParser.GetAttrib(_T("Extend"));

        m_devInfoList[devInfoUnit.m_mainDevInfo.EquId].m_mainDevInfo = devInfoUnit.m_mainDevInfo;
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::AddMainDeviceReq(DevInfoUnit* pDevInfoUnit)
{
    /*for(map<int,DevInfoUnit>::iterator iter = m_devInfoList.begin(); iter!=m_devInfoList.end(); ++iter)
    {
        if(iter->second.m_mainDevInfo.MainDevName==pDevInfoUnit->m_mainDevInfo.MainDevName)
        {
            return -1;
        }
    }

    m_lastDevInfo = *pDevInfoUnit;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetMainEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem(_T("EquInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem(_T("EquInfo"));
    xmlParser.AddChildAttrib(_T("OpSeq"), 1);
    xmlParser.AddChildAttrib(_T("OpType"), 0);
    xmlParser.AddChildAttrib(_T("EquId"), -1);
    xmlParser.AddChildAttrib(_T("CtlgId"), pDevInfoUnit->m_mainDevInfo.CtlgId);

    QString mainDevName = pDevInfoUnit->m_mainDevInfo.MainDevName;
    xmlParser.AddChildAttrib(_T("EquName"), pDevInfoUnit->m_mainDevInfo.MainDevName);
    xmlParser.AddChildAttrib(_T("FactoryName"), pDevInfoUnit->m_mainDevInfo.FactoryName);
    xmlParser.AddChildAttrib(_T("Ip"), pDevInfoUnit->m_mainDevInfo.IpAddr);
    xmlParser.AddChildAttrib(_T("Port"), pDevInfoUnit->m_mainDevInfo.Port);
    xmlParser.AddChildAttrib(_T("ChannelNum"), pDevInfoUnit->m_mainDevInfo.ChannelNum);
    xmlParser.AddChildAttrib(_T("InputNum"), pDevInfoUnit->m_mainDevInfo.InputNum);
    xmlParser.AddChildAttrib(_T("OutputNum"), pDevInfoUnit->m_mainDevInfo.OutputNum);
    xmlParser.AddChildAttrib(_T("UserName"), pDevInfoUnit->m_mainDevInfo.UserName);
    xmlParser.AddChildAttrib(_T("Password"), pDevInfoUnit->m_mainDevInfo.PassWord);
    xmlParser.AddChildAttrib(_T("Extend"), pDevInfoUnit->m_mainDevInfo.Extend);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //添加主设备信令：ADD_MAIN_DEVDICE_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnAddMainDeviceReqAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_MAIN_EQU_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnAddMainDeviceReqAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnAddMainDeviceReqAck(pData,dataLen);
}

int DeviceManager::OnAddMainDeviceReqAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }
    MessageHelper::FreeTcharMsg(pCmdMsg);

    if (false == xmlParser.FindElem(_T("ExSetMainEquRsp")))
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetValList")))
        return -2;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("EquInfo")))
        return -2;

    int ReslutId = xmlParser.GetAttribInt(_T("RetVal"));
    if (0 != ReslutId)
        return -3;

    int equID = xmlParser.GetAttribInt(_T("EquId"));

    while(xmlParser.FindChildElem(_T("SubEquInfo")))
    {
        int subEquType = xmlParser.GetChildAttribInt(_T("SubType"));
        switch(subEquType)
        {
        case 0x1100:
            {
                DevInfoUnit::SubVideoDevInfo subVideoDevInfo;
                subVideoDevInfo.SubInfo.SubEquId	= xmlParser.GetChildAttribInt(_T("SubEquId"));
                subVideoDevInfo.SubInfo.SubEquSeq	= xmlParser.GetChildAttribInt(_T("SubSeq"));
                subVideoDevInfo.SubInfo.SubDevName	= xmlParser.GetChildAttrib(_T("SubName"));
                subVideoDevInfo.SubInfo.OrgNodeId	= xmlParser.GetChildAttribInt(_T("CtlgId"));
                subVideoDevInfo.SubInfo.SubType = SUB_EQU_TYPE_VEDIO;

                subVideoDevInfo.BeSuportPTZ	= xmlParser.GetChildAttribInt(_T("HasPTZ"));
                subVideoDevInfo.BeWithButton= xmlParser.GetChildAttribInt(_T("HasLamp"));
                subVideoDevInfo.BeWithDemist= xmlParser.GetChildAttribInt(_T("HasDemist"));
                subVideoDevInfo.BeWithRainBrush= xmlParser.GetChildAttribInt(_T("HasRainBrush"));
                m_devInfoList[equID].m_subVideoDevList.push_back(subVideoDevInfo);
            }
            break;
        case 0x1200:
            {
                DevInfoUnit::SubInOutputDevInfo subInputDevInfo;
                subInputDevInfo.SubInfo.SubEquId	= xmlParser.GetChildAttribInt(_T("SubEquId"));
                subInputDevInfo.SubInfo.SubEquSeq	= xmlParser.GetChildAttribInt(_T("SubSeq"));
                subInputDevInfo.SubInfo.SubDevName	= xmlParser.GetChildAttrib(_T("SubName"));
                subInputDevInfo.SubInfo.OrgNodeId	= xmlParser.GetChildAttribInt(_T("CtlgId"));
                subInputDevInfo.SubInfo.SubType = SUB_EQU_TYPE_INPUT;

                subInputDevInfo.bInput		= TRUE;
                m_devInfoList[equID].m_subInputDevList.push_back(subInputDevInfo);
            }
            break;
        case 0x1300:
            {
                DevInfoUnit::SubInOutputDevInfo subOutputDevInfo;
                subOutputDevInfo.SubInfo.SubEquId	= xmlParser.GetChildAttribInt(_T("SubEquId"));
                subOutputDevInfo.SubInfo.SubEquSeq	= xmlParser.GetChildAttribInt(_T("SubSeq"));
                subOutputDevInfo.SubInfo.SubDevName	= xmlParser.GetChildAttrib(_T("SubName"));
                subOutputDevInfo.SubInfo.OrgNodeId	= xmlParser.GetChildAttribInt(_T("CtlgId"));
                subOutputDevInfo.SubInfo.SubType = SUB_EQU_TYPE_OUTPUT;

                subOutputDevInfo.bInput		= FALSE;
                m_devInfoList[equID].m_subOutputDevList.push_back(subOutputDevInfo);
            }
            break;
        }
    }

    m_lastDevInfo.m_mainDevInfo.EquId = equID;
    m_devInfoList[equID].m_mainDevInfo = m_lastDevInfo.m_mainDevInfo;//写入保存主设备的信息，子设备的信息由服务端返回的
    NotifyDeviceChange(&m_devInfoList[equID],IDeviceChangeSink::ADD);
    return equID;*/

    return 0;
}

int DeviceManager::ModifyDeviceReq(DevInfoUnit* pDevInfoUnit)
{
    /*for(map<int,DevInfoUnit>::iterator iter = m_devInfoList.begin(); iter!=m_devInfoList.end(); ++iter)
    {
        if(iter->second.m_mainDevInfo.EquId != pDevInfoUnit->m_mainDevInfo.EquId &&
            iter->second.m_mainDevInfo.MainDevName == pDevInfoUnit->m_mainDevInfo.MainDevName)
        {
            return -5;
        }
    }

    m_lastDevInfo = *pDevInfoUnit;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetMainEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("EquInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem (_T("EquInfo"));
    xmlParser.AddChildAttrib(_T("OpSeq"), 1);
    xmlParser.AddChildAttrib(_T("OpType"), 1);
    xmlParser.AddChildAttrib(_T("EquId"), pDevInfoUnit->m_mainDevInfo.EquId);
    xmlParser.AddChildAttrib(_T("CtlgId"), pDevInfoUnit->m_mainDevInfo.CtlgId);
    xmlParser.AddChildAttrib(_T("EquName"), pDevInfoUnit->m_mainDevInfo.MainDevName);
    xmlParser.AddChildAttrib(_T("FactoryName"), pDevInfoUnit->m_mainDevInfo.FactoryName);
    xmlParser.AddChildAttrib(_T("Ip"), pDevInfoUnit->m_mainDevInfo.IpAddr);
    xmlParser.AddChildAttrib(_T("Port"), pDevInfoUnit->m_mainDevInfo.Port);
    xmlParser.AddChildAttrib(_T("ChannelNum"), pDevInfoUnit->m_mainDevInfo.ChannelNum);
    xmlParser.AddChildAttrib(_T("InputNum"), pDevInfoUnit->m_mainDevInfo.InputNum);
    xmlParser.AddChildAttrib(_T("OutputNum"), pDevInfoUnit->m_mainDevInfo.OutputNum);
    xmlParser.AddChildAttrib(_T("UserName"), pDevInfoUnit->m_mainDevInfo.UserName);
    xmlParser.AddChildAttrib(_T("Password"), pDevInfoUnit->m_mainDevInfo.PassWord);
    xmlParser.AddChildAttrib(_T("Extend"), pDevInfoUnit->m_mainDevInfo.Extend);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //添加主设备信令：ADD_MAIN_DEVDICE_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnModifyDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_MAIN_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);*/
    return 0;
}

int DeviceManager::Static_OnModifyDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnModifyDeviceAck(pData,dataLen);
}

int DeviceManager::OnModifyDeviceAck(BYTE* pData,int dataLen)
{
#if 0
    iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExSetMainEquRsp")) )
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetValList")))
        return -2;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("EquInfo")))
        return -2;

    int ReslutId = xmlParser.GetAttribInt(_T("RetVal"));
    if (0 != ReslutId)
        return -3;

    int equID = xmlParser.GetAttribInt(_T("EquId"));

    m_devInfoList[equID].m_mainDevInfo = m_lastDevInfo.m_mainDevInfo;
    NotifyDeviceChange(&m_devInfoList[equID],IDeviceChangeSink::MODIFY);

    MessageHelper::FreeTcharMsg(pCmdMsg);
    return equID;
#endif
    return 0;
}


int DeviceManager::ModifySubDeviceReq(DevInfoUnit* pDevInfoUnit, DevInfoUnit::SubDevInfo* pSubInfo, int oldCtlgId, int newCtlgId, int SpecficType)
{
#if 0
    m_lastDevInfo = *pDevInfoUnit;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExSetSubEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("SubEquInfoList"));
    xmlParser.IntoElem();
    xmlParser.AddChildElem (_T("SubEquInfo"));
    xmlParser.AddChildAttrib(_T("OpSeq"), 1);
    xmlParser.AddChildAttrib(_T("OpType"), 1);
    xmlParser.AddChildAttrib(_T("SubEquId"), pSubInfo->SubEquId);
    xmlParser.AddChildAttrib(_T("EquId"), pDevInfoUnit->m_mainDevInfo.EquId);
    xmlParser.AddChildAttrib(_T("NewCtlgId"), newCtlgId);
    xmlParser.AddChildAttrib(_T("OldCtlgId"), oldCtlgId);
    xmlParser.AddChildAttrib(_T("SubName"), pSubInfo->SubDevName);
    xmlParser.AddChildAttrib(_T("SubSeq"), pSubInfo->SubEquSeq);
    xmlParser.AddChildAttrib(_T("SubType"), pSubInfo->SubType);
    xmlParser.AddChildAttrib(_T("SpecificType"), SpecficType);
    xmlParser.AddChildAttrib(_T("HasPTZ"), 1);
    xmlParser.AddChildAttrib(_T("HasLamp"), 1);
    xmlParser.AddChildAttrib(_T("HasDemist"), 1);
    xmlParser.AddChildAttrib(_T("HasRainBrush"), 1);
    xmlParser.AddChildAttrib(_T("Extend"), _T(""));

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    m_lastEquId = pDevInfoUnit->m_mainDevInfo.EquId;
    m_lastOldCtlgId = oldCtlgId;
    m_lastNewCtlgId = newCtlgId;

    //修改子设备信令：EX_SET_SUB_EQU_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnModifySubDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_SET_SUB_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);
 #endif
    return 0;
}

int DeviceManager::Static_OnModifySubDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnModifySubDeviceAck(pData,dataLen);
}

int DeviceManager::OnModifySubDeviceAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExSetSubEquRsp")) )
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetValList")))
        return -2;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("SubEquInfo")))
        return -2;

    int ReslutId = xmlParser.GetAttribInt(_T("RetVal"));
    if (0 != ReslutId)
        return -3;

    int SubEquId = xmlParser.GetAttribInt(_T("SubEquId"));

    int findit=0;
    map<int,DevInfoUnit>::iterator iterdevInfo=m_devInfoList.begin();
    for(; iterdevInfo!=m_devInfoList.end(); ++iterdevInfo)
    {
        //在通道中查找该id
        if(!findit)
        {
            list<DevInfoUnit::SubVideoDevInfo>::iterator iterVideo = iterdevInfo->second.m_subVideoDevList.begin();
            for(; iterVideo!=iterdevInfo->second.m_subVideoDevList.end(); ++iterVideo)
            {
                if(SubEquId==iterVideo->SubInfo.SubEquId)
                {
                    //在通道中找到
                    NotifyDeviceChange(&(*iterVideo), IDeviceChangeSink::MODIFY_SUB);
                    findit=1;
                    break;
                }
            }
        }

        //在输出中查找该id
        if(!findit)
        {
            list<DevInfoUnit::SubInOutputDevInfo>::iterator iterInput = iterdevInfo->second.m_subInputDevList.begin();
            for(; iterInput!=iterdevInfo->second.m_subInputDevList.end(); ++iterInput)
            {
                if(SubEquId==iterInput->SubInfo.SubEquId)
                {
                    //在输出中找到
                    NotifyDeviceChange(&(*iterInput),IDeviceChangeSink::MODIFY_SUB);
                    findit=1;
                    break;
                }
            }
        }

        //在探头中查找该id
        if(!findit)
        {
            list<DevInfoUnit::SubInOutputDevInfo>::iterator iterOutput = iterdevInfo->second.m_subOutputDevList.begin();
            for(; iterOutput!=iterdevInfo->second.m_subOutputDevList.end(); ++iterOutput)
            {
                if(SubEquId==iterOutput->SubInfo.SubEquId)
                {
                    //在输出中找到
                    NotifyDeviceChange(&(*iterOutput), IDeviceChangeSink::MODIFY_SUB);
                    findit=1;
                    break;
                }
            }
        }

        if(findit)
        {
            break;
        }

    }

    MessageHelper::FreeTcharMsg(pCmdMsg);
    return SubEquId;*/
    return 0;
}



int DeviceManager::RemoveSubDeviceReq(DevInfoUnit* pDevInfoUnit,DevInfoUnit::SubVideoDevInfo* pSubInfo)
{
    /*map<int,DevInfoUnit>::iterator iter = m_devInfoList.find(pDevInfoUnit->m_mainDevInfo.EquId);
    if (iter == m_devInfoList.end())
        return -1;

    m_lastDevInfo = *pDevInfoUnit;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExRmvSubEquReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);

    xmlParser.AddChildElem (_T("SubEquIdSet"));
    xmlParser.AddChildAttrib(_T("Value"), pSubInfo->SubInfo.SubEquId);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //删除子设备信令：RMV_SUB_DEVDICE_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnRemoveSubDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_RMV_SUB_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);*/
    return 0;
}

int DeviceManager::Static_OnRemoveSubDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager)
        return -1;
    return pDeviceManager->OnRemoveSubDeviceAck(pData,dataLen);
}

int DeviceManager::OnRemoveSubDeviceAck(BYTE* pData,int dataLen)
{
#if 0
    iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExRmvSubEquRsp")) )
        return -1;
    if (xmlParser.FindChildElem(_T("RetValList")))
    {
        xmlParser.IntoElem();
        while (xmlParser.FindChildElem(_T("SubEquInfo")))
        {
            if (0 == xmlParser.GetChildAttribInt(_T("RetVal")))
            {
                int ICMSSubEquipmentID = xmlParser.GetChildAttribInt(_T("SubEquId"));

                int findit=0;
                map<int,DevInfoUnit>::iterator iterdevInfo=m_devInfoList.begin();
                for(; iterdevInfo!=m_devInfoList.end(); ++iterdevInfo)
                {
                    //在通道中查找该id
                    if(!findit)
                    {
                        list<DevInfoUnit::SubVideoDevInfo>::iterator iterVideo = iterdevInfo->second.m_subVideoDevList.begin();
                        for(; iterVideo!=iterdevInfo->second.m_subVideoDevList.end(); ++iterVideo)
                        {
                            if(ICMSSubEquipmentID==iterVideo->SubInfo.SubEquId)
                            {
                                //在通道中找到
                                NotifyDeviceChange(&(*iterVideo), IDeviceChangeSink::REMOVE_SUB);

                                //删除该子设备
                                iterdevInfo->second.m_subVideoDevList.erase(iterVideo);
                                findit=1;
                                break;
                            }
                        }
                    }

                    //在输出中查找该id
                    if(!findit)
                    {
                        list<DevInfoUnit::SubInOutputDevInfo>::iterator iterInput = iterdevInfo->second.m_subInputDevList.begin();
                        for(; iterInput!=iterdevInfo->second.m_subInputDevList.end(); ++iterInput)
                        {
                            if(ICMSSubEquipmentID==iterInput->SubInfo.SubEquId)
                            {
                                //在输出中找到
                                NotifyDeviceChange(&(*iterInput),IDeviceChangeSink::REMOVE_SUB);

                                //删除该子设备
                                iterdevInfo->second.m_subInputDevList.erase(iterInput);
                                findit=1;
                                break;
                            }
                        }
                    }

                    //在探头中查找该id
                    if(!findit)
                    {
                        list<DevInfoUnit::SubInOutputDevInfo>::iterator iterOutput = iterdevInfo->second.m_subOutputDevList.begin();
                        for(; iterOutput!=iterdevInfo->second.m_subOutputDevList.end(); ++iterOutput)
                        {
                            if(ICMSSubEquipmentID==iterOutput->SubInfo.SubEquId)
                            {
                                //在输出中找到
                                NotifyDeviceChange(&(*iterOutput), IDeviceChangeSink::REMOVE_SUB);

                                //删除该子设备
                                iterdevInfo->second.m_subOutputDevList.erase(iterOutput);
                                findit=1;
                                break;
                            }
                        }
                    }

                    if(findit)
                    {
                        if(iterdevInfo->second.m_subVideoDevList.empty()
                            && iterdevInfo->second.m_subOutputDevList.empty()
                            && iterdevInfo->second.m_subOutputDevList.empty())
                        {
                            //主设备上没有任何子设备了,删除该主设备
                            m_devInfoList.erase(iterdevInfo);
                        }
                        break;
                    }

                }

                /*map<int,DevInfoUnit>::iterator iterDev = m_devInfoList.find(ICMSSubEquipmentID);
                if (iterDev != m_devInfoList.end())
                {
                    DevInfoUnit* pDevInfoUnit = &iterDev->second;
                    NotifyDeviceChange(pDevInfoUnit,IDeviceChangeSink::REMOVE);
                    pDevInfoUnit->m_subVideoDevList.clear();
                    pDevInfoUnit->m_subInputDevList.clear();
                    pDevInfoUnit->m_subOutputDevList.clear();

                    //m_devInfoList.erase(ICMSSubEquipmentID);
                }*/
            }
        }
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);
#endif
    return 0;
}

int DeviceManager::RemoveMainDeviceReq(DevInfoUnit* pDevInfoUnit)
{
    /*map<int,DevInfoUnit>::iterator iter = m_devInfoList.find(pDevInfoUnit->m_mainDevInfo.EquId);
    if (iter == m_devInfoList.end())
        return -1;

    m_lastDevInfo = *pDevInfoUnit;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExRmvMainEquReq"));
    xmlParser.AddAttrib(_T("Cache"), (DWORD)this);
    xmlParser.AddChildElem (_T("EquIdSet"));
    xmlParser.AddChildAttrib(_T("Value"), pDevInfoUnit->m_mainDevInfo.EquId);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //删除主设备信令：EX_RMV_MAIN_EQU_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnRemoveMainDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_RMV_MAIN_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);*/
    return 0;
}

int DeviceManager::Static_OnRemoveMainDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnRemoveMainDeviceAck(pData,dataLen);
}

int DeviceManager::OnRemoveMainDeviceAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("ExRmvMainEquRsp")) )
        return -1;
    if (xmlParser.FindChildElem(_T("RetValList")))
    {
        xmlParser.IntoElem();
        while (xmlParser.FindChildElem(_T("EquInfo")))
        {
            xmlParser.IntoElem();
            if (xmlParser.GetChildAttribInt(_T("RetVal")) == 0)
            {
                int EquId = xmlParser.GetChildAttribInt(_T("EquId"));
                map<int,DevInfoUnit>::iterator iterDev = m_devInfoList.find(EquId);
                if (iterDev != m_devInfoList.end())
                {
                    NotifyDeviceChange(&iterDev->second,IDeviceChangeSink::REMOVE);
                    m_devInfoList.erase(iterDev);
                }
            }
            xmlParser.OutOfElem();
        }
    }

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return 0;
}

int DeviceManager::ConnectDeviceReq(DevInfoUnit* pDevInfoUnit)
{
   /* map<int,DevInfoUnit>::iterator iter = m_devInfoList.find(pDevInfoUnit->m_mainDevInfo.EquId);
    if (iter == m_devInfoList.end())
        return -1;

    iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("DoConnectEquReq"));
    xmlParser.AddChildElem (_T("Cookie"),(DWORD)this);
    xmlParser.AddChildElem (_T("EquName"),pDevInfoUnit->m_mainDevInfo.MainDevName);
    xmlParser.AddChildElem (_T("EquID"),pDevInfoUnit->m_mainDevInfo.EquId);
    xmlParser.AddChildElem (_T("userName"),pDevInfoUnit->m_mainDevInfo.UserName);
    xmlParser.AddChildElem (_T("passWord"),pDevInfoUnit->m_mainDevInfo.PassWord);
    xmlParser.AddChildElem (_T("ipAddress"),pDevInfoUnit->m_mainDevInfo.IpAddr);
    xmlParser.AddChildElem (_T("port"),pDevInfoUnit->m_mainDevInfo.Port);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //连接设备：CONNECT_EQU_REQ
    const DWORD CONNECT_EQU_REQ = 0x0115;
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnConnectDeviceAck,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(CONNECT_EQU_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack);

    MessageHelper::FreeByteMsg(pchXmlOut);*/
    return 0;
}

int DeviceManager::Static_OnConnectDeviceAck(DWORD cookie,BYTE* pData,int dataLen)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnConnectDeviceAck(pData,dataLen);
}

int DeviceManager::OnConnectDeviceAck(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }

    if (false == xmlParser.FindElem(_T("DoConnectEquRsp")) )
        return -1;

    if (false == xmlParser.FindChildElem(_T("Cookie")))
        return -3;

    int OrganizeID = xmlParser.GetChildDataInt();

    if (false == xmlParser.FindChildElem(_T("ResultCode")))
        return -2;

    int nReslutCode = xmlParser.GetChildDataInt();

    MessageHelper::FreeTcharMsg(pCmdMsg);*/
    return nReslutCode;
}

int DeviceManager::NotifyOrgnizeChange(OrgNode* pOrgNode,int changeType)
{
    QMutexLocker simpleLock(&m_simpleCS);
    list<IDeviceChangeSink*>::iterator iterSink = m_devChangeSinkList.begin();
    for (;iterSink != m_devChangeSinkList.end();++iterSink)
    {
        (*iterSink)->OnOrgnizeNodeChange(pOrgNode,changeType);
    }
    return 0;
}

int DeviceManager::NotifyDeviceChange(void* pDevInfo,int changeType)
{
    QMutexLocker simpleLock(&m_simpleCS);
    list<IDeviceChangeSink*>::iterator iterSink = m_devChangeSinkList.begin();
    for (;iterSink != m_devChangeSinkList.end();++iterSink)
    {
        (*iterSink)->OnDeviceChange(pDevInfo,changeType);
    }
    return 0;
}

int DeviceManager::AddNodeChangeSink(IDeviceChangeSink* pSink)
{
    QMutexLocker simpleLock(&m_simpleCS);
    list<IDeviceChangeSink*>::iterator iterSink = m_devChangeSinkList.begin();
    for (;iterSink != m_devChangeSinkList.end();++iterSink)
    {
        if (*iterSink == pSink)
            break;
    }
    if (iterSink == m_devChangeSinkList.end())
        m_devChangeSinkList.push_back(pSink);
    return 0;
}

int DeviceManager::RemoveNodeChangeSink(IDeviceChangeSink* pSink)
{
    QMutexLocker simpleLock(&m_simpleCS);
    list<IDeviceChangeSink*>::iterator iterSink = m_devChangeSinkList.begin();
    for (;iterSink != m_devChangeSinkList.end();++iterSink)
    {
        if (*iterSink == pSink)
        {
            m_devChangeSinkList.erase(iterSink);
            break;
        }
    }
    return 0;
}

int DeviceManager::OnRecvData(BYTE* pData, int dataLen)
{
    if (NULL == pData || dataLen < sizeof(ST_ICMS_CMD_HEADER) || ::IsBadWritePtr (pData,dataLen))
        return -2;
    STRY;
    ST_ICMS_CMD_HEADER* pCmdHeader = (ST_ICMS_CMD_HEADER*)pData;
    switch (pCmdHeader->dwCmdSubType)
    {
    case 0x02e0://添加组织节点更新通知,修改组织节点名称更新通知,删除组织节点更新通知
    case 0x02e1://添加子设备更新通知,修改子设备更新通知,删除子设备更新通知
        {
        }
        break;
    }
    SCATCH;
    return 0;
}

//获取通道
DeviceManager::DevInfoUnit::SubVideoDevInfo* DeviceManager::GetSubDev(int devId)
{
    map<int,DevInfoUnit>::iterator iter		= m_devInfoList.begin();
    for(;iter != m_devInfoList.end();++iter)
    {
        list<DeviceManager::DevInfoUnit::SubVideoDevInfo>::iterator iterSub =iter->second.m_subVideoDevList.begin();
        for(;iterSub !=iter->second.m_subVideoDevList.end();++iterSub)
        {
            if (iterSub->SubInfo.SubEquId != devId)
                continue;

            return &(*iterSub);
        }
    }
    return NULL;
}
//获取输出
DeviceManager::DevInfoUnit::SubInOutputDevInfo* DeviceManager::GetSubInOutputDev(int nSubEquId)
{
    map<int,DevInfoUnit>::iterator iter	= m_devInfoList.begin();
    for(;iter != m_devInfoList.end();++iter)
    {
        list<DeviceManager::DevInfoUnit::SubInOutputDevInfo>::iterator iterSub = iter->second.m_subInputDevList.begin();
        for(; iterSub != iter->second.m_subInputDevList.end(); ++iterSub)
        {
            if (iterSub->SubInfo.SubEquId == nSubEquId)
            {
                return &(*iterSub);
            }
        }

        iterSub = iter->second.m_subOutputDevList.begin();
        for(; iterSub != iter->second.m_subOutputDevList.end(); ++iterSub)
        {
            if (iterSub->SubInfo.SubEquId == nSubEquId)
            {
                return &(*iterSub);
            }
        }
    }
    return NULL;
}

int DeviceManager::DoRequestPreset(int SubEquId)
{
    //list<DevInfoUnit::SubVideoDevInfo*>::iterator iter = m_reqPresetList.begin();
    //if (iter == m_reqPresetList.end())
    //	return GetMcPeer()->OnStageInitFinished(m_stageIndex);

    //m_pLastSubDev = *iter;
    //m_reqPresetList.erase(iter);

    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetPtzPresetPosReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("UserId"),GetMcPeer()->m_dwUserInfoID);
    xmlParser.AddChildElem (_T("SubEquId"),SubEquId);

    BYTE* pOutMsg = NULL;
    int nCmdLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pOutMsg, nCmdLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取云台预置点
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGotPreset,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_PTZ_PRESET_POS_REQ,(char*)pOutMsg,nCmdLen,&stAffairCallBack,1,0,1);

    MessageHelper::FreeByteMsg(pOutMsg);*/
    return 0;
}

int DeviceManager::Static_OnGotPresetOvertime(DWORD cookie)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnGotPresetOvertime();
}
int DeviceManager::OnGotPresetOvertime()
{
    /*iCMSP_SimpleLock cs(&m_SinkLock, _T("DeviceManager::OnGotCurise"));
    for(list<IDeviceChangeSink*>::iterator iter = m_devChangeSinkList.begin(); iter!=m_devChangeSinkList.end(); ++iter)
    {
        (*iter)->OnDeviceNotify(99, "获取预置点超时");
    }*/
    return 0;
}
int DeviceManager::Static_OnGotPreset(DWORD cookie,BYTE* pData,int dataLen)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnGotPreset(pData,dataLen);
}

int DeviceManager::OnGotPreset(BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }
    MessageHelper::FreeTcharMsg(pCmdMsg);

    if (false == xmlParser.FindElem(_T("ExGetPtzPresetPosRsp")) )
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetChildAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("SubEquId")))
        return -2;
    int SubEquId = xmlParser.GetChildDataInt();
    if (0 == SubEquId)
        return -3;

    if (false == xmlParser.FindElem(_T("PresetPosList")))
        return -4;

    xmlParser.IntoElem();
    while (xmlParser.FindElem(_T("PresetPos")))
    {
        PreSetPoint presetPt;
        presetPt.presetId = xmlParser.GetAttribInt(_T("PresetId"));
        presetPt.presetSeq = xmlParser.GetAttribInt(_T("PresetSeq"));
        presetPt.presetName = xmlParser.GetAttrib(_T("PresetName"));
        m_pLastSubDev->presetList.push_back(presetPt);
    }

    DoRequestCurise(SubEquId);*/
    return 0;
}

int DeviceManager::DoRequestCurise(int SubEquId)
{
    /*iCMSP_XmlParser	xmlParser;
    xmlParser.AddElem(_T("ExGetPtzCruiseReq"));
    xmlParser.AddAttrib(_T("Cache"),(DWORD)this);
    xmlParser.AddChildElem (_T("UserId"),GetMcPeer()->m_dwUserInfoID);
    xmlParser.AddChildElem (_T("SubEquId"),SubEquId);

    BYTE* pchXmlOut = NULL;
    int nOutXmlLen = 0;
    int nRet = MessageHelper::BuildCmdXml(&pchXmlOut, nOutXmlLen, xmlParser);
    if(nRet != 0)
    {
        return -1;
    }

    //获取云台的巡航信息信令：EX_GET_PTZ_CRUISE_REQ
    ST_AFFAIR_CALLBACK	stAffairCallBack((DWORD)this,Static_OnGotCurise,Static_OnAffairOverTime);
    GetMcPeer()->SendData2Mc(EX_GET_PTZ_CRUISE_REQ,(char*)pchXmlOut,nOutXmlLen,&stAffairCallBack,1,0,1);

    MessageHelper::FreeByteMsg(pchXmlOut);*/
    return 0;
}
int DeviceManager::Static_OnGotCuriseOvertime(DWORD cookie)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnGotCuriseOvertime();
}
int DeviceManager::OnGotCuriseOvertime()
{
    /*iCMSP_SimpleLock cs(&m_SinkLock, _T("DeviceManager::OnGotCurise"));
    for(list<IDeviceChangeSink*>::iterator iter = m_devChangeSinkList.begin(); iter!=m_devChangeSinkList.end(); ++iter)
    {
        (*iter)->OnDeviceNotify(99, "获取巡航超时");
    }*/
    return 0;
}
int DeviceManager::Static_OnGotCurise(DWORD cookie,BYTE* pData,int dataLen)
{
    /*DeviceManager* pDeviceManager = (DeviceManager*)cookie;
    if (NULL == pDeviceManager || ::IsBadReadPtr(pDeviceManager,sizeof(DeviceManager)))
        return -1;*/
    return pDeviceManager->OnGotCurise(pData,dataLen);
}

int DeviceManager::OnGotCurise(UINT64 fromAddr,BYTE* pData,int dataLen)
{
    /*iCMSP_XmlParser xmlParser;
    TCHAR* pCmdMsg = NULL;
    ST_ICMS_CMD_HEADER stCmdHeader;
    int nRet = MessageHelper::ParseCmdMsg(xmlParser, &pCmdMsg, stCmdHeader, pData);
    if(nRet != 0)
    {
        return -1;
    }
    MessageHelper::FreeTcharMsg(pCmdMsg);

    if (false == xmlParser.FindElem(_T("ExGetPtzCruiseRsp")) )
        return -1;

    xmlParser.IntoElem();
    if (false == xmlParser.FindElem(_T("RetVal")))
        return -2;
    int nResultCode = xmlParser.GetChildAttribInt(_T("Code"));
    if (0 != nResultCode)
        return -3;

    if (false == xmlParser.FindElem(_T("CruiseInfoList")))
        return -4;

    xmlParser.IntoElem();
    while (xmlParser.FindElem(_T("CruiseInfo")))
    {
        CurisePoint curisePoint;
        curisePoint.curiseId = xmlParser.GetAttribInt(_T("CruiseId"));
        curisePoint.curiseName = xmlParser.GetAttrib(_T("CruiseName"));
        while(xmlParser.FindChildElem(_T("PresetPos")))
        {

        }
        m_pLastSubDev->curiseList.push_back(curisePoint);
    }

    iCMSP_SimpleLock cs(&m_SinkLock, _T("DeviceManager::OnGotCurise"));
    for(list<IDeviceChangeSink*>::iterator iter = m_devChangeSinkList.begin(); iter!=m_devChangeSinkList.end(); ++iter)
    {
        (*iter)->OnDeviceNotify(1, NULL);
    }
*/
    return 0;
}
