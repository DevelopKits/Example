#ifndef VIEW_H
#define VIEW_H

#include <QWidget>
#include "connector.h"

namespace Ui {
class View;
}

class VView : public QWidget
{
    Q_OBJECT
    
public:
    explicit VView(QWidget *parent = 0, Connector *Conn=0);
    ~VView();
    
public slots:
    void on_pushButton_clicked(void);
    void OnReciveData(char* Data, int Len);
private:
    Connector* Conn;
    Ui::View *ui;


};

#endif // VIEW_H
